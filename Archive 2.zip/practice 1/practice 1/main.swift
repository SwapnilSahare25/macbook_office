//
//  main.swift
//  practice 1
//
//  Created by Swapnil Sahare on 18/11/22.
//

import Foundation

print("Hello, World!")

var myTup = (25,10.23,"City")
print(myTup)
print(type(of: myTup))

print(myTup.0)
print(myTup.1)
print(myTup.2)


var mysTup = ("Swapnil","Ashish","Sagar","Suraj")
print(mysTup)

print(type(of: mysTup))

print(mysTup.0)
print(mysTup.2)
print(mysTup.1)


let myrTup = (1,2,4,5,6)
print(type(of: myrTup))
print(myrTup)

print(myrTup.3)
print(myrTup.2)

let stringL = "Hello\tWorld\n\nHello\'Swift 4\'"
print(stringL)


var string1 = "23\n24\n25\n26\n"
print(string1)


// conditional statments decision making


