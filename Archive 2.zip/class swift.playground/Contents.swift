import UIKit

var greeting = "Hello, playground"

class person {
    
    var age : Int
    var name : String
    
    init(age : Int,name:String) {
        <#statements#>
    }
    
}
