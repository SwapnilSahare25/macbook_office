import UIKit

var greeting = "Hello, playground"

let myArr = [4,7,8,9,3,41,23,34]

var smallNumber = myArr[0]

for number in myArr {
    print(number)
    
}
