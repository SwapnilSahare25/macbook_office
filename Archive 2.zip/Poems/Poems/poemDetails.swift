//
//  poemDetails.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import Foundation
import UIKit

class poemDetails: UIViewController{
    
}
