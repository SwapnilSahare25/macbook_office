//
//  ViewController.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!


    let poetUrl = "https://poetrydb.org/author"
    var poetArray: poetModel?
    var apiResponseData: Data = Data()
    var selectedData: String = ""
    
    @IBOutlet weak var poetListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
 

        poetListTableView.dataSource = self
        poetListTableView.delegate = self
        
        loadingIndicator.startAnimating()
        self.loadingIndicator.isHidden = false
        performSession()
         
    }

  


    
    
}


extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return poetArray?.authors.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          
        selectedData = (poetArray?.authors[indexPath.row])!
        performSegue(withIdentifier: "viewData", sender: self)
    }
    
  
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "viewData" {
          let detailViewController = segue.destination as! poemList
            detailViewController.poet = selectedData
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
   
        let cell = poetListTableView.dequeueReusableCell(withIdentifier: "poetCell", for: indexPath)
        
        guard let array = poetArray else {return cell}
     
        let poetApiData  = array.authors[indexPath.row]
 
        cell.textLabel?.text = poetApiData 
        return cell
    }
    
    
    
}

extension ViewController{
    
    func createRequest()->URLRequest?{
        guard let uniUrl = URL(string: poetUrl) else {return nil}
        let request = NSURLRequest(url: uniUrl)
        return request as URLRequest
    }
    
    
    
    // to perform a session on any Task we need Request First -
    func performSession(){
        guard let myRequestIsValid = createRequest() else {return}
        let configure = URLSessionConfiguration.default
        let session = URLSession(configuration: configure)
   
        let task = session.dataTask(with: myRequestIsValid)
        task.delegate = self
        task.resume()
    }
    
    func parseData(_ data:Data){
        do {
            let decoder = JSONDecoder()
            poetArray = try decoder.decode(poetModel.self, from: data)
        }catch let error {
            print(error)
        }
     
        DispatchQueue.main.async {
            self.poetListTableView.reloadData()
            self.loadingIndicator.stopAnimating()
            self.loadingIndicator.isHidden = true
        }
    }
    
    
}

extension ViewController: URLSessionTaskDelegate,URLSessionDataDelegate{
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard error == nil else {
            return
        }
        parseData(apiResponseData)
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
//        if let string = String(bytes: data, encoding: .utf8) {
//           print(string)
//
//        } else {
//            print("not a valid UTF-8 sequence")
//        }
        
         self.apiResponseData.append(data)
     }
}

