//
//  poemModel.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import Foundation
 
 
struct poemModel: Codable{
       let title: String
       let lines: [String]
       let linecount: String
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decode(String.self, forKey: .title)
        self.lines = try container.decode([String].self, forKey: .lines)
        self.linecount = try container.decode(String.self, forKey: .linecount)
    }
    enum CodingKeys: CodingKey {
        case title
        case lines
        case linecount
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(self.title, forKey: .title)
        try container.encode(self.lines, forKey: .lines)
        try container.encode(self.linecount, forKey: .linecount)
    }
    
}
