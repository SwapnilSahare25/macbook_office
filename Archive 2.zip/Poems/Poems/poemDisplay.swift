//
//  poemDisplay.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import Foundation
import UIKit

class poemDisplay: UIViewController{
    var poemDetailsData: String = ""
    
    @IBOutlet weak var poemtext: UILabel!
    
    var lineArray: [String]?
 
    
    @IBOutlet weak var poemTextView: UITextView!
    

    override func viewDidLoad() {
        var finalString = lineArray!.joined(separator: " ")
        var text = ""
        for index in 0..<lineArray!.count {
            text += "\(lineArray![index])\n"
           }
 
        poemTextView.text = text
 
        self.title = poemDetailsData
      
    }
}


