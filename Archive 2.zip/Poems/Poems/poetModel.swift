//
//  poetModel.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import Foundation


struct poetModel: Codable{
    
    var authors : [String]
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.authors = try container.decode([String].self, forKey: .authors)
    }
    
    enum CodingKeys: CodingKey {
        case authors
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(self.authors, forKey: .authors)
    }
    
}
 
