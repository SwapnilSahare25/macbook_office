//
//  poemList.swift
//  Poems
//
//  Created by Amit Ninawe on 11/01/23.
//

import Foundation
import UIKit

class poemList: UIViewController{
    
    
    var poet: String = ""
    var lineArr: [String]?
    
    @IBOutlet weak var poemListTable: UITableView!
   
    var poemsURL = "https://poetrydb.org/author/"
    var poemArray: [poemModel]?
    var apiResponseData: Data = Data()
    var selectedData: String = ""
    
    @IBOutlet weak var poemListactivityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        poemListTable.dataSource = self
        poemListTable.delegate = self
        
        poemListactivityIndicator.startAnimating()
        poemListactivityIndicator.isHidden = false
        self.title = poet
        poemsURL = "https://poetrydb.org/author/\(poet)"
        performSession()
        
    }
   
    
}




extension poemList: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return poemArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          
        selectedData = poemArray![indexPath.row].title
        lineArr = poemArray![indexPath.row].lines
        performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetails" {
          let detailViewController = segue.destination as! poemDisplay
            detailViewController.poemDetailsData = selectedData
            detailViewController.lineArray = lineArr
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
   
        let cell = poemListTable.dequeueReusableCell(withIdentifier: "poemCell", for: indexPath)
        
        guard let array = poemArray else {return cell}
     
        let poemApiData  = array[indexPath.row]
        cell.textLabel!.numberOfLines = 0
        cell.textLabel!.lineBreakMode = .byWordWrapping
        cell.textLabel!.font = UIFont.systemFont(ofSize: 14.0)

        cell.textLabel?.text = poemApiData.title
        return cell
    }
    
    
    
}

extension poemList{
    
    func createRequest()->URLRequest?{
       
        var urlString = poemsURL.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        print(urlString as Any)
        guard let uniUrl = URL(string: urlString!) else {return nil}
      
        let request = NSURLRequest(url: uniUrl)
        return request as URLRequest
    }
    
    
    
    // to perform a session on any Task we need Request First -
    func performSession(){
        guard let myRequestIsValid = createRequest() else {return}
        let configure = URLSessionConfiguration.default
        let session = URLSession(configuration: configure)
   
        let task = session.dataTask(with: myRequestIsValid)
        task.delegate = self
        task.resume()
    }
    
    func parseData(_ data:Data){
        do {
            let decoder = JSONDecoder()
            poemArray = try decoder.decode([poemModel].self, from: data)
        }catch let error {
            print(error)
        }
     
        DispatchQueue.main.async {
            self.poemListTable.reloadData()
            self.poemListactivityIndicator.stopAnimating()
            self.poemListactivityIndicator.isHidden = true
        }
    }
    
    
}

extension poemList: URLSessionTaskDelegate,URLSessionDataDelegate{
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard error == nil else {
            return
        }
        parseData(apiResponseData)
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
//        if let string = String(bytes: data, encoding: .utf8) {
//           print(string)
//
//        } else {
//            print("not a valid UTF-8 sequence")
//        }
        
         self.apiResponseData.append(data)
     }
}

