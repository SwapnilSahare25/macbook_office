import UIKit
import Foundation

//var greeting = "Hello, playground"



class car {
    
    var names : String!
    init(names:String) {
        self.names=names
    }
}


class SUV : car {
    var color : String?
    //var model : String?
    
    init(color:String,names:String) {
        super.init(names:String)
    }
    
   
}

class Sedan : car {
    
}

class HatchBack : car {
    
}

class Company {
    var models : [car]
    
    init(){
    models = []
    }
}

class Mahindra:Company {
    override init() {
        super.init()
        let suv = SUV()
        self.models.append(suv)
        
        let sedan = Sedan(names: "Varito")
        self.models.append(sedan)
        
        let hatchback = HatchBack(names: "KUV")
        self.models.append(hatchback)
    }
}

class BMW:Company{
    
    override init() {
        super.init()
        let suv =SUV(
        self.models.append(suv)
        
        let sedan = Sedan(names: "BMW 3 series")
        self.models.append(sedan)
        
        let hatchback = HatchBack(names: "BMW 116i")
        self.models.append(hatchback)
        
    }
}


class Tata:Company{
    override init() {
        super.init()
        let suv = SUV(names: "Nexon")
        self.models.append(suv)
        
        let sedan = Sedan(names: "Tigor")
        self.models.append(sedan)
        
        let hatchback = HatchBack(names: "Tiago")
        self.models.append(hatchback)
    }
    
}

let mahindra = Mahindra()
for name in mahindra.models {
    print(name.names!)
}


let bmw = BMW()
for name in bmw.models {
    
    print(name.names!)
}

let tata = Tata()
for name in tata.models {
    print(name.names!)
}
