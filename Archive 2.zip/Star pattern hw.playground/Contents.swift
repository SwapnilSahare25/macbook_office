 import UIKit

var n = 5

for i in 0...5 {

    //print("S")

    for j in 1...i+1 {

        print("*",terminator: " ")

    }
    print("") //add new line to code
}

/*func uptothenum(n:Int){
    for i in 0...n {
        
        //print("S")
        
        for j in 1...i+1 {
            
            print("*",terminator: " ")
            
        }
        print("")
    }
  
}
uptothenum(n: 10)*/



//for i in 0...6 {
//
//    for j in i...1 {
//
//    }
//}



