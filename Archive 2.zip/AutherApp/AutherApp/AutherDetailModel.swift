//
//  AutherDetailModel.swift
//  AutherApp
//
//  Created by Bharat Silavat on 11/01/23.
//

import Foundation

struct AutherAchivement: Codable {
    
    var title: String?
    var author: String?
    var lines: [String]?
    var lineCount: String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.title, forKey: .title)
        try container.encodeIfPresent(self.author, forKey: .author)
        try container.encodeIfPresent(self.lines, forKey: .lines)
        try container.encodeIfPresent(self.lineCount, forKey: .lineCount)
    }
    enum CodingKeys: String, CodingKey {
        case title
        case author
        case lines
        case lineCount = "linecount"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.author = try container.decodeIfPresent(String.self, forKey: .author)
        self.lines = try container.decodeIfPresent([String].self, forKey: .lines)
        self.lineCount = try container.decodeIfPresent(String.self, forKey: .lineCount)
    }
    
}
