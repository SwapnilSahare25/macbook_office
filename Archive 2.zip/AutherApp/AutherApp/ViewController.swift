//
//  ViewController.swift
//  AutherApp
//
//  Created by Bharat Silavat on 11/01/23.
//

import UIKit

class ViewController: UIViewController,ConnectionManagerDelegate {
    
    var sendtitle: String = ""
    var api: String?
    var authersList: AuthersModel?
    let manager = ConnectionManager()
    var sendingQueryString : String = ""
    @IBOutlet weak var authersListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        authersListTableView.delegate = self
        authersListTableView.dataSource = self
        api = "https://poetrydb.org/author"
        manager.delegate = self
        manager.prepareForSession()
    }
    
    func didFinishTask(data: Data?, error: Error?) {
        guard error == nil else {return}
        guard let data = data else {return}
        do{
            authersList = try JSONDecoder().decode(AuthersModel?.self, from: data)
        }catch{
            print("Error : -\(error)")
        }
        DispatchQueue.main.async {
            self.authersListTableView.reloadData()
        }
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authersList?.authors?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "authersListCell", for: indexPath)
        let authers = authersList?.authors?[indexPath.row].description ?? ""
        sendingQueryString = authers.description
        sendtitle = authers
        cell.textLabel?.text = authers
        return cell
    }
}
extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "FirstVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "FirstVC" {
            var sendingQuery = sendingQueryString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            let vc = segue.destination as! AutherDetailViewController
            vc.title = sendtitle
            vc.query = "\(api!)/\(sendingQuery ?? "")"
        }
    }
    
}
