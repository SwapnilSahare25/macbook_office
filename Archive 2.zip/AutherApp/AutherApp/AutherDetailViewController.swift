//
//  AutherDetailViewController.swift
//  AutherApp
//
//  Created by Bharat Silavat on 11/01/23.
//

import UIKit

class AutherDetailViewController: UIViewController,ConnectionManagerDelegate {
    
    var sendingTitle : String = ""
    var api: String?
    var sendingData : [String] = []
    var query: String?
    var manager = ConnectionManager()
    var authersInfo : [AutherAchivement]?
    @IBOutlet weak var authersDetailTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        authersDetailTableView.delegate = self
        authersDetailTableView.dataSource = self
        api = query
        manager.delegate = self
        manager.prepareForSession()
    }
    
    func didFinishTask(data: Data?, error: Error?) {
        guard error == nil else {return}
        guard let data = data else {return}
        do{
            authersInfo = try JSONDecoder().decode([AutherAchivement]?.self, from: data)
        }catch{
            print("Error : -\(error)")
        }
        DispatchQueue.main.async {
            self.authersDetailTableView.reloadData()
        }
    }
}
extension AutherDetailViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return  authersInfo?[section].author?.description
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let trackInfo = authersInfo?[section].author else {return 0}
//        let authertrack = trackInfo
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "authersDetailCell", for: indexPath)
        guard let title = authersInfo?[indexPath.row].title else { return cell}
        guard let auther = authersInfo?[indexPath.row].author else { return cell}
        sendingTitle = auther
        cell.textLabel?.text = title
        cell.detailTextLabel?.text = auther
        sendingData = authersInfo?[indexPath.row].lines ?? []
        return cell
    }
}

extension AutherDetailViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "SecondVC", sender: self)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SecondVC" {
            let vc = segue.destination as! AuthersPoemViewController
            vc.receivindData = sendingData
            vc.poemName = sendingTitle
            
        }
    }
    
}
