//
//  AuthersPoemViewController.swift
//  AutherApp
//
//  Created by Bharat Silavat on 11/01/23.
//

import UIKit

class AuthersPoemViewController: UIViewController {
    
    var receivindData : [String]?
    var poemName : String?
    
    @IBOutlet weak var poemtitltLbl: UILabel!
    @IBOutlet weak var  lines : UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        poemtitltLbl.text = poemName
        lines.text = receivindData?.description
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
