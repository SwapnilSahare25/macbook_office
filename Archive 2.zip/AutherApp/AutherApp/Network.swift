//
//  Network.swift
//  AutherApp
//
//  Created by Bharat Silavat on 11/01/23.
//

import Foundation

protocol ConnectionManagerDelegate{
var api: String? {get set}
func didFinishTask(data: Data?, error: Error?)

}

class ConnectionManager {


var delegate : ConnectionManagerDelegate?

private let session =  URLSession.shared
var url : String?


init(delegate: ConnectionManagerDelegate? = nil, url: String? = nil) {
    self.delegate = delegate
    self.url = url
}


func prepareForSession(){
    
    guard let delegate = delegate, let api = delegate.api else { return }
    let url = api.utf16
    performTask("\(url)")
}

private func performTask(_ provideStringUrlHere : String){
    guard let url = URL(string: provideStringUrlHere) else { return }
    let request = URLRequest(url: url)
    
    let task = URLSession.shared.dataTask(with: request) { (data, responce, error) in
        
        guard let delegate = self.delegate else { return }
        delegate.didFinishTask(data: data, error: error)
        
    }
    task.resume()
    
}

}
