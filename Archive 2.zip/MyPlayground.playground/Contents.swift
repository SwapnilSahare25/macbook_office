import UIKit

/* 0 - 5 infant
 5 - 12 children
 12-19 teen
 19 - 30 youth
 30 - 45 middle
 45 - 60 senior old */

var greeting = "Hello, playground"

var a : Int = 54

a = 56
//optimised use

//let age = 60

/*if age >= 0 && age < 5 {
    print("infant")
    
} else if age >= 5 && age < 12 {
    print("children")
} else if age >= 12 && age < 19 {
    print("teen")
} else if age >= 19 && age < 30 {
    print("youth")
} else if age >= 30 && age < 45 {
    print("middle")
} else if age >= 45 && age < 60 {
    print("old")
}*/

/*if age < 5 {
    print("infant")
} else if age < 12 {
    print("child")
} else if age < 19 {
    print("teen")
} else if age < 30 {
    print("youth")
} else if age < 45 {
    print("old")
} else {
    print("senior")
}*/


// switch statement
/*switch age {
    
case 0 ..< 5 :
    print("infant")
    
case 5 ..< 12 :
    print("child")
    
case 12 ..< 19 :
    print("teen")
    
case 19 ..< 30 :
    print("youth")
    
case 30 ..< 45 :
    print("middle")
    
default :
    print("old")
}*/

var d = 45
var e = 60

if d >= e {
    print("equal")
} else{
    print("not equal")
}

var h = "it is good"

if h == "it" {
    print("contains")
}else {
    print("does not contains")
}




