import UIKit
import Foundation

var greeting = "Hello, playground"


var myArr = [12,3,5,67,4,6,65,34,54]

var k = 2

for i in 0..<myArr.count{
    
    for j in 0..<myArr.count {
        
        if myArr[i] < myArr[j]{
            var result = myArr[i]
            myArr[i] = myArr[j]
            myArr[j] = result
        }
    }
}
print(myArr[k])



func isBalanced(sequence: [Character]) -> Bool {
    var stack = [Character]()
    for bracket  in sequence {
        switch bracket {
        case "{", "[", "(":
            stack.append(bracket)
        case "}", "]", ")":
            if stack.isEmpty
                || (bracket == "}" && stack.last != "{")
                || (bracket == "]" && stack.last != "[")
                || (bracket == ")" && stack.last != "(")  {
                return false
            }
            stack.removeLast()
        default:
            fatalError("unknown bracket found")
        }
    }
    return stack.isEmpty
}

