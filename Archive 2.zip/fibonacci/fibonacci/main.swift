//
//  main.swift
//  fibonacci
//
//  Created by Swapnil Sahare on 18/11/22.
//

import Foundation

/*var a = 0
var b = 1

for i in 0 ... 10 {
    
    var c = a + b
    a = b
    b = c
    
    print(a)
}*/



print("Swapnil")

//variables

var a = "Swapnil Nagpur"

//print(a)

print(type(of: a))

a = "Rakesh"

print(a)


//Constants


let r = "nagpur city"
print(r)
print(type(of: r))

//Error

//r = "surat is city"

let c = 50
print(type(of: c))

let d = 576.78
print(type(of: d))

let s = 0.2345
print(type(of: s))


var myString = "Hello, World!";print(myString)

typealias Feet = Int

var distance : Feet = 100

print(distance)

typealias speed = Int
var road : speed = 120
print(road)

//var snum = 12
//var snum1 = 3.140

//var snum : String = "Mumbai"
//print(snum)

//var snum1 : Int = 342

//print(snum1)

//var snum3 : Float = 23
//print(snum3)

var snum = "Swapnil"
var snum1 = 25

print("My Friend \(snum) is \(snum1) years old")


let snum3 = "Nagpur"
let snum4 = 15

print("Mihaan is \(snum4) from \(snum3)")


// Optionals ?

//var i:?

var str : String? = nil

if str != nil {
    print(str)
}else {
    print("It is nil")
}


var myStr : Int? = 24

if myStr != nil {
    
    print(myStr!)
}else {
    print("It is nillll")
}

let myInt : Int? = 56

if myInt == nil {
    print(myStr)
}else {
    print("It is not nill")
}

let myFloat : Float? = 34.567

if myFloat != nil {
    print(myFloat!)
}else {
    print("it Does not contain any value")
}

// Force Unwrapping ?

var def : String?

def = "Nagpur"

if def != nil {
    print(def)
}else {
    print("it is nil")
}

//automatic unwrapping !

let myStr1 : Int!

myStr1 = 25
if myStr1 == nil {
    print(myStr1)
}else {
    print("\(myStr1) is nill")
}

// Optional Binding
// By if let

/* if let constantname = optionalname {
    condition
 }*/


var sstr : String?

sstr = "Mumbai"

if let yoursstr = sstr {
    print("\(yoursstr) is in Maharashtra")
}else {
    print("it is nill")
}

let abc : Int?

abc = nil

if let myabc = abc {
    print(myabc)
}else {
    print("it is nill")
}






