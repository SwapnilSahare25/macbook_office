//
//  ViewController.swift
//  Button+CornerRadiusExtensionGetSet
//
//  Created by Swapnil Sahare on 21/12/22.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //[Yesterday 5:58 pm] Bharat  Silavat
    override func viewDidLoad() {
            super.viewDidLoad()
        }
        
       override func viewWillAppear(_ animated: Bool) {
            
        }
        
       override func viewDidAppear(_ animated: Bool) {
            
        }
        
        override func viewWillDisappear(_ animated: Bool) {
            
        }
        
        override func viewDidDisappear(_ animated: Bool) {
            
        }
        
        lazy var table: UITableView = {
            let view = UITableView(frame: .zero, style: .plain)
            return view
        }()
        
        var fName: String = ""
        var lName: String = ""
        
        var fullName: String {
            set {
                let str = newValue
                let strArray = str.split(separator: " ")
                if strArray.count > 0 {
                    self.fName = String(strArray[0])
                }
                if strArray.count > 1 {
                    self.lName = String(strArray[1])
                }
            }
            
            get {
                return "\(fName) \(lName)"
            }
        }

   // [Yesterday 5:58 pm] Bharat  Silavat
     lazy var myDictArrey :[[[String:String]]] = {
            return [[["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]],[["E":"Akash"],["F":"Amit"],["G":"Amol"],["H":"Sameer"]]]
        }()
        




}

extension UIButton {

    var cornerRadius: CGFloat {

        set {

            self.layer.cornerRadius = newValue
        }

        get {

            return self.layer.cornerRadius
        }
    }

    func setDefaultValues() {

        self.layer.cornerRadius = 5.0

        self.layer.borderColor = UIColor.red.cgColor

        self.layer.borderWidth = 1.0
    }
}
