import UIKit

var greeting = "Hello, playground"

func multiply (a:Int,b:Int)->Int{
    let c = a*b
    return c
    
}
let multi = multiply(a: 34, b: 7)
print(multi)


enum shape {
    
    case circle
    case rectangle
    case triangle
    
}
func calculate(for type : shape, varArrey:[Float]?) -> Float {
    
    
    guard let arr = varArrey, arr.count > 0 else {
        return 0.0
    }
    let a = arr[0]
    var b : Float?
    
    switch type {
        
    case.circle:
        let radius = arr[0]
        
        return 3.141 * (radius * radius)
        
    case.rectangle:
        
        if arr.count>1 {
            
            b = arr[1]
            
        }
        if let b1 = b {
            
            return a * b1
        }
        return a * a

    case.triangle:
        
        if arr.count>1 {
            
            b = arr[1]
        }
        if let b1 = b {
            
            return 1/2 * a * b1
        }
        return 1/2 * a * a


    }
}
calculate(for: .rectangle, varArrey: [6,5])
calculate(for: .triangle, varArrey: [4])
calculate(for: .circle, varArrey: [4])



enum names {
    case fname
    case mname
    case lname
}
func names1(for type:names){
    switch type {
    case.fname:
        print("Good")
        
    case .mname:
        print("Today")
    case .lname:
        print("yesterday")
    }
}
let result = names1(for: .fname)
//print(result)

//names1(for: .lname)
let result2 = names1(for: .lname)


enum weatherType {
    
    case sun
    case rainy
    case cloud
    case cold
    case humidity
}
func weathers(weather:weatherType)->String{
    
    switch weather {
    case.sun:
        return "Its hot today"
    case.rainy:
        return "It will rain today"
    case.cold:
        return "It might be rain today"
    case.cloud:
        return "Clouds"
    default:
        return "nothing"
    }
}

let weatherDetails = weathers(weather: .humidity)

print(weatherDetails)

enum college {
    case collegeName
    case rollNumber
    case id
    
}

func details(for type:college){
    
    switch type{
    case.collegeName:
        print("PCE")
    case.rollNumber:
        print("151")
    case.id:
        print("2015")
    }
}
let totaldetails = details(for: .id)


