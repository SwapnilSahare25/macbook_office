import UIKit
import Foundation

var greeting = "Hello, playground"

var myDictArrey :[[[String:String]]] = [[["A":"Swapnil","B":"Sagar","C":"Suraj","D":"Shubham"],["E":"Akash","F":"Amit","G":"Amit","H":"Ashish"]],[["I":"Prashant","J":"Pranav","K":"Pravin","L":"Jahangir"],["M":"Shubham","N":"Ketan","O":"Komal","P":"Kavita"]],[["A":"Nagpur","B":"Mumbai","C":"Pune","D":"Nashik"],["1":"A","2":"B","3":"C","4":"D"]]]

print(myDictArrey)
print(type(of: myDictArrey))
