import UIKit
import Foundation
import PlaygroundSupport


//var greeting = "Hello, playground"

func track(buttonName:String,compiltionHandler: @escaping(Bool)->()){
    apiCall(handler: compiltionHandler)
    
}

func apiCall(handler:@escaping(Bool)->()){
    print("Api request Started")
    PlaygroundPage.current.needsIndefiniteExecution = true
    DispatchQueue.main.asyncAfter(deadline: .now() + 3){
        handler(true)
    }
}
//print("scope finished")
//handler()

track(buttonName: "Skip") { isSuccess in // handler code
    if isSuccess{
        print("track Skip Complete")
    }else{
        print("track skip failed")
    }
}

class X : NSObject{
    
    var a : String? // for unwrapping
    
    func abc (){
        let y = Y()
        y.closer {[weak self] in // ??
            guard let strongSelf = self else{
                return
            }
            strongSelf.a = "done"
            print(strongSelf.a ?? "abc")
        }
    }
}

class Y : NSObject {
    
    func closer(handler:@escaping()->()){
     PlaygroundPage.current.needsIndefiniteExecution = true
     DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
     handler()

        }
    }
}
let x = X()
x.abc()

// do it without @escaping,weaks self


// self = -> { use in this scope}
//return =-> {use in this scope}



