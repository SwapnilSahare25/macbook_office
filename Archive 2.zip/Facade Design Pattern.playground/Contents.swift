import UIKit

var greeting = "Hello, playground"

class Engine {
    func produceEngine(){
        print("produce Engine")
    }
}
class Body {
    func produceBody(){
        print("produce Body")
    }
}
class Accessories {
    
    func produceAccessories(){
        print("produce accessories")
    }
}

class FactoryFacade {
    let engine = Engine()
    let body = Body()
    let accessories = Accessories()
    
    func produceCar(){
        engine.produceEngine()
        body.produceBody()
        accessories.produceAccessories()
    }
}
let carFactory = FactoryFacade()
carFactory.produceCar()
