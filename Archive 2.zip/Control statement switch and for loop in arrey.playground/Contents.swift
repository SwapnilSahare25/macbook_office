import UIKit

/* 0 - 5 infant
 5 - 12 children
 12-19 teen
 19 - 30 youth
 30 - 45 middle
 45 - 60 senior old */


var greeting = "Hello, playground"

// control statement

// for loop

let arrey = [4,23,52,63,17,34,55]

for i in arrey {
    switch i {
        case 0..<5:
            print("infant")
        case 5..<12:
            print("child")
        case 12..<19 :
            print("teen")
        case 19..<30:
            print("youth")
        case 30..<45:
            print("middle")
        default :
            print("old")
    }
}


var data = [12.34,65.465,83.346,73.845,12.934,34.80,45,85]

for num in data {
    switch num {
    case 0..<15 :
        print("1")
    case 15..<30 :
        print("2")
    case 30..<45 :
        print("3")
    case 45..<60 :
        print("4")
    case 60..<100 :
        print("5")
    default :
        print("any")
    }
}


var a = 65

switch a {
    
case 0..<15 :
    
    print("less")
    
case 15..<30 :
    
    print("equal")
    
case 30..<45 :
    
    print("more")
    
case 45..<60 :
    
    print("good")
    
default :
    
    print("not given")
}


var num = 56

switch num {
    
case 0..<20 :
    print("less")
    
case 20..<30 :
    print("equal")
    
case 30..<40 :
    print("more")
    
default :
    print("None")
}



