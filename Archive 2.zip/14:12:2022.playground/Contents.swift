import UIKit

var greeting = "Hello, playground"

var myDictArrey :[[[String:String]]] = [[["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]],[["E":"Akash"],["F":"Amit"],["G":"Amol"],["H":"Sameer"]]]

//print(myDictArrey)
//print(type(of: myDictArrey))


var mydictArrey2:[String] = Array()

for item in myDictArrey {
    //print(item)

    for (key) in item {
        
        //print(key)
        for j in key {
            print(j)
            mydictArrey2.append(j.key)
            mydictArrey2.append(j.value)
            print(mydictArrey2)
        }
        
        
    }
}
print(mydictArrey2)


