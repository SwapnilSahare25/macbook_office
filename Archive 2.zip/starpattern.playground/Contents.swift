import UIKit
//
//var greeting = "Hello, playground"
//
////var c = 6
////for i in 0...6{
////
////    for j in 1...i{
////
////        print("S",terminator: " ")
////    }
////    print("A")
////}
//
////var sum:[Int] = []
////
////
////
////for i in 0...2 {
////    var a = 10
////    var b = 12
////    var c = a+b
////    sum.append(c)
////    //print(sum)
////
////}
////print(sum)
////
////
////var table:[Int] = []
////var n = 2
////var result = 0
////
////for i in 0...10 {
////    result = n*i
////    table.append(result)
////}
////print(table)
//
//
//var n = 5
//
//for i in 0..<n {
//
//    for j in 0..<n-i {
//
//        print("*",terminator: " ")
//
//    }
//    print("")
//}
//
//var ab : [Int] = [0,1,2,3,4]
//ab.append(5)
//

var arrey:[Int] = [3,5,6,9,10,1,4]

var c = arrey.count
//var c:Int = 0

for i in 0..<c-1{

    for j in 1..<c {

        if arrey[j-1]>arrey[j] {
            let temp = arrey[j-1]
            arrey[j-1] = arrey[j]
            arrey[j] = temp
            
        }
    }
    print(i)
}
print(arrey)

var a = [1,4,6,8,2,4,3,6,]

var d = a.count

for i in 0..<d-1 {
    
    for j in 1..<d {
        
        if a[j-1]>a[j] {
            
            let f = a[j-1]
            
            a[j-1]=a[j]
            
            a[j]=f
        }
    }
}
print(a)

var namearrey = ["bisen","samir","ashok","raj"]

for i in 0..<namearrey.count-1 {
    
    for j in 1..<namearrey.count {
        
        if namearrey[j-1]>namearrey[j] {
            
            let varC = namearrey[j-1]
            
            namearrey[j-1]=namearrey[j]
            
            namearrey[j]=varC
        }
    }
}
print(namearrey)

var flarr = [23.23,41.32,12.23,11.23,34.21]

for i in 0..<flarr.count-1 {
    
    for j in 1..<flarr.count {
        
        if flarr[j-1]>flarr[j] {
            
            var varZ = flarr[j-1]
            flarr[j-1] = flarr[j]
            flarr[j] = varZ
        }
    }
    print(i)
}
print(flarr)

//creat an empty arrey

var arrey3 :[Int] = []
var arrey2 : Array<Int> = Array()

// create arrey of repeated elements

var digitcount = Array(repeatElement(12, count: 10))

print(digitcount)

//Access value in arrey

let names = ["Albemarle", "Brandywine", "Chesapeake","Road","Beach","House"]

for name in names {
    
    print("The name is \(name)")
}

//isEmpty

let oddNum = [1,3,5,7,9,11]

if oddNum.isEmpty {
    print("The arrey is empty")
}else {
    print("arrey is not \(oddNum.count) empty")
}


let ar = [2,4,5,6,6,7,8,9,0,1,23,23,45,12,34]

var Ac = ar.count
print(Ac)

for i in 0..<Ac-1 {
    print(Ac)
}




