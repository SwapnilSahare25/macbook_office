import UIKit

var greeting = "Hello, playground"

var a = 5

for i in 0..<a {
    
    for j in 0...i {
        
        print("*", terminator: " ")
    }
    print("")
}

var b = 5

for i in 0...b{
    
    for j in 0..<b-i {
        
        print("8",terminator: " ")
    }
    print("")
}

//var Ac = 5
//
//for i in 0...5 {
//    
//    for j in ...i{
//        
//        print("*",terminator: " ")
//    }
//    print("")
//}


