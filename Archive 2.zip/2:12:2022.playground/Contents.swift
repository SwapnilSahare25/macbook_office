import UIKit
import Foundation

var greeting = "Hello, playground"

//[6:13 pm] Bharat  Silavat
//completion block

//(closure) - it is like variable and it can be optional
//
//(no parameter)->(no return)  - default closure
//
//closure  -
//to pass function as a parameter in class or another function

//*/

func track( buttonName: String, completionHandler: @escaping(Bool)->()){
    apiCall(handler: completionHandler)
}

func apiCall( handler: @escaping(Bool)->()) {
    // make api call which will take 3 sec
    print("api request started")
    PlaygroundPage.current.needsIndefiniteExecution = true
    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
        handler(false)
    }
//    for i in 0..<100 {
//        print(i+1)
//    }
    print("scope finished")
//    handler()
}

track(buttonName: "skip") { (isSucces) in
    
    if isSucces {
        print("track skip complete")
    } else {
        print("track skip failed")
    }

}

//[6:14 pm] Bharat  Silavat
class X: NSObject {
    
    var a: String?
    
    func abc() {
        let y = Y()
        y.closure { [weak self] in
            guard let strongSelf = self else {
                return
            }
            strongSelf.a = "done"
            print(strongSelf.a ?? "abc")
        }
    }
}

class Y: NSObject {
    
    func closure(handler: @escaping ()->()) {
        PlaygroundPage.current.needsIndefiniteExecution = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            handler()
        }
    }
}
let x = X()
x.abc()


