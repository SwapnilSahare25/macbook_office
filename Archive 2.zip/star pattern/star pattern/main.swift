//
//  main.swift
//  star pattern
//
//  Created by Swapnil Sahare on 23/11/22.
//

import Foundation

print("Hello, World!")



