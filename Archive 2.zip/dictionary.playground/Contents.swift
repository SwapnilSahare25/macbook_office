import UIKit
import Foundation

var greeting = "Hello, playground"

let dict1:[Int:[String]] = [ 1:["karthik","Akshay","Chand"], 2:["chandu","Akash","Raj"], 3:["nandu","Rahul","Samir"]]

for key in dict1 {
    
    print("\(key)")
}

let keys = Array(dict1.keys)
print(keys)

let values = dict1[1]
print(values!)

let value2 = dict1[2]
print(value2!)

let value3 = dict1[3]
print(value3!)
