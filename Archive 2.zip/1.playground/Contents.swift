import UIKit

//var greeting = "Hello, playground"

//var a:Int
//var b:Int
//func add(a:Int,b:Int)->Int {
//
//    let sum = a+b
//    return sum
//
//}
//let c = add(a: 4, b: 5)
//print(c)
//
//
//func days(year:Int,month:Int,day:Int)->Int{
//
//    let days = year * month * day
//    return days
//}
//days(year: 16, month: 12, day: 30)
//
//
//func areaoftriangle (base :Int,height : Int) -> Int{
//
//    let area = base*height/2
//    return area
//
//}
//let area = areaoftriangle(base: 10, height: 15)
//print(area)
//
//func integer(a:Int)-> Int{
//
//    let A = a + 1
//    return A
//}
//var result = integer(a: 12)
//print(result)
//
//func mintoseconds(min:Int,sec:Int)->Int{
//
//    let multiply = min*sec
//    return multiply
//
//}
//let e = mintoseconds(min: 12, sec: 60)
//print(e)
//
//func equalornot (a:Int){
//
//    if (a <= 0) {
//        print("true")
//    }else {
//        print("False")
//    }
//}
//equalornot(a:0)
//
//func reminder (a:Int,b:Int)->Int{
//
//    let reminder = a%b
//    return reminder
//
//}
//reminder(a: 9, b: 10)
//
//
//func addstring(a:String)->String {
//    var b = "Edabit"
//
//    let addresult = a+b
//    return addresult
//}
//let store = addstring(a: "Swapnil")
//print(store)
//
//func cube (a:Int)->Int{
//
//    let s = a*a*a
//    return s
//}
//cube(a: 2)
//
//var varA = 0
//var varM = 0
//func singlenumber(a:Int)->Int{
//        for i in 0...a-1 {
//        varA = a - i
//        varM += varA
//    }
//    return varM
//}
//let pri = singlenumber(a: 6)
//print(pri)
//
//
//func matchsteps(cv:Int)->Int{
//
//    let varG = cv*5 + 1
//    //var varH = varG + 1
//    return varG
//}
//let sum = matchsteps(cv: 8)
//print(sum)
//
//func primenumber(a:Int){
//
//    if (a%a == 0 && a%1 == 0){
//
//        print("it is prime")
//    }else{
//        print("not prime")
//    }
//}
//let prime = primenumber(a: 9)
//print(prime)
//
//
////func shiftoperator(a:Int,b:Int) ->Int {
////    let sum = a * (2)
////    return sum
////}
////shiftoperator(a: 4, b: 4)
//
//var numbers = [5,6,8,11,99,66,45]
//
//var range = numbers.count
//
////var min = numbers[0]
////var max = numbers.last
//
//var emptyarrey:[Int] = []
//var temp = 0
//for i in 0...range {
//
//    for j in 1...range-1 {
//
//        if (numbers[j]<numbers[j-1]){
//
//          temp = numbers[j-1]
//
//           numbers[j-1] = numbers[j]
//
//           numbers[j] = temp
//        }
//    }
//
//}
//
//print(numbers[0],numbers.last!)
//
//func cookies (day:Int,month:Int)->Bool{
//
//    if (day==24 && month == 12){
//        return true
//    }else {
//        return false
//    }
//}
//let add = cookies(day: 23, month: 12)
//print(add)
//
//func whichislarger(f:()->Int,g:()->Int)->String{
//    //let varAB = f()
//    //let varAC = g()
//    func f()->String{
//        return "f"
//    }
//
//    func g()->String{
//        return "g"
//    }
//
//    if f() > g() {
//        print("f")
//    } else {
//            print("neither")
//        }
//    return ""
//    }
////whichislarger(f:()->12, g:()->14)


class Vehicle {
    func engine (){
        print("main engine")
    }
    func chesis(){
        print("main chesis")
    }
}
class Car : Vehicle {

}
let m = Car()
var n = m.chesis()
//print(n)

class Bus : Vehicle {

    override func engine() {
        
        print("Engine")
    }
}

let g = Bus()
var varBus = g.engine()



