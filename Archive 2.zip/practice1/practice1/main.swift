//
//  main.swift
//  practice1
//
//  Created by Swapnil Sahare on 21/11/22.
//

import Foundation

print("Hello, World!")


var a = 12

if a > 23 {
    print("it is a less number")
    
}else {
    print("it is not")
}

var b = "Hello WORLD"
var result = String(b.reversed())
print("reversed string \(result)")

var varA = "Swapnil"
let varB = 12
var varC = 12.68

print("\(varA) is \(varB) and \(varC * 10)" )

var d = "Nagpur City"

print(d.count)


var f = "Swift Language"
var g = "Nagpur City"

if f != g {
    print("var \(f) and var \(g) are equal")
    }else {
    print("var \(f) and var \(g) are not equal")
}
//string iterator

for name in "SwapnilSahare" {
    print(name ,terminator: " ")
}

// arrey

var str = [String]()

str.append("Apple")
str.append("Banana")
str.append("Books")

print(str)

for s in str {
    print(s)
}


var myarrey = [String]()

myarrey.append("table")
myarrey.append("Tv")
myarrey.append("Chair")

print(myarrey)
print(type(of: myarrey))

for (index,item) in myarrey.enumerated(){
    print("value of index is \(index) of \(item)")
}

var asa : [Int] = [1,2,3,4,5]
var bsa : [Int] = [6,7,9,10]

var csa = asa + bsa
print(csa)

var cities = ["Mumbai","Pune","banglore"]

var distance = [8300,1000,1200]

var addboth = Dictionary(uniqueKeysWithValues: zip(cities, distance))

print(addboth)

var name : [String] = ["Swapnil","Ajay","Rakesh","Rajesh"]
var age : [Int] = [24,35,26,27]

var addnameandage = Dictionary(uniqueKeysWithValues: zip(name, age))

print(addnameandage)

print(type(of: addnameandage))


