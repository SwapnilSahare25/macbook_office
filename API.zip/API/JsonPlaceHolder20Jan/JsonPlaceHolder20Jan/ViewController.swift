//
//  ViewController.swift
//  JsonPlaceHolder20Jan
//
//  Created by Swapnil Sahare on 20/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

