var json: Any?
        if let path = Bundle.main.path(forResource: "TimerApi", ofType: "json") {
            do {
                let fileUrl = URL(fileURLWithPath: path)
                // Getting data from JSON file using the file URL
                let data = try Data(contentsOf: fileUrl, options: .mappedIfSafe)
                json = try? JSONSerialization.jsonObject(with: data)
                
                print(json)
                
            } catch {
                // Handle error here
            }
        }
