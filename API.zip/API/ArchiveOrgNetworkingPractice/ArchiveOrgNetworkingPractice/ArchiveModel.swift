//
//  ArchiveModel.swift
//  ArchiveOrgNetworkingPractice
//
//  Created by Swapnil Sahare on 09/01/23.
//

import Foundation

struct Archive {
    var created : Int16?
    var d1 : String?
    var 
}
