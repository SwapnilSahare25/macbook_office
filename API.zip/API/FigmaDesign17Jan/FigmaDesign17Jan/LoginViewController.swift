//
//  LoginViewController.swift
//  FigmaDesign17Jan
//
//  Created by Swapnil Sahare on 18/01/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var textFieldView : UIView!
    @IBOutlet weak var emailTextField : UITextField!
    @IBOutlet weak var passwordTextField : UITextField!
    @IBOutlet weak var singINButton : UIButton!
    
    var email : String = ""             // step 9
    var password : String = ""           // step 10
    override func viewDidLoad() {
        super.viewDidLoad()
        self.singINButton.isEnabled = false
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func signINClicked(){
        let connection = ConnectionManager(delegate: self)      // use init for this in connection manager
        connection.login(with: ["user":self.email,"password":self.password])       //step 15
    }

}
extension LoginViewController : ConnectionManagerDelegate {       //step 11
    func didFinishedTask(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else {return}
     //     print(data)
            do{
                let str = String(data:data,encoding: .utf8)
                print("response\(str!)")
            }catch {
                print("Error \(error)")
            }
        }
    }
    
    
}
extension LoginViewController : UITextFieldDelegate {                    // step 12
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.emailTextField {
            self.email = textField.text ?? ""
        }
        if textField == self.passwordTextField {
            self.password = textField.text ?? ""
        }
        if self.email.isValidEmail() && self.password.count > 5 {           // step 14
            self.singINButton.isEnabled = true
        }
    }
}
extension String {                          // step 13
    func isValidEmail() -> Bool {
           // here, `try!` will always succeed because the pattern is valid
           let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
           return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
       }
}
