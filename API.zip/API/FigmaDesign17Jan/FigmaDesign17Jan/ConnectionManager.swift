//
//  ConnectionManager.swift
//  FigmaDesign17Jan
//
//  Created by Swapnil Sahare on 18/01/23.
//

import Foundation

protocol ConnectionManagerDelegate{        // step 2
    func didFinishedTask(data : Data?,error : Error?) // step 3
}

class ConnectionManager{  // step 1
    
    
    var delegate : ConnectionManagerDelegate?   // step 4
    
    init(delegate: ConnectionManagerDelegate? = nil) {               // step 5
        self.delegate = delegate
    }
    
    
    func login(with loginDict : [String:String]){                    // step 6
        let url = "http://testurapp.com/iostesting/login.php"
        performTask(_provideStringUrlHere: url,params:loginDict)       // step 8
    }
    
    private func performTask(_provideStringUrlHere : String, params : [String:String]?=nil){  // step 7
        guard let url = URL(string: _provideStringUrlHere) else {return}
        var request = URLRequest(url: url)
        
        if params == params {
            do{
                request.httpBody = try JSONEncoder().encode(params)
                request.httpMethod = "POST"
            }catch let error{
                print(error)
            }
        }
        let task = URLSession.shared.dataTask(with: request) { (data, responce, error) in
            guard let delegate = self.delegate else {return}
            delegate.didFinishedTask(data: data, error: error)
        }
        task.resume()
    }
    
}
