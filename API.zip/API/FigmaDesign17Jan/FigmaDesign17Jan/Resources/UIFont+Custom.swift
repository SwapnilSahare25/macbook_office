//
//  UIFont+Custom.swift
//  FigmaDesign17Jan
//
//  Created by Swapnil Sahare on 17/01/23.
//

import Foundation
import UIKit


extension UIFont {
    func groteskBold ( with size : CGFloat) -> UIFont? {
        return UIFont(name: "HKGrotesk-Bold", size: size)
    }
}
