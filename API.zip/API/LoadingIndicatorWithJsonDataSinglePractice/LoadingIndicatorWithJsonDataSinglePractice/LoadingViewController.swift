//
//  LoadingViewController.swift
//  LoadingIndicatorWithJsonDataSinglePractice
//
//  Created by Swapnil Sahare on 02/01/23.
//

import UIKit

class LoadingViewController: UIViewController {
    
    
  //step 7
    @IBOutlet weak var loadingIndicator : UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    // step 8
    override func viewDidAppear(_ animated: Bool) {
        loadingIndicator.startAnimating()
    }
    
    // step 9
    override func viewDidDisappear(_ animated: Bool) {
        loadingIndicator.stopAnimating()
    }
}

// step 10
extension UIViewController {
    
    func showLoading() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loadingVc = storyBoard.instantiateViewController(withIdentifier: "LoadingViewController")
        loadingVc.view.tag = 100
        loadingVc.view.frame = self.view.bounds
        self.view.addSubview(loadingVc.view)
    }
    
    func removeLoading() {
        let views = self.view.subviews.filter({ $0.tag == 100 })
        if views.count > 0 {
            let view = views[0]
            view.removeFromSuperview()
        }
    }
}
