//
//  Json.swift
//  LoadingIndicatorWithJsonDataSinglePractice
//
//  Created by Swapnil Sahare on 02/01/23.
//

import Foundation

struct ProPublica : Codable {
    var totalResults : Int?
    var organizations : [Organizations]?
    var numPages : Int?
    var curPage : Int?
    var pageOffset : Int?
    var perPage : Int?
    var searchQuery : String?
    var selectedState : String?
    var selectedNtee : String?
    var selectedCode : String?
    var dataSource : String?
    var apiVersion : Int?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.totalResults, forKey: .totalResults)
        try container.encodeIfPresent(self.organizations, forKey: .organizations)
        try container.encodeIfPresent(self.numPages, forKey: .numPages)
        try container.encodeIfPresent(self.curPage, forKey: .curPage)
        try container.encodeIfPresent(self.pageOffset, forKey: .pageOffset)
        try container.encodeIfPresent(self.perPage, forKey: .perPage)
        try container.encodeIfPresent(self.searchQuery, forKey: .searchQuery)
        try container.encodeIfPresent(self.selectedState, forKey: .selectedState)
        try container.encodeIfPresent(self.selectedNtee, forKey: .selectedNtee)
        try container.encodeIfPresent(self.selectedCode, forKey: .selectedCode)
        try container.encodeIfPresent(self.dataSource, forKey: .dataSource)
        try container.encodeIfPresent(self.apiVersion, forKey: .apiVersion)
    }
    enum CodingKeys: String, CodingKey {
        case totalResults = "total_results"
        case organizations
        case numPages = "num_pages"
        case curPage = "cur_page"
        case pageOffset = "page_offset"
        case perPage = "per_page"
        case searchQuery = "search_query"
        case selectedState = "selected_state"
        case selectedNtee = "selected_ntee"
        case selectedCode = "selected_code"
        case dataSource = "data_source"
        case apiVersion = "api_version"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.totalResults = try container.decodeIfPresent(Int.self, forKey: .totalResults)
        self.organizations = try container.decodeIfPresent([Organizations].self, forKey: .organizations)
        self.numPages = try container.decodeIfPresent(Int.self, forKey: .numPages)
        self.curPage = try container.decodeIfPresent(Int.self, forKey: .curPage)
        self.pageOffset = try container.decodeIfPresent(Int.self, forKey: .pageOffset)
        self.perPage = try container.decodeIfPresent(Int.self, forKey: .perPage)
        self.searchQuery = try container.decodeIfPresent(String.self, forKey: .searchQuery)
        self.selectedState = try container.decodeIfPresent(String.self, forKey: .selectedState)
        self.selectedNtee = try container.decodeIfPresent(String.self, forKey: .selectedNtee)
        self.selectedCode = try container.decodeIfPresent(String.self, forKey: .selectedCode)
        self.dataSource = try container.decodeIfPresent(String.self, forKey: .dataSource)
        self.apiVersion = try container.decodeIfPresent(Int.self, forKey: .apiVersion)
    }
}
struct Organizations : Codable {
    var ein : Int?
    var strein : String?
    var name : String?
    var subName : String?
    var city : String?
    var state : String?
    var nteeCode : String?
    var rawNteeCode : String?
    var subseccd : Int?
    var hasSubseccd : Bool?
    var haveFilings : Bool?
    var haveExtracts : Bool?
    var havePdfs : Bool?
    var score : Float?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.ein, forKey: .ein)
        try container.encodeIfPresent(self.strein, forKey: .strein)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.subName, forKey: .subName)
        try container.encodeIfPresent(self.city, forKey: .city)
        try container.encodeIfPresent(self.state, forKey: .state)
        try container.encodeIfPresent(self.nteeCode, forKey: .nteeCode)
        try container.encodeIfPresent(self.rawNteeCode, forKey: .rawNteeCode)
        try container.encodeIfPresent(self.subseccd, forKey: .subseccd)
        try container.encodeIfPresent(self.hasSubseccd, forKey: .hasSubseccd)
        try container.encodeIfPresent(self.haveFilings, forKey: .haveFilings)
        try container.encodeIfPresent(self.haveExtracts, forKey: .haveExtracts)
        try container.encodeIfPresent(self.havePdfs, forKey: .havePdfs)
        try container.encodeIfPresent(self.score, forKey: .score)
    }
    enum CodingKeys: String,CodingKey {
        case ein
        case strein
        case name
        case subName = "sub_name"
        case city
        case state
        case nteeCode = "ntee_code"
        case rawNteeCode = "raw_ntee_code"
        case subseccd
        case hasSubseccd = "has_subseccd"
        case haveFilings = "have_filings"
        case haveExtracts = "have_extracts"
        case havePdfs = "have_pdfs"
        case score
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.ein = try container.decodeIfPresent(Int.self, forKey: .ein)
        self.strein = try container.decodeIfPresent(String.self, forKey: .strein)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.subName = try container.decodeIfPresent(String.self, forKey: .subName)
        self.city = try container.decodeIfPresent(String.self, forKey: .city)
        self.state = try container.decodeIfPresent(String.self, forKey: .state)
        self.nteeCode = try container.decodeIfPresent(String.self, forKey: .nteeCode)
        self.rawNteeCode = try container.decodeIfPresent(String.self, forKey: .rawNteeCode)
        self.subseccd = try container.decodeIfPresent(Int.self, forKey: .subseccd)
        self.hasSubseccd = try container.decodeIfPresent(Bool.self, forKey: .hasSubseccd)
        self.haveFilings = try container.decodeIfPresent(Bool.self, forKey: .haveFilings)
        self.haveExtracts = try container.decodeIfPresent(Bool.self, forKey: .haveExtracts)
        self.havePdfs = try container.decodeIfPresent(Bool.self, forKey: .havePdfs)
        self.score = try container.decodeIfPresent(Float.self, forKey: .score)
    }
}
