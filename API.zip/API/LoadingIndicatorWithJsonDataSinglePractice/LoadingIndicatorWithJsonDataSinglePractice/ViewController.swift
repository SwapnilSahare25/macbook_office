//
//  ViewController.swift
//  LoadingIndicatorWithJsonDataSinglePractice
//
//  Created by Swapnil Sahare on 02/01/23.
//

import UIKit

class ViewController: UIViewController  {
   
    // step 6
    var apiArrey : [API] = [.proPublica]
    
    @IBOutlet weak var proPublicaTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        proPublicaTableView.delegate = self
        proPublicaTableView.dataSource = self
        // Do any additional setup after loading the view.
    }


}
// step 7
extension ViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apiArrey.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = proPublicaTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let apiType : API = apiArrey[indexPath.row]
        cell.textLabel?.text = apiType.rawValue
        return cell
    }

// step 8
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let apiValue : API = apiArrey[indexPath.row]
        
        switch(apiValue){
        case .proPublica :
            self.performSegue(withIdentifier: "ProPublicaViewController", sender: apiValue)
        }
    }

// step 9
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier?.hasSuffix("Controller") == true {
            guard let api : API = sender as? API else {return}
            
            var targetVC = segue.destination as? ConnectionDelegate
            targetVC?.api = api
        }
    }
    
}
