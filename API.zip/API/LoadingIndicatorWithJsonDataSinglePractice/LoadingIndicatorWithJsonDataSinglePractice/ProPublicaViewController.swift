//
//  ProPublicaViewController.swift
//  LoadingIndicatorWithJsonDataSinglePractice
//
//  Created by Swapnil Sahare on 02/01/23.
//

import UIKit
 // step 11
class ProPublicaViewController: UIViewController , ConnectionDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        
  // step 15
        DispatchQueue.main.async {
            self.removeLoading()
        }
        // step 14
        if error == nil {
            guard let data = data else {return}
            let text = String(data: data, encoding: .utf8)
            DispatchQueue.main.async {
                self.proPublicaTextView.text = text
            }
        }
    }
    
    
    @IBOutlet weak var proPublicaTextView : UITextView!
    
    // step 12
    let connection = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
// step 13
        connection.delegate = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
// step 14
    override func viewDidAppear(_ animated: Bool) {
        self.showLoading()
        self.connection.startSession()
    }
}
