//
//  ConnectionAndNetworking.swift
//  LoadingIndicatorWithJsonDataSinglePractice
//
//  Created by Swapnil Sahare on 02/01/23.
//

import Foundation
//step 3
protocol ConnectionDelegate {
    var api : API? { get set }
    
    func didFinishedTaskWithResponse(data : Data? , error : Error?)
}

//step 2
enum API : String {
    case proPublica = "https://projects.propublica.org/nonprofits/api/v2/search.json?order=revenue&sort_order=desc"
}

// step 1
class ConnectionManager {
    
    // step 4
    var delegate : ConnectionDelegate?
    
    // step 6
    func startSession() {
        guard let delegate = self.delegate else {return}
        let api = delegate.api
        let url = api?.rawValue
        self.startTask(url!)
    }
    //step 5
    func startTask(_ url : String) {
        guard let myUrl = URL(string: url) else {return}
        let request = URLRequest(url: myUrl)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {return}
            delegate.didFinishedTaskWithResponse(data: data, error: error)
        }
        dataTask.resume()
    }
}
