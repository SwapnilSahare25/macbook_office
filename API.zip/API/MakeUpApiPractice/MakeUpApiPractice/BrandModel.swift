//
//  BrandModel.swift
//  MakeUpApiPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import Foundation

struct Brand : Codable {
    var brandArray : [String]?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.brandArray, forKey: .brandArray)
    }
    enum CodingKeys: CodingKey {
        case brandArray
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.brandArray = try container.decodeIfPresent([String].self, forKey: .brandArray)
    }
}
