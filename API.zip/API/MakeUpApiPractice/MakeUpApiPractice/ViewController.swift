//
//  ViewController.swift
//  MakeUpApiPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import UIKit

class ViewController: UIViewController ,ConnectionDelegate {
    var api: API?
    
    func didFishishedTaskWithResponse(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else {return}
            do{
                self.brand = try JSONDecoder().decode(Brand.self, from: data)
                //print(brandArrey)
            }catch let error {
                print(error)
            }
            DispatchQueue.main.async {
                self.brandTableView.reloadData()
            }
        }
    }
    
    var brand : Brand?
    let connection = ConnectionManager()
    @IBOutlet weak var brandTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        api = .makeup
        connection.delegate = self
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        connection.startSession()
    }


}

extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return brand?.brandArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = brandTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let brandData = brand?.brandArray![indexPath.row]
        print(brandData)
        cell.textLabel?.text = brandData
        return cell
    }
    
    
}
