//
//  Network.swift
//  MakeUpApiPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import Foundation
protocol ConnectionDelegate {
    var api : API? { get set }
    func didFishishedTaskWithResponse(data : Data?,error : Error?)
}

enum API : String {
    case makeup = "https://makeup-api.herokuapp.com/api/v1/products.json"
}
class ConnectionManager {
    var delegate : ConnectionDelegate?
    
    func startSession(){
       guard let delegate = self.delegate,
             let api = delegate.api else {return}
        let url = api.rawValue
        self.startSession(url)
    }
    func startSession(_ url : String){
        guard let url = URL(string: url) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {return}
            delegate.didFishishedTaskWithResponse(data: data, error: error)
        }
        dataTask.resume()
    }
    
}

