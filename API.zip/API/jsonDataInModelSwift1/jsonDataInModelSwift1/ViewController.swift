//
//  ViewController.swift
//  jsonDataInModelSwift1
//
//  Created by Swapnil Sahare on 28/12/22.
//

import UIKit

struct Response : Codable {
    
    var timerapis : TimerApi
    
    enum timerApiKeys : CodingKey {
        
        case timerapis
    }
}

class ViewController: UIViewController {

    var response : Response?
    
    var myTimerApi : TimerApi?
    
    @IBOutlet weak var myTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        guard let urlPath = Bundle.main.url(forResource: "TimerApi", withExtension: "json") else { return }
         
        do {
            let data = try Data(contentsOf: urlPath)
            let decoder = JSONDecoder()
            response = try decoder.decode(Response.self, from: data)
            myTimerApi = response?.timerapis
            
            print(myTimerApi)
        } catch let error  {
            print(error)
        }
    }


}
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.myTimerApi?.dataseries?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        guard let timer = myTimerApi else {return cell}
        cell.textLabel?.text = timer.dataseries?[indexPath.row].
        cell.detailTextLabel?.text = timer.dataseries?[indexPath.row].rh2m
        return cell
    }
    
    
}
