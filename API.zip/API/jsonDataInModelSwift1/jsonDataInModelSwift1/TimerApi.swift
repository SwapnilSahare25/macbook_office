//
//  TimerApi.swift
//  jsonDataInModelSwift1
//
//  Created by Swapnil Sahare on 28/12/22.
//

import Foundation


// step 1


struct TimerApi:Codable {
    
    var product : String?
    var init1 : String?
    var dataseries : [DataSeries]?
    
    // step 3
    func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(product, forKey: .product)
        try container.encode(init1, forKey: .init1)
//        try container.encode(dataseries, forKey: .dataseries)
        
    }
    // step 4
     init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.product = try values.decode(String.self, forKey: .product)
        self.init1 = try values.decode(String.self, forKey: .init1)
        self.dataseries = try values.decode(Array<DataSeries>.self, forKey: .dataseries)
        
    }
    // step optional if want to change name
    enum CodingKeys : String , CodingKey {
        case product
        case init1
        case dataseries
    }
    
}
// if contain any arrey of dict or dict in api key then step 2 is this
// subclass of arrey of dict in timerapi
struct DataSeries : Codable {
    
    var timePoint : Int?
    var cloudCover : Int?
    var seeing : Int?
    var transparency : Int?
    var liftedIndex : Int?
    var rh2m : Int?
    var wind2m : Wind10m
    var temp2m : Int?
    var precType : String?
    
    
    func encode(to encoder:Encoder) throws {
        var container1 = encoder.container(keyedBy: DataSeriesKeys.self)
        try container1.encode(timePoint, forKey: .timePoint)
        try container1.encode(cloudCover, forKey: .cloudCover)
        try container1.encode(seeing, forKey: .seeing)
        try container1.encode(transparency, forKey: .transparency)
        try container1.encode(liftedIndex, forKey: .liftedIndex)
        try container1.encode(rh2m, forKey: .rh2m)
        try container1.encode(wind2m, forKey: .wind2m)
        try container1.encode(temp2m, forKey: .temp2m)
        try container1.encode(precType, forKey: .precType)
        
    }
    
     init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: DataSeriesKeys.self)
        self.timePoint = try container.decode(Int.self, forKey: .timePoint)
        self.cloudCover = try container.decode(Int.self, forKey: .cloudCover)
        self.seeing = try container.decode(Int.self, forKey: .seeing)
        self.transparency = try container.decode(Int.self, forKey: .transparency)
        self.liftedIndex = try container.decode(Int.self, forKey: .liftedIndex)
        self.rh2m = try container.decode(Int.self, forKey: .rh2m)
        self.wind2m = try container.decode(Wind10m.self, forKey: .wind2m)
        self.temp2m = try container.decode(Int.self, forKey: .temp2m)
        self.precType = try container.decode(String.self, forKey: .precType)
    }
    
    enum DataSeriesKeys : String , CodingKey {
        case timePoint
        case cloudCover
        case seeing
        case transparency
        case liftedIndex = "lifted_index"
        case rh2m
        case wind2m
        case temp2m
        case precType = "prec_type"
    }
    
}

// sub class of dict in DataSeries
struct Wind10m : Codable {
    
    var direction : String?
    var speed : Int?
    
    
    func encode(to encoder:Encoder) throws {
        var container3 = encoder.container(keyedBy: Wind10mKeys.self)
        try container3.encode(direction, forKey: .direction)
        try container3.encode(speed, forKey: .speed)
    }
    
     init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: Wind10mKeys.self)
        self.direction = try container.decode(String.self, forKey: .direction)
        self.speed = try container.decode(Int.self, forKey: .speed)
    }
    
    
    enum Wind10mKeys : String , CodingKey {
        case direction
        case speed
    }
    
}
