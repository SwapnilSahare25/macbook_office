//
//  CommentsViewController.swift
//  PlaceHolderJson
//
//  Created by Swapnil Sahare on 18/01/23.
//

import UIKit

class UserViewController: UIViewController {

    var user : [User]?
    @IBOutlet weak var userTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        hitUrl()
        // Do any additional setup after loading the view.
    }
    
    func hitUrl(){
        let baseUrl = "https://jsonplaceholder.typicode.com/users"
        guard let url = URL(string: baseUrl) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            if error == nil {
                guard let data = data else {return}
                do{
                    self.user = try JSONDecoder().decode([User].self, from: data)
                    //print(self.user)
                }catch let e{
                    print(e)
                }
                DispatchQueue.main.async {
                    self.userTableView.reloadData()
                }
            }
        }
        dataTask.resume()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UserViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return user?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let userData : User = user![indexPath.row]
        cell.textLabel?.text = userData.name
        cell.detailTextLabel?.text = "Rank : \(userData.id ?? 0)"
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userName = user![indexPath.row]
        let id : String = "\(userName.id!)"
        //print(id)
        self.performSegue(withIdentifier: "UserResponse", sender: id)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "UserResponse"{
            let targetVc = segue.destination as! PostViewController
            targetVc.id = sender as! String?
            
        }
    }
}
