//
//  ViewController.swift
//  PlaceHolderJson
//
//  Created by Swapnil Sahare on 18/01/23.
//

import UIKit

class CommentsViewController: UIViewController {
    @IBOutlet weak var postTableView : UITableView!
    
    var post : [Post]?
    var name : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        postTableView.delegate = self
        postTableView.dataSource = self
        print(name)
        getAllPosts()
        // Do any additional setup after loading the view.
    }
    func getAllPosts(){
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            if error == nil {
                guard let data = data else {return}
                do{
                    self.post = try JSONDecoder().decode([Post].self, from: data)
                    print(self.post!)
                }catch let er{
                    //print(er)
                }
                DispatchQueue.main.async {
                    self.postTableView.reloadData()
                }
            }
            
        }
        dataTask.resume()
    }


}

extension CommentsViewController : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return post?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = postTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PostTableViewCell
        let post : Post = post![indexPath.row]
        cell.userIdLabel.text = "User : \(post.userId ?? 0)"
        cell.idLabel.text = "Rank : \(post.id ?? 0)"
        cell.titleLabel.text = "\(post.title ?? "")"
        cell.bodyLabel.text = "\(post.body ?? "")"
        return cell
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let post = post![indexPath.row]
//        self.performSegue(withIdentifier: "Response", sender: post)
//    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "Response"{
//            let targetVc = segue.destination as! CommentsViewController
//            targetVc.rankId = sender as! Int?
//        }
//    }
}
