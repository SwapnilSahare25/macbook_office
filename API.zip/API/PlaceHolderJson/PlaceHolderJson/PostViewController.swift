//
//  PostViewController.swift
//  PlaceHolderJson
//
//  Created by Swapnil Sahare on 19/01/23.
//

import UIKit

class PostViewController: UIViewController {
    //var postArray : Post?
    var postArray : PostArray?
    var id : String?
    @IBOutlet weak var postNameView : UIView!
    @IBOutlet weak var postLabel : UILabel!
    @IBOutlet weak var postableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(id!)
        hitPostUrl()

        // Do any additional setup after loading the view.
    }
    func hitPostUrl(){
        var postUrl = "https://jsonplaceholder.typicode.com/posts/"
        let query = id?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        postUrl.append(query)
        //print(postUrl)
        guard let url = URL(string: postUrl) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            if error == nil{
                guard let data = data else {return}
               // print(data)
                do{
                    self.postArray = try JSONDecoder().decode(PostArray.self, from: data)
                    print(self.postArray!)
                }catch let error{
                    print(error)
                }
                DispatchQueue.main.async {
                    self.postableView.reloadData()
                }
            }
        }
        dataTask.resume()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PostViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postArray?.post?.count   ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = postableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PostCustomTableViewCell
        let postData = postArray?.post![indexPath.row]
        cell.idLabel.text = "\(postData?.id!)"
        cell.titleLabel.text = postData?.title
        cell.bodyLabel.text = postData?.body
        return cell
    }
    
    
}
