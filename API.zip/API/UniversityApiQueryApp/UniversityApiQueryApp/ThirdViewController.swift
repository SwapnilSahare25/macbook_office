//
//  ThirdViewController.swift
//  UniversityApiQueryApp
//
//  Created by Bharat Silavat on 10/01/23.
//

import UIKit

class ThirdViewController: UIViewController {

    var receivingData : [Source]?
    
    @IBOutlet weak var thirdVCTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .magenta
        thirdVCTableView.delegate = self
        thirdVCTableView.dataSource = self
//        print(receivingData)
    }
    
}

extension ThirdViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ThirdVC", for: indexPath)
        cell.textLabel?.text = receivingData?[indexPath.row].name
        cell.detailTextLabel?.text = receivingData?[indexPath.row].annotations?.sourceDescription
        return cell
    }
  
}

extension ThirdViewController: UITableViewDelegate{
    
    
    
}
