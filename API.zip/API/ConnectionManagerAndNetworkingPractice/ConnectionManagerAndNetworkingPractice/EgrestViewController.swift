//
//  EgrestViewController.swift
//  ConnectionManagerAndNetworkingPractice
//
//  Created by Swapnil Sahare on 01/01/23.
//

import UIKit

class EgrestViewController: UIViewController ,NetworkingDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        
        DispatchQueue.main.async {
            self.egrestView.isHidden = true
            self.egrestActivityIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
        
        if error == nil {
            guard let data = data else {return}
            let text = String(data: data, encoding: .utf8)
            
            DispatchQueue.main.async {
                self.egrestTextView.text = text
            }
        }
    }
    
    
    @IBOutlet weak var egrestTextView : UITextView!
    @IBOutlet weak var egrestView : UIView!
    @IBOutlet weak var egrestActivityIndicator : UIActivityIndicatorView!
    
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        //api = API.egrest
        connection.delegate = self
        egrestView.isHidden = true

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
        
        egrestView.isHidden = false
        egrestActivityIndicator.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        self.connection.startSession()
    }
}
