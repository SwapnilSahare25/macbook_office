//
//  ViewController.swift
//  ConnectionManagerAndNetworkingPractice
//
//  Created by Swapnil Sahare on 01/01/23.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource {
    
    
    
    var apiArrey : [API] = [.egrest]
    
    @IBOutlet weak var egrestTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        egrestTableView.delegate = self
        egrestTableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return apiArrey.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = egrestTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let apiType : API = apiArrey[indexPath.row]
        cell.textLabel?.text = apiType.rawValue
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urlApi : API = apiArrey[indexPath.row]
        
        self.performSegue(withIdentifier: "Response", sender: urlApi)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            guard let EgrestVc : EgrestViewController = segue.destination as? EgrestViewController else {return}
            let urlApi = sender as! API
            EgrestVc.api = urlApi
        }
    }
}

