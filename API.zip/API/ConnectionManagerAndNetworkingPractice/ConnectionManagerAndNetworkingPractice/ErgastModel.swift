//
//  Ergest Model.swift
//  ConnectionManagerAndNetworkingPractice
//
//  Created by Swapnil Sahare on 01/01/23.
//

import Foundation


struct Ergast : Codable {
    var MRData :MrData?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.MRData, forKey: .MRData)
    }
    enum CodingKeys: CodingKey {
        case MRData
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.MRData = try container.decodeIfPresent(MrData.self, forKey: .MRData)
    }
    
}
struct MrData : Codable {
    var xmlns : String?
    var series : String?
    var url : String?
    var limit : String?
    var offset : String?
    var total : String?
    var raceTable : RaceTable?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.xmlns, forKey: .xmlns)
        try container.encodeIfPresent(self.series, forKey: .series)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.limit, forKey: .limit)
        try container.encodeIfPresent(self.offset, forKey: .offset)
        try container.encodeIfPresent(self.total, forKey: .total)
        try container.encodeIfPresent(self.raceTable, forKey: .raceTable)
    }
    enum CodingKeys: CodingKey {
        case xmlns
        case series
        case url
        case limit
        case offset
        case total
        case raceTable
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.xmlns = try container.decodeIfPresent(String.self, forKey: .xmlns)
        self.series = try container.decodeIfPresent(String.self, forKey: .series)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.limit = try container.decodeIfPresent(String.self, forKey: .limit)
        self.offset = try container.decodeIfPresent(String.self, forKey: .offset)
        self.total = try container.decodeIfPresent(String.self, forKey: .total)
        self.raceTable = try container.decodeIfPresent(RaceTable.self, forKey: .raceTable)
    }
    
}
//
struct RaceTable : Codable {
    var season : String?
    var round : String?
    var races : [Races]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.season, forKey: .season)
        try container.encodeIfPresent(self.round, forKey: .round)
        try container.encodeIfPresent(self.races, forKey: .races)
    }
    enum CodingKeys: CodingKey {
        case season
        case round
        case races
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.season = try container.decodeIfPresent(String.self, forKey: .season)
        self.round = try container.decodeIfPresent(String.self, forKey: .round)
        self.races = try container.decodeIfPresent([Races].self, forKey: .races)
    }
}
//
struct Races : Codable {
    var season : String?
    var round : String?
    var url : String?
    var raceName : String?
    var circuit : Circuit?
    var date : String?
    var results : [Results]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.season, forKey: .season)
        try container.encodeIfPresent(self.round, forKey: .round)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.raceName, forKey: .raceName)
        try container.encodeIfPresent(self.circuit, forKey: .circuit)
        try container.encodeIfPresent(self.date, forKey: .date)
        try container.encodeIfPresent(self.results, forKey: .results)
    }
    enum CodingKeys: CodingKey {
        case season
        case round
        case url
        case raceName
        case circuit
        case date
        case results
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.season = try container.decodeIfPresent(String.self, forKey: .season)
        self.round = try container.decodeIfPresent(String.self, forKey: .round)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.raceName = try container.decodeIfPresent(String.self, forKey: .raceName)
        self.circuit = try container.decodeIfPresent(Circuit.self, forKey: .circuit)
        self.date = try container.decodeIfPresent(String.self, forKey: .date)
        self.results = try container.decodeIfPresent([Results].self, forKey: .results)
    }
}
//
struct Circuit : Codable {
    var circuitId : String?
    var url : String?
    var circuitName : String?
    var location : Location?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.circuitId, forKey: .circuitId)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.circuitName, forKey: .circuitName)
        try container.encodeIfPresent(self.location, forKey: .location)
    }
    enum CodingKeys: CodingKey {
        case circuitId
        case url
        case circuitName
        case location
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.circuitId = try container.decodeIfPresent(String.self, forKey: .circuitId)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.circuitName = try container.decodeIfPresent(String.self, forKey: .circuitName)
        self.location = try container.decodeIfPresent(Location.self, forKey: .location)
    }
}
//
struct Location : Codable {
    var lat : String?
    var long : String?
    var locality : String?
    var country : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.lat, forKey: .lat)
        try container.encodeIfPresent(self.long, forKey: .long)
        try container.encodeIfPresent(self.locality, forKey: .locality)
        try container.encodeIfPresent(self.country, forKey: .country)
    }
    enum CodingKeys: CodingKey {
        case lat
        case long
        case locality
        case country
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.lat = try container.decodeIfPresent(String.self, forKey: .lat)
        self.long = try container.decodeIfPresent(String.self, forKey: .long)
        self.locality = try container.decodeIfPresent(String.self, forKey: .locality)
        self.country = try container.decodeIfPresent(String.self, forKey: .country)
    }
}
//
struct Results : Codable {
    var number : String?
    var position : String?
    var positionText : String?
    var points : String?
    var driver :Driver?
    var constructor : Constructor?
    var grid : String?
    var laps : String?
    var status : String?
    var time : Time?
    var fastestLap : FastestLap?
    var averageSpeed : AverageSpeed?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.number, forKey: .number)
        try container.encodeIfPresent(self.position, forKey: .position)
        try container.encodeIfPresent(self.positionText, forKey: .positionText)
        try container.encodeIfPresent(self.points, forKey: .points)
        try container.encodeIfPresent(self.driver, forKey: .driver)
        try container.encodeIfPresent(self.constructor, forKey: .constructor)
        try container.encodeIfPresent(self.grid, forKey: .grid)
        try container.encodeIfPresent(self.laps, forKey: .laps)
        try container.encodeIfPresent(self.status, forKey: .status)
        try container.encodeIfPresent(self.time, forKey: .time)
        try container.encodeIfPresent(self.fastestLap, forKey: .fastestLap)
        try container.encodeIfPresent(self.averageSpeed, forKey: .averageSpeed)
    }
    enum CodingKeys: CodingKey {
        case number
        case position
        case positionText
        case points
        case driver
        case constructor
        case grid
        case laps
        case status
        case time
        case fastestLap
        case averageSpeed
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.number = try container.decodeIfPresent(String.self, forKey: .number)
        self.position = try container.decodeIfPresent(String.self, forKey: .position)
        self.positionText = try container.decodeIfPresent(String.self, forKey: .positionText)
        self.points = try container.decodeIfPresent(String.self, forKey: .points)
        self.driver = try container.decodeIfPresent(Driver.self, forKey: .driver)
        self.constructor = try container.decodeIfPresent(Constructor.self, forKey: .constructor)
        self.grid = try container.decodeIfPresent(String.self, forKey: .grid)
        self.laps = try container.decodeIfPresent(String.self, forKey: .laps)
        self.status = try container.decodeIfPresent(String.self, forKey: .status)
        self.time = try container.decodeIfPresent(Time.self, forKey: .time)
        self.fastestLap = try container.decodeIfPresent(FastestLap.self, forKey: .fastestLap)
        self.averageSpeed = try container.decodeIfPresent(AverageSpeed.self, forKey: .averageSpeed)
    }
    
}
//
struct Driver : Codable {
    var driverId : String?
    var code : String?
    var url : String?
    var givenName : String?
    var familyName : String?
    var dateOfBirth : String?
    var nationality : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.driverId, forKey: .driverId)
        try container.encodeIfPresent(self.code, forKey: .code)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.givenName, forKey: .givenName)
        try container.encodeIfPresent(self.familyName, forKey: .familyName)
        try container.encodeIfPresent(self.dateOfBirth, forKey: .dateOfBirth)
        try container.encodeIfPresent(self.nationality, forKey: .nationality)
    }
    enum CodingKeys: CodingKey {
        case driverId
        case code
        case url
        case givenName
        case familyName
        case dateOfBirth
        case nationality
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.driverId = try container.decodeIfPresent(String.self, forKey: .driverId)
        self.code = try container.decodeIfPresent(String.self, forKey: .code)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.givenName = try container.decodeIfPresent(String.self, forKey: .givenName)
        self.familyName = try container.decodeIfPresent(String.self, forKey: .familyName)
        self.dateOfBirth = try container.decodeIfPresent(String.self, forKey: .dateOfBirth)
        self.nationality = try container.decodeIfPresent(String.self, forKey: .nationality)
    }
}
//
struct Constructor : Codable {
    var constructorId : String?
    var url : String?
    var name : String?
    var nationality : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.constructorId, forKey: .constructorId)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.nationality, forKey: .nationality)
    }
    enum CodingKeys: CodingKey {
        case constructorId
        case url
        case name
        case nationality
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.constructorId = try container.decodeIfPresent(String.self, forKey: .constructorId)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.nationality = try container.decodeIfPresent(String.self, forKey: .nationality)
    }
}
//
struct Time : Codable {
    var millis : String?
    var time : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.millis, forKey: .millis)
        try container.encodeIfPresent(self.time, forKey: .time)
    }
    enum CodingKeys: CodingKey {
        case millis
        case time
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.millis = try container.decodeIfPresent(String.self, forKey: .millis)
        self.time = try container.decodeIfPresent(String.self, forKey: .time)
    }
}
//
struct FastestLap : Codable {
    var rank : String?
    var lap : String?
    var time : Time1?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.rank, forKey: .rank)
        try container.encodeIfPresent(self.lap, forKey: .lap)
        try container.encodeIfPresent(self.time, forKey: .time)
    }
    enum CodingKeys: CodingKey {
        case rank
        case lap
        case time
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.rank = try container.decodeIfPresent(String.self, forKey: .rank)
        self.lap = try container.decodeIfPresent(String.self, forKey: .lap)
        self.time = try container.decodeIfPresent(Time1.self, forKey: .time)
    }
}
//
struct Time1 : Codable {
    var time : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.time, forKey: .time)
    }
    enum CodingKeys: CodingKey {
        case time
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.time = try container.decodeIfPresent(String.self, forKey: .time)
    }
}
//
struct AverageSpeed : Codable {
    var units : String?
    var speed : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.units, forKey: .units)
        try container.encodeIfPresent(self.speed, forKey: .speed)
    }
    enum CodingKeys: CodingKey {
        case units
        case speed
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.units = try container.decodeIfPresent(String.self, forKey: .units)
        self.speed = try container.decodeIfPresent(String.self, forKey: .speed)
    }
}
