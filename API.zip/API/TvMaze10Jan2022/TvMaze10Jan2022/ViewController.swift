//
//  ViewController.swift
//  TvMaze10Jan2022
//
//  Created by Swapnil Sahare on 10/01/23.
//

import UIKit

class ViewController: UIViewController {
    var tvmaze : TvMaze?
    let urlPath = "http://api.tvmaze.com/search/shows"
    var query = "q=golden%20girls"
    
    @IBOutlet weak var tvMazeTableView : UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tvMazeTableView.delegate = self
        tvMazeTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func startSession(_ url : String){
        guard let url = URL(string: urlPath) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do{
                self.tvmaze = try JSONDecoder().decode(TvMaze.self, from: data)
            }catch let e{
                print(e)
            }
        }
        dataTask.resume()
    }


}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tvmaze?.name?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tvMazeTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = tvmaze?.name
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let urlApi : API = apiArrey[indexPath.row]
        self.performSegue(withIdentifier: "Response", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            var targetVc = segue.destination as! TvMazeResponseViewController
            targetVc.tvmaze = tvmaze
        }
    }
    
}
