//
//  TvMazeResponseViewController.swift
//  TvMaze10Jan2022
//
//  Created by Swapnil Sahare on 10/01/23.
//

import UIKit

class TvMazeResponseViewController: UIViewController {
    
    var tvmaze : TvMaze?
    
    @IBOutlet weak var tvMazeResponseTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


extension TvMazeResponseViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tvmaze?.name?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tvMazeResponseTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let tv : TvMaze = tvmaze!
        cell.textLabel?.text = tv.name
        cell.detailTextLabel?.text = tv.message
        return cell
    }
    
    
}
