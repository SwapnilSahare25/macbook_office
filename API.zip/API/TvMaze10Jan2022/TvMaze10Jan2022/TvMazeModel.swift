//
//  TvMazeModel.swift
//  TvMaze10Jan2022
//
//  Created by Swapnil Sahare on 10/01/23.
//

import Foundation

struct TvMaze : Codable {
    var name : String?
    var message : String?
    var code : Int?
    var status : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.message, forKey: .message)
        try container.encodeIfPresent(self.code, forKey: .code)
        try container.encodeIfPresent(self.status, forKey: .status)
    }
    enum CodingKeys: CodingKey {
        case name
        case message
        case code
        case status
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.message = try container.decodeIfPresent(String.self, forKey: .message)
        self.code = try container.decodeIfPresent(Int.self, forKey: .code)
        self.status = try container.decodeIfPresent(Int.self, forKey: .status)
    }
}
