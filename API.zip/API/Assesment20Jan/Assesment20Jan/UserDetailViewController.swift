//
//  UserDetailViewController.swift
//  Assesment20Jan
//
//  Created by Swapnil Sahare on 20/01/23.
//

import UIKit

class UserDetailViewController: UIViewController {

    @IBOutlet weak var nameLabel : UILabel!
    @IBOutlet weak var addressTextView : UITextView!
    @IBOutlet weak var phoneLabel : UILabel!
    @IBOutlet weak var websiteLabel : UILabel!
    @IBOutlet weak var companyTextView : UITextView!
    @IBOutlet weak var viewPostButton : UIButton!

    var userDetail : User?
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = userDetail?.name
        
        addressTextView.text = "Street : \(userDetail?.address?.street ?? "") , Suite :  \(userDetail?.address?.suite ?? "") , City : \(userDetail?.address?.city ?? "") , ZipCode :  \(userDetail?.address?.zipcode ?? "") ,  Lattitude : \(userDetail?.address?.geo?.lat ?? "") , Longitude : \(userDetail?.address?.geo?.lng ?? "")"
        
        phoneLabel.text = " \(userDetail?.phone ?? "")"
        
        websiteLabel.text = " \(userDetail?.website ?? "")"
        
        companyTextView.text = " Name : \(userDetail?.company?.name ?? "").\n BS : \(userDetail?.company?.bs ?? "").\n CatchPhrase : \(userDetail?.company?.catchPhrase ?? "")."
       // print(userDetail)
        
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func viewPostButton(_ sender: Any) {
        let userId = userDetail?.id
       
        let PostViewController = self.storyboard?.instantiateViewController(withIdentifier: "PostViewController") as! PostViewController
        PostViewController.UserId = userId
                self.navigationController?.pushViewController(PostViewController, animated: true)
           
    }
}
