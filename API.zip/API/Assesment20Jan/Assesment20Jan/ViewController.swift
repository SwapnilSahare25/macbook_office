//
//  ViewController.swift
//  Assesment20Jan
//
//  Created by Swapnil Sahare on 20/01/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userNametableView : UITableView!
    
    let section : [String] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    
    var userArray : [User]?
    var SortedNameArry : [User]? = []
    override func viewDidLoad() {
        super.viewDidLoad()
        print(SortedNameArry)
        userNametableView.delegate = self
        userNametableView.dataSource = self
        loopArray()
        hitUrl()
        
        // Do any additional setup after loading the view.
    }
    
    func loopArray(){
        
        for item in userArray ?? [] {
            
            if(item.name == "Leanne Graham"){
                SortedNameArry?.append(item)
            }
        }
        
        
    }
    
    func hitUrl(){
        let baseUrl = "https://jsonplaceholder.typicode.com/users"
        guard let url = URL(string: baseUrl) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            if error == nil {
                guard let data = data else {return}
                do{
                    self.userArray = try JSONDecoder().decode([User].self, from: data)
                    
                    
                }catch let error{
                    print(error)
                }
                DispatchQueue.main.async {
                    self.userNametableView.reloadData()
                }
            }
        }
        dataTask.resume()
        
    }


}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 26
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return self.section[section]
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userNametableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let userName = userArray![indexPath.row].name
        let fullNameArr = userName!.components(separatedBy: " ")

        cell.textLabel?.text = fullNameArr[0]
        cell.backgroundColor = indexPath.row % 2 == 0 ? .blue : .green
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let DetailsArray = userArray![indexPath.row]
        
        self.performSegue(withIdentifier: "Response", sender: DetailsArray)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response" {
            let targetVc = segue.destination as! UserDetailViewController
            let user = sender as! User?
            targetVc.userDetail = user
        }
    
    }
}
