//
//  DetailViewController.swift
//  UniversityQueryurl
//
//  Created by Swapnil Sahare on 10/01/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    var universityData : [University]?

    func detailData(){
        let url = "http://universities.hipolabs.com/search?"
        var query = "country=Singapore"
        
        let urlApi = URL(string: "http://universities.hipolabs.com/search?\(query)")
        let request = URLRequest(url: urlApi!)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do{
                self.universityData = try JSONDecoder().decode([University].self, from: data)
            }catch let e {
                print(e)
            }
            DispatchQueue.main.async {
                self.universityTableView.reloadData()
            }
        }
        dataTask.resume()
    }
   
    @IBOutlet weak var universityTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //universityTableView.dataSource = self
        //universityTableView.delegate = self
        detailData()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension DetailViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universityData?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = universityTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let urlData : University = universityData![indexPath.row]
        cell.textLabel?.text = urlData.name
        cell.detailTextLabel?.text = urlData.country
        return cell
    }


}
