//
//  UniversityResponseViewController.swift
//  UniversityQueryurl
//
//  Created by Swapnil Sahare on 10/01/23.
//

import UIKit

class UniversityResponseViewController: UIViewController , ConnectionManagerDelegate {
    var api: API?

    func didfFinishedTaskWithResponse(data: Data?, error: Error?) {
        
        if error == nil{
            guard let data = data else {return}
            do{
                self.university = try JSONDecoder().decode([University].self, from: data)
            }catch let e{
                print(e)
            }
            DispatchQueue.main.async {
                self.responseTableView.reloadData()
            }
          }
    }
    
    
    @IBOutlet weak var responseTableView : UITableView!
    var university : [University]?
    let connection = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        connection.delegate = self
        responseTableView.dataSource = self
        responseTableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        connection.startSession()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UniversityResponseViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return university?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = responseTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let urlApi : University = university![indexPath.row]
        cell.textLabel?.text = urlApi.name
        cell.detailTextLabel?.text = urlApi.country
        return  cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "DetailResponse", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DetailResponse"{
            let targetVc = segue.destination as! DetailViewController
            targetVc.universityData = university
        }
    }
}
