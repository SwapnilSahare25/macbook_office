//
//  ViewController.swift
//  UniversityQueryurl
//
//  Created by Swapnil Sahare on 10/01/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    var apiArrey : [API] = [.university]

    @IBOutlet weak var urlTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        apiArrey.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = urlTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let apiType : API = apiArrey[indexPath.row]
        cell.textLabel?.text = apiType.rawValue
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urlApi : API = apiArrey[indexPath.row]
        self.performSegue(withIdentifier: "Response", sender: urlApi)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response" {
            guard let api : API = sender as! API? else {return}
            var targetVc = segue.destination as! ConnectionManagerDelegate
            targetVc.api = api
        }
    }
}
