//
//  Conection.swift
//  UniversityQueryurl
//
//  Created by Swapnil Sahare on 10/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    var api : API? { get set }
    
    func didfFinishedTaskWithResponse(data : Data?,error: Error?)
}
   
enum API : String {
    case university = "http://universities.hipolabs.com/search"
}
class ConnectionManager {
    
    var delegate : ConnectionManagerDelegate?
    
    func startSession(){
        guard let delegate = self.delegate,
              let api = delegate.api else {return}
        let url = api.rawValue
        self.startTask(url)
        
    }
    func startTask(_ url : String){
        guard let url = URL(string: url) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {return}
            delegate.didfFinishedTaskWithResponse(data: data, error: error)
        }
        dataTask.resume()
    }
}
