//
//  ViewController.swift
//  figmaPractice17Jan
//
//  Created by Swapnil Sahare on 17/01/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailTextField : UITextField!
    @IBOutlet weak var passwordTextField : UITextField!
    @IBOutlet weak var loginButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

