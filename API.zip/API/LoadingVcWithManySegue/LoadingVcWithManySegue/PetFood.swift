//
//  PetFood.swift
//  LoadingVcWithManySegue
//
//  Created by Swapnil Sahare on 03/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    var api : API? { get set }
    
    func didCompleteTaskWithResponse(data:Data? , error:Error?)
}
enum API : String {
    case petFood = "https://world.openpetfoodfacts.org/api/v0/product/20106836.json"
}
class ConnectionManager {
    var delegate : ConnectionManagerDelegate?
    
    func startTask(){
        guard let delegate = self.delegate
                let api = delegate.api
    }
    func startTask(_ url : String) {
        
        guard let apiurl = URL(string: url) else {return}
        
        let request = URLRequest(url: apiurl)
        
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {return}
            delegate.didCompleteTaskWithResponse(data: data, error: error)
        }
        dataTask.resume()
    }
}
