//
//  ViewController.swift
//  LoadingVcWithManySegue
//
//  Created by Swapnil Sahare on 02/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

