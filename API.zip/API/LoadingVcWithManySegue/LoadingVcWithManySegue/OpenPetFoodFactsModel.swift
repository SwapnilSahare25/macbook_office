//
//  json.swift
//  LoadingVcWithManySegue
//
//  Created by Swapnil Sahare on 02/01/23.
//

import Foundation


struct PetFoodFacts : Codable {
    var statusVerbose : String?
    var status : Int?
    var code : String?
    var product : Product?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.statusVerbose, forKey: .statusVerbose)
        try container.encodeIfPresent(self.status, forKey: .status)
        try container.encodeIfPresent(self.code, forKey: .code)
        try container.encodeIfPresent(self.product, forKey: .product)
    }
    enum CodingKeys: CodingKey {
        case statusVerbose = "status_verbose"
        case status
        case code
        case product
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.statusVerbose = try container.decodeIfPresent(String.self, forKey: .statusVerbose)
        self.status = try container.decodeIfPresent(Int.self, forKey: .status)
        self.code = try container.decodeIfPresent(String.self, forKey: .code)
        self.product = try container.decodeIfPresent(Product.self, forKey: .product)
    }

}
struct Product : Codable {
    var ingredients_that_may_be_from_palm_oil_n : Int?
    var nutrition_data : String?
    var interface_version_created : String?
    var image_small_url : String?
    var last_image_t : Int16?
    var editors : [String]?
    var selected_images : SelectedImages?
    var max_imgid : String?
    var image_nutrition_url : String?
    var image_thumb_url : String?
    var countries_lc : String?
    var nutrition_grades_tags : [String]?
    var nutrition_data_prepared_per : String?
    var lc : String?
    var product_quantity : Int?
    var sortkey : Int16?
    var categories_lc : String?
    var packaging_debug_tags : [String]?  // empty aarey
    var no_nutrition_data : String?
    var brands_debug_tags : [String]?  // empty arrey
    var packaging : String?
    var amino_acids_tags : [String]? // empty arrey
    var codes_tags : [String]?
    var ingredients_text : String?
    var nutrition_data_per : String?
    var allergens_debug_tags : [String]?  // empty arrey
    var emb_codes : String?
    var additives_tags : [String]?     // empty arrey
    var manufacturing_places : String?
    var purchase_places_debug_tags : [String]?  // empty arrrey
    var labels_debug_tags : [String]?
    var origins : String?
    var traces_from_ingredients : String?
    var last_modified_t : Int16?
    var image_front_url : String?
    var categories : String?
    var update_key : String?
    var vitamins_prev_tags : [String]?  // empty arrey
    var nova_group_debug : String?
    var nova_groups : Int?
    var ingredients_original_tags : [String]?
    var countries_tags : [String]?
    var additives_old_tags : [String]?   // empty arrey
    var additives_debug_tags : [String]?  // empty arrey
    var last_edit_dates_tags : [String]?
    var checkers_tags : [String]?   // empty arrey
    var categories_debug_tags : [String]?
    var image_ingredients_url : String?
    var interface_version_modified : String?
    var labels_lc : String?
    var manufacturing_places_debug_tags : [String]?   // empty arrey
    var minerals_prev_tags : [String]?    // empty arrey
    var pnns_groups_2_tags : [String]?
    var labels_hierarchy : [String]?  // empty arrey
    var emb_codes_orig : String?
    var languages_tags : [String]?
    var emb_codes_20141016 : String?
    var ingredients_tags : [String]?
    var brands : String?
    var quantity : String?
    var additives_prev_tags : [String]?  // empty arrey
    var product_name : String?
    var entry_dates_tags : [String]?
    var id : String?
    var image_nutrition_small_url : String?
    var nutrient_levels_tags : [String]?
    var purchase_places : String?
    var ingredients_from_palm_oil_tags : [String]?  // empty arrey
    var additives_n : Int?
    var lang : String?
    var additives_original_tags : [String]?   // empty arrey
    var last_modified_by : String?
    var additives_prev : String?
    var image_ingredients_small_url : String?
    var image_url : String?
    var lang_debug_tags : [String]?  // empty arrey
    var editors_tags : [String]?
    var additives_prev_n : Int?
    var minerals_tags : [String]?   // empty arrey
    var nova_group : Int?
    var additives_prev_original_tags : [String]?   // empty arrey
    var last_editor : String?
    var nutrition_data_prepared_per_debug_tags : [String]?
    var serving_size : String?
    var serving_quantity : Int?
    var allergens_from_user : String?
    var created_t : Int16?
    var nutrient_levels : NutrientsLevel?
    var traces_hierarchy : [String]?  // empty arrey
    var states : String?
    var image_ingredients_thumb_url : String?
    var product_name_fr : String?
    var photographers_tags : [String]?   // empty arrey
    var labels_prev_hierarchy : [String]?      // empty arrey
    var image_nutrition_thumb_url : String?
    var ingredients_text_with_allergens : String?
    var rev : Int?
    var nucleotides_prev_tags : [String]?      // empty arrey
    var ingredients_text_debug : String?
    var traces_tags : [String]?               // empty arrey
    var nucleotides_tags : [String]?            // empty arrey
    var nutrition_data_per_debug_tags : [String]?           // empty arrey
    var ingredients_n_tags : [String]?                  // empty arrey
    var categories_prev_tags : [String]?                //empty arrey
    var images : Images?
    var stores_tags : [String]?                         // empty arrey
    var origins_debug_tags : [String]?
    var nutriments : Nutriments?
    var allergens_from_ingredients : String?
    var labels_tags : [String]?                           // empty arrey
    var unknown_nutrients_tags : [String]?
    var ingredients_hierarchy : [String]?
    var link_debug_tags : [String]?                           // empty arrey
    var informers_tags : [String]?
    var stores_debug_tags : [String]?             // empty arrey
    var emb_codes_tags : [String]?                        // empty arrey
    var amino_acids_prev_tags : [String]?                 // empty arrey
    var vitamins_tags : [String]?                             // empty arrey
    var ingredients_ids_debug : [String]?
    var image_front_thumb_url : String?
    var generic_name_fr : String?
    var traces_debug_tags : [String]?                     // empty arrey
    var ingredients_text_fr : String?
    var nutrition_data_prepared : String?
    var expiration_date_debug_tags : [String]?                   // empty arrey
    var last_image_dates_tags : [String]?
    var labels : String?
    var new_additives_n : Int?
    var allergens_hierarchy : [String]?
    var product_name_fr_debug_tags : [String]?                    // empty arrey
    var ingredients_text_with_allergens_fr : String?
    var origins_tags : [String]?                   // empty arrey
    var quality_tags : [String]?
    var categories_tags : [String]?
    var generic_name_fr_debug_tags : [String]?         // empty arrey
    var code : String?
    var allergens : String?
    var additives_old_n : Int?
    var languages : Language?
    var allergens_tags : [String]?
    var traces_lc : String?
    var ingredients_n : String?
    var debug_param_sorted_langs : [String]?
    var quantity_debug_tags : [String]?                 // empty arrey
    var pnns_groups_2 : String?
    var packaging_tags : [String]?
    var ingredients : [Ingridents2]?
    var creator : String?
    var countries : String?
    var nova_groups_tags : [String]?
    var pnns_groups_1_tags : [String]?
    var unknown_ingredients_n : Int?
    var ingredients_from_palm_oil_n : Int?
    var cities_tags : [String]?                     // empty arrey
    var languages_hierarchy : [String]?
    var _keywords : [String]?
    var countries_hierarchy : [String]?
    var labels_prev_tags : [String]?                // empty arrey
    var states_hierarchy : [String]?
    var completed_t : Int16?
    var pnns_groups_1 : String?
    var traces : String?
    var countries_debug_tags : [String]?                // empty arrey
    var image_front_small_url : String?
    var generic_name : String?
    var complete : Int?
    var misc_tags : [String]?
    var allergens_lc : String?
    var categories_prev_hierarchy : [String]?
    var manufacturing_places_tags : [String]?               // empty arrey
    var ingredients_that_may_be_from_palm_oil_tags : [String]?          // empty arrey
    var serving_size_debug_tags : [String]?                     // empty arrey
    var nutrition_score_debug : String?
    var categories_hierarchy : [String]?
    var ingredients_from_or_that_may_be_from_palm_oil_n : Int?
    var expiration_date : String?
    var brands_tags : [String]?
    var additives : String?
    var ingredients_debug : [String]?
    var purchase_places_tags : [String]?
    var stores : String?
    var _id : String?
    var traces_from_user : String?
    var link : String?
    var states_tags : [String]?
    var ingredients_text_fr_debug_tags : [String]?              // empty arrey
    var emb_codes_debug_tags : [String]?            // empty arrey
    var languages_codes : LanguageCode?
    var correctors_tags : [String]?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.ingredients_that_may_be_from_palm_oil_n, forKey: .ingredients_that_may_be_from_palm_oil_n)
        try container.encodeIfPresent(self.nutrition_data, forKey: .nutrition_data)
        try container.encodeIfPresent(self.interface_version_created, forKey: .interface_version_created)
        try container.encodeIfPresent(self.image_small_url, forKey: .image_small_url)
        try container.encodeIfPresent(self.last_image_t, forKey: .last_image_t)
        try container.encodeIfPresent(self.editors, forKey: .editors)
        try container.encodeIfPresent(self.selected_images, forKey: .selected_images)
        try container.encodeIfPresent(self.max_imgid, forKey: .max_imgid)
        try container.encodeIfPresent(self.image_nutrition_url, forKey: .image_nutrition_url)
        try container.encodeIfPresent(self.image_thumb_url, forKey: .image_thumb_url)
        try container.encodeIfPresent(self.countries_lc, forKey: .countries_lc)
        try container.encodeIfPresent(self.nutrition_grades_tags, forKey: .nutrition_grades_tags)
        try container.encodeIfPresent(self.nutrition_data_prepared_per, forKey: .nutrition_data_prepared_per)
        try container.encodeIfPresent(self.lc, forKey: .lc)
        try container.encodeIfPresent(self.product_quantity, forKey: .product_quantity)
        try container.encodeIfPresent(self.sortkey, forKey: .sortkey)
        try container.encodeIfPresent(self.categories_lc, forKey: .categories_lc)
        try container.encodeIfPresent(self.packaging_debug_tags, forKey: .packaging_debug_tags)
        try container.encodeIfPresent(self.no_nutrition_data, forKey: .no_nutrition_data)
        try container.encodeIfPresent(self.brands_debug_tags, forKey: .brands_debug_tags)
        try container.encodeIfPresent(self.packaging, forKey: .packaging)
        try container.encodeIfPresent(self.amino_acids_tags, forKey: .amino_acids_tags)
        try container.encodeIfPresent(self.codes_tags, forKey: .codes_tags)
        try container.encodeIfPresent(self.ingredients_text, forKey: .ingredients_text)
        try container.encodeIfPresent(self.nutrition_data_per, forKey: .nutrition_data_per)
        try container.encodeIfPresent(self.allergens_debug_tags, forKey: .allergens_debug_tags)
        try container.encodeIfPresent(self.emb_codes, forKey: .emb_codes)
        try container.encodeIfPresent(self.additives_tags, forKey: .additives_tags)
        try container.encodeIfPresent(self.manufacturing_places, forKey: .manufacturing_places)
        try container.encodeIfPresent(self.purchase_places_debug_tags, forKey: .purchase_places_debug_tags)
        try container.encodeIfPresent(self.labels_debug_tags, forKey: .labels_debug_tags)
        try container.encodeIfPresent(self.origins, forKey: .origins)
        try container.encodeIfPresent(self.traces_from_ingredients, forKey: .traces_from_ingredients)
        try container.encodeIfPresent(self.last_modified_t, forKey: .last_modified_t)
        try container.encodeIfPresent(self.image_front_url, forKey: .image_front_url)
        try container.encodeIfPresent(self.categories, forKey: .categories)
        try container.encodeIfPresent(self.update_key, forKey: .update_key)
        try container.encodeIfPresent(self.vitamins_prev_tags, forKey: .vitamins_prev_tags)
        try container.encodeIfPresent(self.nova_group_debug, forKey: .nova_group_debug)
        try container.encodeIfPresent(self.nova_groups, forKey: .nova_groups)
        try container.encodeIfPresent(self.ingredients_original_tags, forKey: .ingredients_original_tags)
        try container.encodeIfPresent(self.countries_tags, forKey: .countries_tags)
        try container.encodeIfPresent(self.additives_old_tags, forKey: .additives_old_tags)
        try container.encodeIfPresent(self.additives_debug_tags, forKey: .additives_debug_tags)
        try container.encodeIfPresent(self.last_edit_dates_tags, forKey: .last_edit_dates_tags)
        try container.encodeIfPresent(self.checkers_tags, forKey: .checkers_tags)
        try container.encodeIfPresent(self.categories_debug_tags, forKey: .categories_debug_tags)
        try container.encodeIfPresent(self.image_ingredients_url, forKey: .image_ingredients_url)
        try container.encodeIfPresent(self.interface_version_modified, forKey: .interface_version_modified)
        try container.encodeIfPresent(self.labels_lc, forKey: .labels_lc)
        try container.encodeIfPresent(self.manufacturing_places_debug_tags, forKey: .manufacturing_places_debug_tags)
        try container.encodeIfPresent(self.minerals_prev_tags, forKey: .minerals_prev_tags)
        try container.encodeIfPresent(self.pnns_groups_2_tags, forKey: .pnns_groups_2_tags)
        try container.encodeIfPresent(self.labels_hierarchy, forKey: .labels_hierarchy)
        try container.encodeIfPresent(self.emb_codes_orig, forKey: .emb_codes_orig)
        try container.encodeIfPresent(self.languages_tags, forKey: .languages_tags)
        try container.encodeIfPresent(self.emb_codes_20141016, forKey: .emb_codes_20141016)
        try container.encodeIfPresent(self.ingredients_tags, forKey: .ingredients_tags)
        try container.encodeIfPresent(self.brands, forKey: .brands)
        try container.encodeIfPresent(self.quantity, forKey: .quantity)
        try container.encodeIfPresent(self.additives_prev_tags, forKey: .additives_prev_tags)
        try container.encodeIfPresent(self.product_name, forKey: .product_name)
        try container.encodeIfPresent(self.entry_dates_tags, forKey: .entry_dates_tags)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.image_nutrition_small_url, forKey: .image_nutrition_small_url)
        try container.encodeIfPresent(self.nutrient_levels_tags, forKey: .nutrient_levels_tags)
        try container.encodeIfPresent(self.purchase_places, forKey: .purchase_places)
        try container.encodeIfPresent(self.ingredients_from_palm_oil_tags, forKey: .ingredients_from_palm_oil_tags)
        try container.encodeIfPresent(self.additives_n, forKey: .additives_n)
        try container.encodeIfPresent(self.lang, forKey: .lang)
        try container.encodeIfPresent(self.additives_original_tags, forKey: .additives_original_tags)
        try container.encodeIfPresent(self.last_modified_by, forKey: .last_modified_by)
        try container.encodeIfPresent(self.additives_prev, forKey: .additives_prev)
        try container.encodeIfPresent(self.image_ingredients_small_url, forKey: .image_ingredients_small_url)
        try container.encodeIfPresent(self.image_url, forKey: .image_url)
        try container.encodeIfPresent(self.lang_debug_tags, forKey: .lang_debug_tags)
        try container.encodeIfPresent(self.editors_tags, forKey: .editors_tags)
        try container.encodeIfPresent(self.additives_prev_n, forKey: .additives_prev_n)
        try container.encodeIfPresent(self.minerals_tags, forKey: .minerals_tags)
        try container.encodeIfPresent(self.nova_group, forKey: .nova_group)
        try container.encodeIfPresent(self.additives_prev_original_tags, forKey: .additives_prev_original_tags)
        try container.encodeIfPresent(self.last_editor, forKey: .last_editor)
        try container.encodeIfPresent(self.nutrition_data_prepared_per_debug_tags, forKey: .nutrition_data_prepared_per_debug_tags)
        try container.encodeIfPresent(self.serving_size, forKey: .serving_size)
        try container.encodeIfPresent(self.serving_quantity, forKey: .serving_quantity)
        try container.encodeIfPresent(self.allergens_from_user, forKey: .allergens_from_user)
        try container.encodeIfPresent(self.created_t, forKey: .created_t)
        try container.encodeIfPresent(self.nutrient_levels, forKey: .nutrient_levels)
        try container.encodeIfPresent(self.traces_hierarchy, forKey: .traces_hierarchy)
        try container.encodeIfPresent(self.states, forKey: .states)
        try container.encodeIfPresent(self.image_ingredients_thumb_url, forKey: .image_ingredients_thumb_url)
        try container.encodeIfPresent(self.product_name_fr, forKey: .product_name_fr)
        try container.encodeIfPresent(self.photographers_tags, forKey: .photographers_tags)
        try container.encodeIfPresent(self.labels_prev_hierarchy, forKey: .labels_prev_hierarchy)
        try container.encodeIfPresent(self.image_nutrition_thumb_url, forKey: .image_nutrition_thumb_url)
        try container.encodeIfPresent(self.ingredients_text_with_allergens, forKey: .ingredients_text_with_allergens)
        try container.encode(self.rev, forKey: .rev)
        try container.encodeIfPresent(self.nucleotides_prev_tags, forKey: .nucleotides_prev_tags)
        try container.encodeIfPresent(self.ingredients_text_debug, forKey: .ingredients_text_debug)
        try container.encodeIfPresent(self.traces_tags, forKey: .traces_tags)
        try container.encodeIfPresent(self.nucleotides_tags, forKey: .nucleotides_tags)
        try container.encodeIfPresent(self.nutrition_data_per_debug_tags, forKey: .nutrition_data_per_debug_tags)
        try container.encodeIfPresent(self.ingredients_n_tags, forKey: .ingredients_n_tags)
        try container.encodeIfPresent(self.categories_prev_tags, forKey: .categories_prev_tags)
        try container.encodeIfPresent(self.images, forKey: .images)
        try container.encodeIfPresent(self.stores_tags, forKey: .stores_tags)
        try container.encodeIfPresent(self.origins_debug_tags, forKey: .origins_debug_tags)
        try container.encodeIfPresent(self.nutriments, forKey: .nutriments)
        try container.encodeIfPresent(self.allergens_from_ingredients, forKey: .allergens_from_ingredients)
        try container.encodeIfPresent(self.labels_tags, forKey: .labels_tags)
        try container.encodeIfPresent(self.unknown_nutrients_tags, forKey: .unknown_nutrients_tags)
        try container.encodeIfPresent(self.ingredients_hierarchy, forKey: .ingredients_hierarchy)
        try container.encodeIfPresent(self.link_debug_tags, forKey: .link_debug_tags)
        try container.encodeIfPresent(self.informers_tags, forKey: .informers_tags)
        try container.encodeIfPresent(self.stores_debug_tags, forKey: .stores_debug_tags)
        try container.encodeIfPresent(self.emb_codes_tags, forKey: .emb_codes_tags)
        try container.encodeIfPresent(self.amino_acids_prev_tags, forKey: .amino_acids_prev_tags)
        try container.encodeIfPresent(self.vitamins_tags, forKey: .vitamins_tags)
        try container.encodeIfPresent(self.ingredients_ids_debug, forKey: .ingredients_ids_debug)
        try container.encodeIfPresent(self.image_front_thumb_url, forKey: .image_front_thumb_url)
        try container.encodeIfPresent(self.generic_name_fr, forKey: .generic_name_fr)
        try container.encodeIfPresent(self.traces_debug_tags, forKey: .traces_debug_tags)
        try container.encodeIfPresent(self.ingredients_text_fr, forKey: .ingredients_text_fr)
        try container.encodeIfPresent(self.nutrition_data_prepared, forKey: .nutrition_data_prepared)
        try container.encodeIfPresent(self.expiration_date_debug_tags, forKey: .expiration_date_debug_tags)
        try container.encodeIfPresent(self.last_image_dates_tags, forKey: .last_image_dates_tags)
        try container.encodeIfPresent(self.labels, forKey: .labels)
        try container.encodeIfPresent(self.new_additives_n, forKey: .new_additives_n)
        try container.encodeIfPresent(self.allergens_hierarchy, forKey: .allergens_hierarchy)
        try container.encodeIfPresent(self.product_name_fr_debug_tags, forKey: .product_name_fr_debug_tags)
        try container.encodeIfPresent(self.ingredients_text_with_allergens_fr, forKey: .ingredients_text_with_allergens_fr)
        try container.encodeIfPresent(self.origins_tags, forKey: .origins_tags)
        try container.encodeIfPresent(self.quality_tags, forKey: .quality_tags)
        try container.encodeIfPresent(self.categories_tags, forKey: .categories_tags)
        try container.encodeIfPresent(self.generic_name_fr_debug_tags, forKey: .generic_name_fr_debug_tags)
        try container.encodeIfPresent(self.code, forKey: .code)
        try container.encodeIfPresent(self.allergens, forKey: .allergens)
        try container.encodeIfPresent(self.additives_old_n, forKey: .additives_old_n)
        try container.encodeIfPresent(self.languages, forKey: .languages)
        try container.encodeIfPresent(self.allergens_tags, forKey: .allergens_tags)
        try container.encodeIfPresent(self.traces_lc, forKey: .traces_lc)
        try container.encodeIfPresent(self.ingredients_n, forKey: .ingredients_n)
        try container.encodeIfPresent(self.debug_param_sorted_langs, forKey: .debug_param_sorted_langs)
        try container.encodeIfPresent(self.quantity_debug_tags, forKey: .quantity_debug_tags)
        try container.encodeIfPresent(self.pnns_groups_2, forKey: .pnns_groups_2)
        try container.encodeIfPresent(self.packaging_tags, forKey: .packaging_tags)
        try container.encodeIfPresent(self.ingredients, forKey: .ingredients)
        try container.encodeIfPresent(self.creator, forKey: .creator)
        try container.encodeIfPresent(self.countries, forKey: .countries)
        try container.encodeIfPresent(self.nova_groups_tags, forKey: .nova_groups_tags)
        try container.encodeIfPresent(self.pnns_groups_1_tags, forKey: .pnns_groups_1_tags)
        try container.encodeIfPresent(self.unknown_ingredients_n, forKey: .unknown_ingredients_n)
        try container.encodeIfPresent(self.ingredients_from_palm_oil_n, forKey: .ingredients_from_palm_oil_n)
        try container.encodeIfPresent(self.cities_tags, forKey: .cities_tags)
        try container.encodeIfPresent(self.languages_hierarchy, forKey: .languages_hierarchy)
        try container.encodeIfPresent(self._keywords, forKey: ._keywords)
        try container.encodeIfPresent(self.countries_hierarchy, forKey: .countries_hierarchy)
        try container.encodeIfPresent(self.labels_prev_tags, forKey: .labels_prev_tags)
        try container.encodeIfPresent(self.states_hierarchy, forKey: .states_hierarchy)
        try container.encodeIfPresent(self.completed_t, forKey: .completed_t)
        try container.encodeIfPresent(self.pnns_groups_1, forKey: .pnns_groups_1)
        try container.encodeIfPresent(self.traces, forKey: .traces)
        try container.encodeIfPresent(self.countries_debug_tags, forKey: .countries_debug_tags)
        try container.encodeIfPresent(self.image_front_small_url, forKey: .image_front_small_url)
        try container.encodeIfPresent(self.generic_name, forKey: .generic_name)
        try container.encodeIfPresent(self.complete, forKey: .complete)
        try container.encodeIfPresent(self.misc_tags, forKey: .misc_tags)
        try container.encodeIfPresent(self.allergens_lc, forKey: .allergens_lc)
        try container.encodeIfPresent(self.categories_prev_hierarchy, forKey: .categories_prev_hierarchy)
        try container.encodeIfPresent(self.manufacturing_places_tags, forKey: .manufacturing_places_tags)
        try container.encodeIfPresent(self.ingredients_that_may_be_from_palm_oil_tags, forKey: .ingredients_that_may_be_from_palm_oil_tags)
        try container.encodeIfPresent(self.serving_size_debug_tags, forKey: .serving_size_debug_tags)
        try container.encodeIfPresent(self.nutrition_score_debug, forKey: .nutrition_score_debug)
        try container.encodeIfPresent(self.categories_hierarchy, forKey: .categories_hierarchy)
        try container.encodeIfPresent(self.ingredients_from_or_that_may_be_from_palm_oil_n, forKey: .ingredients_from_or_that_may_be_from_palm_oil_n)
        try container.encodeIfPresent(self.expiration_date, forKey: .expiration_date)
        try container.encodeIfPresent(self.brands_tags, forKey: .brands_tags)
        try container.encodeIfPresent(self.additives, forKey: .additives)
        try container.encodeIfPresent(self.ingredients_debug, forKey: .ingredients_debug)
        try container.encodeIfPresent(self.purchase_places_tags, forKey: .purchase_places_tags)
        try container.encodeIfPresent(self.stores, forKey: .stores)
        try container.encodeIfPresent(self._id, forKey: ._id)
        try container.encodeIfPresent(self.traces_from_user, forKey: .traces_from_user)
        try container.encodeIfPresent(self.link, forKey: .link)
        try container.encodeIfPresent(self.states_tags, forKey: .states_tags)
        try container.encodeIfPresent(self.ingredients_text_fr_debug_tags, forKey: .ingredients_text_fr_debug_tags)
        try container.encodeIfPresent(self.emb_codes_debug_tags, forKey: .emb_codes_debug_tags)
        try container.encodeIfPresent(self.languages_codes, forKey: .languages_codes)
        try container.encodeIfPresent(self.correctors_tags, forKey: .correctors_tags)
    }
    enum CodingKeys: CodingKey {
        case ingredients_that_may_be_from_palm_oil_n
        case nutrition_data
        case interface_version_created
        case image_small_url
        case last_image_t
        case editors
        case selected_images
        case max_imgid
        case image_nutrition_url
        case image_thumb_url
        case countries_lc
        case nutrition_grades_tags
        case nutrition_data_prepared_per
        case lc
        case product_quantity
        case sortkey
        case categories_lc
        case packaging_debug_tags
        case no_nutrition_data
        case brands_debug_tags
        case packaging
        case amino_acids_tags
        case codes_tags
        case ingredients_text
        case nutrition_data_per
        case allergens_debug_tags
        case emb_codes
        case additives_tags
        case manufacturing_places
        case purchase_places_debug_tags
        case labels_debug_tags
        case origins
        case traces_from_ingredients
        case last_modified_t
        case image_front_url
        case categories
        case update_key
        case vitamins_prev_tags
        case nova_group_debug
        case nova_groups
        case ingredients_original_tags
        case countries_tags
        case additives_old_tags
        case additives_debug_tags
        case last_edit_dates_tags
        case checkers_tags
        case categories_debug_tags
        case image_ingredients_url
        case interface_version_modified
        case labels_lc
        case manufacturing_places_debug_tags
        case minerals_prev_tags
        case pnns_groups_2_tags
        case labels_hierarchy
        case emb_codes_orig
        case languages_tags
        case emb_codes_20141016
        case ingredients_tags
        case brands
        case quantity
        case additives_prev_tags
        case product_name
        case entry_dates_tags
        case id
        case image_nutrition_small_url
        case nutrient_levels_tags
        case purchase_places
        case ingredients_from_palm_oil_tags
        case additives_n
        case lang
        case additives_original_tags
        case last_modified_by
        case additives_prev
        case image_ingredients_small_url
        case image_url
        case lang_debug_tags
        case editors_tags
        case additives_prev_n
        case minerals_tags
        case nova_group
        case additives_prev_original_tags
        case last_editor
        case nutrition_data_prepared_per_debug_tags
        case serving_size
        case serving_quantity
        case allergens_from_user
        case created_t
        case nutrient_levels
        case traces_hierarchy
        case states
        case image_ingredients_thumb_url
        case product_name_fr
        case photographers_tags
        case labels_prev_hierarchy
        case image_nutrition_thumb_url
        case ingredients_text_with_allergens
        case rev
        case nucleotides_prev_tags
        case ingredients_text_debug
        case traces_tags
        case nucleotides_tags
        case nutrition_data_per_debug_tags
        case ingredients_n_tags
        case categories_prev_tags
        case images
        case stores_tags
        case origins_debug_tags
        case nutriments
        case allergens_from_ingredients
        case labels_tags
        case unknown_nutrients_tags
        case ingredients_hierarchy
        case link_debug_tags
        case informers_tags
        case stores_debug_tags
        case emb_codes_tags
        case amino_acids_prev_tags
        case vitamins_tags
        case ingredients_ids_debug
        case image_front_thumb_url
        case generic_name_fr
        case traces_debug_tags
        case ingredients_text_fr
        case nutrition_data_prepared
        case expiration_date_debug_tags
        case last_image_dates_tags
        case labels
        case new_additives_n
        case allergens_hierarchy
        case product_name_fr_debug_tags
        case ingredients_text_with_allergens_fr
        case origins_tags
        case quality_tags
        case categories_tags
        case generic_name_fr_debug_tags
        case code
        case allergens
        case additives_old_n
        case languages
        case allergens_tags
        case traces_lc
        case ingredients_n
        case debug_param_sorted_langs
        case quantity_debug_tags
        case pnns_groups_2
        case packaging_tags
        case ingredients
        case creator
        case countries
        case nova_groups_tags
        case pnns_groups_1_tags
        case unknown_ingredients_n
        case ingredients_from_palm_oil_n
        case cities_tags
        case languages_hierarchy
        case _keywords
        case countries_hierarchy
        case labels_prev_tags
        case states_hierarchy
        case completed_t
        case pnns_groups_1
        case traces
        case countries_debug_tags
        case image_front_small_url
        case generic_name
        case complete
        case misc_tags
        case allergens_lc
        case categories_prev_hierarchy
        case manufacturing_places_tags
        case ingredients_that_may_be_from_palm_oil_tags
        case serving_size_debug_tags
        case nutrition_score_debug
        case categories_hierarchy
        case ingredients_from_or_that_may_be_from_palm_oil_n
        case expiration_date
        case brands_tags
        case additives
        case ingredients_debug
        case purchase_places_tags
        case stores
        case _id
        case traces_from_user
        case link
        case states_tags
        case ingredients_text_fr_debug_tags
        case emb_codes_debug_tags
        case languages_codes
        case correctors_tags
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.ingredients_that_may_be_from_palm_oil_n = try container.decodeIfPresent(Int.self, forKey: .ingredients_that_may_be_from_palm_oil_n)
        self.nutrition_data = try container.decodeIfPresent(String.self, forKey: .nutrition_data)
        self.interface_version_created = try container.decodeIfPresent(String.self, forKey: .interface_version_created)
        self.image_small_url = try container.decodeIfPresent(String.self, forKey: .image_small_url)
        self.last_image_t = try container.decodeIfPresent(Int16.self, forKey: .last_image_t)
        self.editors = try container.decodeIfPresent([String].self, forKey: .editors)
        self.selected_images = try container.decodeIfPresent(SelectedImages.self, forKey: .selected_images)
        self.max_imgid = try container.decodeIfPresent(String.self, forKey: .max_imgid)
        self.image_nutrition_url = try container.decodeIfPresent(String.self, forKey: .image_nutrition_url)
        self.image_thumb_url = try container.decodeIfPresent(String.self, forKey: .image_thumb_url)
        self.countries_lc = try container.decodeIfPresent(String.self, forKey: .countries_lc)
        self.nutrition_grades_tags = try container.decodeIfPresent([String].self, forKey: .nutrition_grades_tags)
        self.nutrition_data_prepared_per = try container.decodeIfPresent(String.self, forKey: .nutrition_data_prepared_per)
        self.lc = try container.decodeIfPresent(String.self, forKey: .lc)
        self.product_quantity = try container.decodeIfPresent(Int.self, forKey: .product_quantity)
        self.sortkey = try container.decodeIfPresent(Int16.self, forKey: .sortkey)
        self.categories_lc = try container.decodeIfPresent(String.self, forKey: .categories_lc)
        self.packaging_debug_tags = try container.decodeIfPresent([String].self, forKey: .packaging_debug_tags)
        self.no_nutrition_data = try container.decodeIfPresent(String.self, forKey: .no_nutrition_data)
        self.brands_debug_tags = try container.decodeIfPresent([String].self, forKey: .brands_debug_tags)
        self.packaging = try container.decodeIfPresent(String.self, forKey: .packaging)
        self.amino_acids_tags = try container.decodeIfPresent([String].self, forKey: .amino_acids_tags)
        self.codes_tags = try container.decodeIfPresent([String].self, forKey: .codes_tags)
        self.ingredients_text = try container.decodeIfPresent(String.self, forKey: .ingredients_text)
        self.nutrition_data_per = try container.decodeIfPresent(String.self, forKey: .nutrition_data_per)
        self.allergens_debug_tags = try container.decodeIfPresent([String].self, forKey: .allergens_debug_tags)
        self.emb_codes = try container.decodeIfPresent(String.self, forKey: .emb_codes)
        self.additives_tags = try container.decodeIfPresent([String].self, forKey: .additives_tags)
        self.manufacturing_places = try container.decodeIfPresent(String.self, forKey: .manufacturing_places)
        self.purchase_places_debug_tags = try container.decodeIfPresent([String].self, forKey: .purchase_places_debug_tags)
        self.labels_debug_tags = try container.decodeIfPresent([String].self, forKey: .labels_debug_tags)
        self.origins = try container.decodeIfPresent(String.self, forKey: .origins)
        self.traces_from_ingredients = try container.decodeIfPresent(String.self, forKey: .traces_from_ingredients)
        self.last_modified_t = try container.decodeIfPresent(Int16.self, forKey: .last_modified_t)
        self.image_front_url = try container.decodeIfPresent(String.self, forKey: .image_front_url)
        self.categories = try container.decodeIfPresent(String.self, forKey: .categories)
        self.update_key = try container.decodeIfPresent(String.self, forKey: .update_key)
        self.vitamins_prev_tags = try container.decodeIfPresent([String].self, forKey: .vitamins_prev_tags)
        self.nova_group_debug = try container.decodeIfPresent(String.self, forKey: .nova_group_debug)
        self.nova_groups = try container.decodeIfPresent(Int.self, forKey: .nova_groups)
        self.ingredients_original_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_original_tags)
        self.countries_tags = try container.decodeIfPresent([String].self, forKey: .countries_tags)
        self.additives_old_tags = try container.decodeIfPresent([String].self, forKey: .additives_old_tags)
        self.additives_debug_tags = try container.decodeIfPresent([String].self, forKey: .additives_debug_tags)
        self.last_edit_dates_tags = try container.decodeIfPresent([String].self, forKey: .last_edit_dates_tags)
        self.checkers_tags = try container.decodeIfPresent([String].self, forKey: .checkers_tags)
        self.categories_debug_tags = try container.decodeIfPresent([String].self, forKey: .categories_debug_tags)
        self.image_ingredients_url = try container.decodeIfPresent(String.self, forKey: .image_ingredients_url)
        self.interface_version_modified = try container.decodeIfPresent(String.self, forKey: .interface_version_modified)
        self.labels_lc = try container.decodeIfPresent(String.self, forKey: .labels_lc)
        self.manufacturing_places_debug_tags = try container.decodeIfPresent([String].self, forKey: .manufacturing_places_debug_tags)
        self.minerals_prev_tags = try container.decodeIfPresent([String].self, forKey: .minerals_prev_tags)
        self.pnns_groups_2_tags = try container.decodeIfPresent([String].self, forKey: .pnns_groups_2_tags)
        self.labels_hierarchy = try container.decodeIfPresent([String].self, forKey: .labels_hierarchy)
        self.emb_codes_orig = try container.decodeIfPresent(String.self, forKey: .emb_codes_orig)
        self.languages_tags = try container.decodeIfPresent([String].self, forKey: .languages_tags)
        self.emb_codes_20141016 = try container.decodeIfPresent(String.self, forKey: .emb_codes_20141016)
        self.ingredients_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_tags)
        self.brands = try container.decodeIfPresent(String.self, forKey: .brands)
        self.quantity = try container.decodeIfPresent(String.self, forKey: .quantity)
        self.additives_prev_tags = try container.decodeIfPresent([String].self, forKey: .additives_prev_tags)
        self.product_name = try container.decodeIfPresent(String.self, forKey: .product_name)
        self.entry_dates_tags = try container.decodeIfPresent([String].self, forKey: .entry_dates_tags)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
        self.image_nutrition_small_url = try container.decodeIfPresent(String.self, forKey: .image_nutrition_small_url)
        self.nutrient_levels_tags = try container.decodeIfPresent([String].self, forKey: .nutrient_levels_tags)
        self.purchase_places = try container.decodeIfPresent(String.self, forKey: .purchase_places)
        self.ingredients_from_palm_oil_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_from_palm_oil_tags)
        self.additives_n = try container.decodeIfPresent(Int.self, forKey: .additives_n)
        self.lang = try container.decodeIfPresent(String.self, forKey: .lang)
        self.additives_original_tags = try container.decodeIfPresent([String].self, forKey: .additives_original_tags)
        self.last_modified_by = try container.decodeIfPresent(String.self, forKey: .last_modified_by)
        self.additives_prev = try container.decodeIfPresent(String.self, forKey: .additives_prev)
        self.image_ingredients_small_url = try container.decodeIfPresent(String.self, forKey: .image_ingredients_small_url)
        self.image_url = try container.decodeIfPresent(String.self, forKey: .image_url)
        self.lang_debug_tags = try container.decodeIfPresent([String].self, forKey: .lang_debug_tags)
        self.editors_tags = try container.decodeIfPresent([String].self, forKey: .editors_tags)
        self.additives_prev_n = try container.decodeIfPresent(Int.self, forKey: .additives_prev_n)
        self.minerals_tags = try container.decodeIfPresent([String].self, forKey: .minerals_tags)
        self.nova_group = try container.decodeIfPresent(Int.self, forKey: .nova_group)
        self.additives_prev_original_tags = try container.decodeIfPresent([String].self, forKey: .additives_prev_original_tags)
        self.last_editor = try container.decodeIfPresent(String.self, forKey: .last_editor)
        self.nutrition_data_prepared_per_debug_tags = try container.decodeIfPresent([String].self, forKey: .nutrition_data_prepared_per_debug_tags)
        self.serving_size = try container.decodeIfPresent(String.self, forKey: .serving_size)
        self.serving_quantity = try container.decodeIfPresent(Int.self, forKey: .serving_quantity)
        self.allergens_from_user = try container.decodeIfPresent(String.self, forKey: .allergens_from_user)
        self.created_t = try container.decodeIfPresent(Int16.self, forKey: .created_t)
        self.nutrient_levels = try container.decodeIfPresent(NutrientsLevel.self, forKey: .nutrient_levels)
        self.traces_hierarchy = try container.decodeIfPresent([String].self, forKey: .traces_hierarchy)
        self.states = try container.decodeIfPresent(String.self, forKey: .states)
        self.image_ingredients_thumb_url = try container.decodeIfPresent(String.self, forKey: .image_ingredients_thumb_url)
        self.product_name_fr = try container.decodeIfPresent(String.self, forKey: .product_name_fr)
        self.photographers_tags = try container.decodeIfPresent([String].self, forKey: .photographers_tags)
        self.labels_prev_hierarchy = try container.decodeIfPresent([String].self, forKey: .labels_prev_hierarchy)
        self.image_nutrition_thumb_url = try container.decodeIfPresent(String.self, forKey: .image_nutrition_thumb_url)
        self.ingredients_text_with_allergens = try container.decodeIfPresent(String.self, forKey: .ingredients_text_with_allergens)
        self.rev = try container.decode(Int.self, forKey: .rev)
        self.nucleotides_prev_tags = try container.decodeIfPresent([String].self, forKey: .nucleotides_prev_tags)
        self.ingredients_text_debug = try container.decodeIfPresent(String.self, forKey: .ingredients_text_debug)
        self.traces_tags = try container.decodeIfPresent([String].self, forKey: .traces_tags)
        self.nucleotides_tags = try container.decodeIfPresent([String].self, forKey: .nucleotides_tags)
        self.nutrition_data_per_debug_tags = try container.decodeIfPresent([String].self, forKey: .nutrition_data_per_debug_tags)
        self.ingredients_n_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_n_tags)
        self.categories_prev_tags = try container.decodeIfPresent([String].self, forKey: .categories_prev_tags)
        self.images = try container.decodeIfPresent(Images.self, forKey: .images)
        self.stores_tags = try container.decodeIfPresent([String].self, forKey: .stores_tags)
        self.origins_debug_tags = try container.decodeIfPresent([String].self, forKey: .origins_debug_tags)
        self.nutriments = try container.decodeIfPresent(Nutriments.self, forKey: .nutriments)
        self.allergens_from_ingredients = try container.decodeIfPresent(String.self, forKey: .allergens_from_ingredients)
        self.labels_tags = try container.decodeIfPresent([String].self, forKey: .labels_tags)
        self.unknown_nutrients_tags = try container.decodeIfPresent([String].self, forKey: .unknown_nutrients_tags)
        self.ingredients_hierarchy = try container.decodeIfPresent([String].self, forKey: .ingredients_hierarchy)
        self.link_debug_tags = try container.decodeIfPresent([String].self, forKey: .link_debug_tags)
        self.informers_tags = try container.decodeIfPresent([String].self, forKey: .informers_tags)
        self.stores_debug_tags = try container.decodeIfPresent([String].self, forKey: .stores_debug_tags)
        self.emb_codes_tags = try container.decodeIfPresent([String].self, forKey: .emb_codes_tags)
        self.amino_acids_prev_tags = try container.decodeIfPresent([String].self, forKey: .amino_acids_prev_tags)
        self.vitamins_tags = try container.decodeIfPresent([String].self, forKey: .vitamins_tags)
        self.ingredients_ids_debug = try container.decodeIfPresent([String].self, forKey: .ingredients_ids_debug)
        self.image_front_thumb_url = try container.decodeIfPresent(String.self, forKey: .image_front_thumb_url)
        self.generic_name_fr = try container.decodeIfPresent(String.self, forKey: .generic_name_fr)
        self.traces_debug_tags = try container.decodeIfPresent([String].self, forKey: .traces_debug_tags)
        self.ingredients_text_fr = try container.decodeIfPresent(String.self, forKey: .ingredients_text_fr)
        self.nutrition_data_prepared = try container.decodeIfPresent(String.self, forKey: .nutrition_data_prepared)
        self.expiration_date_debug_tags = try container.decodeIfPresent([String].self, forKey: .expiration_date_debug_tags)
        self.last_image_dates_tags = try container.decodeIfPresent([String].self, forKey: .last_image_dates_tags)
        self.labels = try container.decodeIfPresent(String.self, forKey: .labels)
        self.new_additives_n = try container.decodeIfPresent(Int.self, forKey: .new_additives_n)
        self.allergens_hierarchy = try container.decodeIfPresent([String].self, forKey: .allergens_hierarchy)
        self.product_name_fr_debug_tags = try container.decodeIfPresent([String].self, forKey: .product_name_fr_debug_tags)
        self.ingredients_text_with_allergens_fr = try container.decodeIfPresent(String.self, forKey: .ingredients_text_with_allergens_fr)
        self.origins_tags = try container.decodeIfPresent([String].self, forKey: .origins_tags)
        self.quality_tags = try container.decodeIfPresent([String].self, forKey: .quality_tags)
        self.categories_tags = try container.decodeIfPresent([String].self, forKey: .categories_tags)
        self.generic_name_fr_debug_tags = try container.decodeIfPresent([String].self, forKey: .generic_name_fr_debug_tags)
        self.code = try container.decodeIfPresent(String.self, forKey: .code)
        self.allergens = try container.decodeIfPresent(String.self, forKey: .allergens)
        self.additives_old_n = try container.decodeIfPresent(Int.self, forKey: .additives_old_n)
        self.languages = try container.decodeIfPresent(Language.self, forKey: .languages)
        self.allergens_tags = try container.decodeIfPresent([String].self, forKey: .allergens_tags)
        self.traces_lc = try container.decodeIfPresent(String.self, forKey: .traces_lc)
        self.ingredients_n = try container.decodeIfPresent(String.self, forKey: .ingredients_n)
        self.debug_param_sorted_langs = try container.decodeIfPresent([String].self, forKey: .debug_param_sorted_langs)
        self.quantity_debug_tags = try container.decodeIfPresent([String].self, forKey: .quantity_debug_tags)
        self.pnns_groups_2 = try container.decodeIfPresent(String.self, forKey: .pnns_groups_2)
        self.packaging_tags = try container.decodeIfPresent([String].self, forKey: .packaging_tags)
        self.ingredients = try container.decodeIfPresent([Ingridents2].self, forKey: .ingredients)
        self.creator = try container.decodeIfPresent(String.self, forKey: .creator)
        self.countries = try container.decodeIfPresent(String.self, forKey: .countries)
        self.nova_groups_tags = try container.decodeIfPresent([String].self, forKey: .nova_groups_tags)
        self.pnns_groups_1_tags = try container.decodeIfPresent([String].self, forKey: .pnns_groups_1_tags)
        self.unknown_ingredients_n = try container.decodeIfPresent(Int.self, forKey: .unknown_ingredients_n)
        self.ingredients_from_palm_oil_n = try container.decodeIfPresent(Int.self, forKey: .ingredients_from_palm_oil_n)
        self.cities_tags = try container.decodeIfPresent([String].self, forKey: .cities_tags)
        self.languages_hierarchy = try container.decodeIfPresent([String].self, forKey: .languages_hierarchy)
        self._keywords = try container.decodeIfPresent([String].self, forKey: ._keywords)
        self.countries_hierarchy = try container.decodeIfPresent([String].self, forKey: .countries_hierarchy)
        self.labels_prev_tags = try container.decodeIfPresent([String].self, forKey: .labels_prev_tags)
        self.states_hierarchy = try container.decodeIfPresent([String].self, forKey: .states_hierarchy)
        self.completed_t = try container.decodeIfPresent(Int16.self, forKey: .completed_t)
        self.pnns_groups_1 = try container.decodeIfPresent(String.self, forKey: .pnns_groups_1)
        self.traces = try container.decodeIfPresent(String.self, forKey: .traces)
        self.countries_debug_tags = try container.decodeIfPresent([String].self, forKey: .countries_debug_tags)
        self.image_front_small_url = try container.decodeIfPresent(String.self, forKey: .image_front_small_url)
        self.generic_name = try container.decodeIfPresent(String.self, forKey: .generic_name)
        self.complete = try container.decodeIfPresent(Int.self, forKey: .complete)
        self.misc_tags = try container.decodeIfPresent([String].self, forKey: .misc_tags)
        self.allergens_lc = try container.decodeIfPresent(String.self, forKey: .allergens_lc)
        self.categories_prev_hierarchy = try container.decodeIfPresent([String].self, forKey: .categories_prev_hierarchy)
        self.manufacturing_places_tags = try container.decodeIfPresent([String].self, forKey: .manufacturing_places_tags)
        self.ingredients_that_may_be_from_palm_oil_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_that_may_be_from_palm_oil_tags)
        self.serving_size_debug_tags = try container.decodeIfPresent([String].self, forKey: .serving_size_debug_tags)
        self.nutrition_score_debug = try container.decodeIfPresent(String.self, forKey: .nutrition_score_debug)
        self.categories_hierarchy = try container.decodeIfPresent([String].self, forKey: .categories_hierarchy)
        self.ingredients_from_or_that_may_be_from_palm_oil_n = try container.decodeIfPresent(Int.self, forKey: .ingredients_from_or_that_may_be_from_palm_oil_n)
        self.expiration_date = try container.decodeIfPresent(String.self, forKey: .expiration_date)
        self.brands_tags = try container.decodeIfPresent([String].self, forKey: .brands_tags)
        self.additives = try container.decodeIfPresent(String.self, forKey: .additives)
        self.ingredients_debug = try container.decodeIfPresent([String].self, forKey: .ingredients_debug)
        self.purchase_places_tags = try container.decodeIfPresent([String].self, forKey: .purchase_places_tags)
        self.stores = try container.decodeIfPresent(String.self, forKey: .stores)
        self._id = try container.decodeIfPresent(String.self, forKey: ._id)
        self.traces_from_user = try container.decodeIfPresent(String.self, forKey: .traces_from_user)
        self.link = try container.decodeIfPresent(String.self, forKey: .link)
        self.states_tags = try container.decodeIfPresent([String].self, forKey: .states_tags)
        self.ingredients_text_fr_debug_tags = try container.decodeIfPresent([String].self, forKey: .ingredients_text_fr_debug_tags)
        self.emb_codes_debug_tags = try container.decodeIfPresent([String].self, forKey: .emb_codes_debug_tags)
        self.languages_codes = try container.decodeIfPresent(LanguageCode.self, forKey: .languages_codes)
        self.correctors_tags = try container.decodeIfPresent([String].self, forKey: .correctors_tags)
    }
    
    
    
}
struct SelectedImages : Codable {
    var ingredients : Ingredients?
    var nutrition : Nutrients?
    var front : Front?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.ingredients, forKey: .ingredients)
        try container.encodeIfPresent(self.nutrition, forKey: .nutrition)
        try container.encodeIfPresent(self.front, forKey: .front)
    }
    enum CodingKeys: CodingKey {
        case ingredients
        case nutrition
        case front
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.ingredients = try container.decodeIfPresent(Ingredients.self, forKey: .ingredients)
        self.nutrition = try container.decodeIfPresent(Nutrients.self, forKey: .nutrition)
        self.front = try container.decodeIfPresent(Front.self, forKey: .front)
    }
    
}
struct Ingredients : Codable {
    var small : Small?
    var display : Display?
    var thumb : Thumb?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.small, forKey: .small)
        try container.encodeIfPresent(self.display, forKey: .display)
        try container.encodeIfPresent(self.thumb, forKey: .thumb)
    }
    enum CodingKeys: CodingKey {
        case small
        case display
        case thumb
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.small = try container.decodeIfPresent(Small.self, forKey: .small)
        self.display = try container.decodeIfPresent(Display.self, forKey: .display)
        self.thumb = try container.decodeIfPresent(Thumb.self, forKey: .thumb)
    }
    
    
}
struct Small : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
}
struct Display : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
}
struct Thumb : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
    
}
struct Nutrients : Codable {
    var display1 : Display1?
    var small : Small1?
    var thumb : Thumb1?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.display1, forKey: .display1)
        try container.encodeIfPresent(self.small, forKey: .small)
        try container.encodeIfPresent(self.thumb, forKey: .thumb)
    }
    enum CodingKeys: CodingKey {
        case display1
        case small
        case thumb
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.display1 = try container.decodeIfPresent(Display1.self, forKey: .display1)
        self.small = try container.decodeIfPresent(Small1.self, forKey: .small)
        self.thumb = try container.decodeIfPresent(Thumb1.self, forKey: .thumb)
    }
}
struct Display1 : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
}
struct Small1 : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
}
struct Thumb1 : Codable {
    var thumb : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.thumb, forKey: .thumb)
    }
    enum CodingKeys: CodingKey {
        case thumb
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.thumb = try container.decodeIfPresent(String.self, forKey: .thumb)
    }
}
struct Front : Codable {
    var display : Display2?
    var small : Small2?
    var thumb : Thumb2
    
}
struct Display2 : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
}
struct Small2 : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
    
}
struct Thumb2 : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }
    
}
struct NutrientsLevel : Codable {
    var fat : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fat, forKey: .fat)
    }
    enum CodingKeys: CodingKey {
        case fat
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fat = try container.decodeIfPresent(String.self, forKey: .fat)
    }
}
struct Images : Codable {
    var i1 : _1?
    var i2 : _2?
    var nutrition_fr : NutrientsFr?
    var ingredients_fr : IngridentsFr?
    var ingredients : Ingredients?
    var front_fr : FrontFr?
    var nutrition : Nutrition?
    var front : Front1?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i1, forKey: .i1)
        try container.encodeIfPresent(self.i2, forKey: .i2)
        try container.encodeIfPresent(self.nutrition_fr, forKey: .nutrition_fr)
        try container.encodeIfPresent(self.ingredients_fr, forKey: .ingredients_fr)
        try container.encodeIfPresent(self.ingredients, forKey: .ingredients)
        try container.encodeIfPresent(self.front_fr, forKey: .front_fr)
        try container.encodeIfPresent(self.nutrition, forKey: .nutrition)
        try container.encodeIfPresent(self.front, forKey: .front)
    }
    enum CodingKeys: CodingKey {
        case i1
        case i2
        case nutrition_fr
        case ingredients_fr
        case ingredients
        case front_fr
        case nutrition
        case front
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i1 = try container.decodeIfPresent(_1.self, forKey: .i1)
        self.i2 = try container.decodeIfPresent(_2.self, forKey: .i2)
        self.nutrition_fr = try container.decodeIfPresent(NutrientsFr.self, forKey: .nutrition_fr)
        self.ingredients_fr = try container.decodeIfPresent(IngridentsFr.self, forKey: .ingredients_fr)
        self.ingredients = try container.decodeIfPresent(Ingredients.self, forKey: .ingredients)
        self.front_fr = try container.decodeIfPresent(FrontFr.self, forKey: .front_fr)
        self.nutrition = try container.decodeIfPresent(Nutrition.self, forKey: .nutrition)
        self.front = try container.decodeIfPresent(Front1.self, forKey: .front)
    }
    
}
struct _1 : Codable {
    var uploader : String?
    var sizes : Sizes?
    var uploaded_t : Int16?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.uploader, forKey: .uploader)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.uploaded_t, forKey: .uploaded_t)
    }
    enum CodingKeys: CodingKey {
        case uploader
        case sizes
        case uploaded_t
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.uploader = try container.decodeIfPresent(String.self, forKey: .uploader)
        self.sizes = try container.decodeIfPresent(Sizes.self, forKey: .sizes)
        self.uploaded_t = try container.decodeIfPresent(Int16.self, forKey: .uploaded_t)
    }
    
}
struct Sizes : Codable {
    var full : Full?
    var i100 : _100?
    var i400 : _400?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.full, forKey: .full)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i400, forKey: .i400)
    }
    enum CodingKeys: CodingKey {
        case full
        case i100
        case i400
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.full = try container.decodeIfPresent(Full.self, forKey: .full)
        self.i100 = try container.decodeIfPresent(_100.self, forKey: .i100)
        self.i400 = try container.decodeIfPresent(_400.self, forKey: .i400)
    }
    
}
struct Full : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct _100  : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct _400 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct _2 : Codable {
    var uploader : String?
    var sizes : Sizes2?
    var uploaded_t : Int16?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.uploader, forKey: .uploader)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.uploaded_t, forKey: .uploaded_t)
    }
    enum CodingKeys: CodingKey {
        case uploader
        case sizes
        case uploaded_t
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.uploader = try container.decodeIfPresent(String.self, forKey: .uploader)
        self.sizes = try container.decodeIfPresent(Sizes2.self, forKey: .sizes)
        self.uploaded_t = try container.decodeIfPresent(Int16.self, forKey: .uploaded_t)
    }
}

struct Sizes2 : Codable {
    var full : Full?
    var i100 : __100?
    var i400 : __400?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.full, forKey: .full)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i400, forKey: .i400)
    }
    enum CodingKeys: CodingKey {
        case full
        case i100
        case i400
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.full = try container.decodeIfPresent(Full.self, forKey: .full)
        self.i100 = try container.decodeIfPresent(__100.self, forKey: .i100)
        self.i400 = try container.decodeIfPresent(__400.self, forKey: .i400)
    }
}
struct Full2  : Codable {
    var h : Int16?
    var w : Int16?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int16.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int16.self, forKey: .w)
    }
}
struct __100 : Codable {
    var h : Int16?
    var w : Int16?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int16.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int16.self, forKey: .w)
    }
}
struct __400 : Codable {
    var h : Int16?
    var w : Int16?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int16.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int16.self, forKey: .w)
    }
}
struct NutrientsFr : Codable {
    var geometry : String?
    var normalize : String?
    var imgid : String?
    var sizes : Sizes3?
    var white_magic : String?
    var rev : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.geometry, forKey: .geometry)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
        try container.encodeIfPresent(self.rev, forKey: .rev)
    }
    enum CodingKeys: CodingKey {
        case geometry
        case normalize
        case imgid
        case sizes
        case white_magic
        case rev
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.geometry = try container.decodeIfPresent(String.self, forKey: .geometry)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.sizes = try container.decodeIfPresent(Sizes3.self, forKey: .sizes)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
    }
}
struct Sizes3 : Codable {
    var i200 : ___200?
    var full : Full3?
    var i400 : ___400?
    var i100 : ___100?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
        try container.encodeIfPresent(self.i400, forKey: .i400)
        try container.encodeIfPresent(self.i100, forKey: .i100)
    }
    enum CodingKeys: CodingKey {
        case i200
        case full
        case i400
        case i100
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i200 = try container.decodeIfPresent(___200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full3.self, forKey: .full)
        self.i400 = try container.decodeIfPresent(___400.self, forKey: .i400)
        self.i100 = try container.decodeIfPresent(___100.self, forKey: .i100)
    }
}
struct ___200 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Full3 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
    
}
struct ___400 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
    
}
struct ___100 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
// ingridents
struct IngridentsFr : Codable {
    var imgid : String?
    var sizes : Sizes4?
    var geometry : String?
    var normalize : String?
    var rev : String?
    var white_magic : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.geometry, forKey: .geometry)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.rev, forKey: .rev)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
    }
    enum CodingKeys: CodingKey {
        case imgid
        case sizes
        case geometry
        case normalize
        case rev
        case white_magic
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.sizes = try container.decodeIfPresent(Sizes4.self, forKey: .sizes)
        self.geometry = try container.decodeIfPresent(String.self, forKey: .geometry)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
    }
}
struct Sizes4 : Codable {
    var i400 : ____400?
    var i100 :____100?
    var i200 :____200?
    var full : Full4?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i400, forKey: .i400)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
    }
    enum CodingKeys: CodingKey {
        case i400
        case i100
        case i200
        case full
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i400 = try container.decodeIfPresent(____400.self, forKey: .i400)
        self.i100 = try container.decodeIfPresent(____100.self, forKey: .i100)
        self.i200 = try container.decodeIfPresent(____200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full4.self, forKey: .full)
    }
}
struct ____400 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct ____100 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct ____200 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
struct Full4 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
// ingridents
struct Ingridents : Codable {
    var imgid : String?
    var sizes : Sizes5?
    var geometry : String?
    var normalize : String?
    var rev : String?
    var white_magic : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.geometry, forKey: .geometry)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.rev, forKey: .rev)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
    }
    enum CodingKeys: CodingKey {
        case imgid
        case sizes
        case geometry
        case normalize
        case rev
        case white_magic
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.sizes = try container.decodeIfPresent(Sizes5.self, forKey: .sizes)
        self.geometry = try container.decodeIfPresent(String.self, forKey: .geometry)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
    }
}
struct Sizes5 : Codable {
    var i400 : _____400?
    var i100 : _____100?
    var i200 : _____200?
    var full : Full5?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i400, forKey: .i400)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
    }
    enum CodingKeys: CodingKey {
        case i400
        case i100
        case i200
        case full
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i400 = try container.decodeIfPresent(_____400.self, forKey: .i400)
        self.i100 = try container.decodeIfPresent(_____100.self, forKey: .i100)
        self.i200 = try container.decodeIfPresent(_____200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full5.self, forKey: .full)
    }
}
struct _____400 : Codable {
    var h : String?
    var w : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(String.self, forKey: .h)
        self.w = try container.decodeIfPresent(String.self, forKey: .w)
    }
}
struct _____100 : Codable {
    var w : String?
    var h : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(String.self, forKey: .w)
        self.h = try container.decodeIfPresent(String.self, forKey: .h)
    }
}
struct _____200 : Codable {
    var h : String?
    var w : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(String.self, forKey: .h)
        self.w = try container.decodeIfPresent(String.self, forKey: .w)
    }
}
struct Full5 : Codable {
    var w : String?
    var h : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(String.self, forKey: .w)
        self.h = try container.decodeIfPresent(String.self, forKey: .h)
    }
}
// frontfr class

struct FrontFr : Codable {
    var normalize : String?
    var geometry : String?
    var sizes : Sizes6?
    var imgid : String?
    var rev : String?
    var white_magic : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.geometry, forKey: .geometry)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.rev, forKey: .rev)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
    }
    enum CodingKeys: CodingKey {
        case normalize
        case geometry
        case sizes
        case imgid
        case rev
        case white_magic
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.geometry = try container.decodeIfPresent(String.self, forKey: .geometry)
        self.sizes = try container.decodeIfPresent(Sizes6.self, forKey: .sizes)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
    }
}
struct Sizes6 : Codable {
    var i400 : Ii400?
    var i100 : Ii100?
    var i200 : Ii200?
    var full : Full6?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i400, forKey: .i400)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
    }
    enum CodingKeys: CodingKey {
        case i400
        case i100
        case i200
        case full
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i400 = try container.decodeIfPresent(Ii400.self, forKey: .i400)
        self.i100 = try container.decodeIfPresent(Ii100.self, forKey: .i100)
        self.i200 = try container.decodeIfPresent(Ii200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full6.self, forKey: .full)
    }
}
struct Ii400 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Ii100 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Ii200 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Full6 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
// nutrition class

struct Nutrition : Codable {
    var nutrition : String?
    var normalize : String?
    var imgid : String?
    var sizes : Sizes7?
    var white_magic : String?
    var rev : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.nutrition, forKey: .nutrition)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
        try container.encodeIfPresent(self.rev, forKey: .rev)
    }
    enum CodingKeys: CodingKey {
        case nutrition
        case normalize
        case imgid
        case sizes
        case white_magic
        case rev
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.nutrition = try container.decodeIfPresent(String.self, forKey: .nutrition)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.sizes = try container.decodeIfPresent(Sizes7.self, forKey: .sizes)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
    }
}
struct Sizes7 : Codable {
    var i200 : Iii200?
    var full : Full7?
    var i100 : Iii100?
    var i400 : Iii400?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i400, forKey: .i400)
    }
    enum CodingKeys: CodingKey {
        case i200
        case full
        case i100
        case i400
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i200 = try container.decodeIfPresent(Iii200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full7.self, forKey: .full)
        self.i100 = try container.decodeIfPresent(Iii100.self, forKey: .i100)
        self.i400 = try container.decodeIfPresent(Iii400.self, forKey: .i400)
    }
}
struct Iii200 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Full7 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Iii100 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    
}
struct Iii400 : Codable {
    var h : Int?
    var w : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.h, forKey: .h)
        try container.encodeIfPresent(self.w, forKey: .w)
    }
    enum CodingKeys: CodingKey {
        case h
        case w
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
    }
}
//for front class
struct Front1 : Codable {
    var normalize : String?
    var geometry : String?
    var sizes : Sizes8?
    var imgid : String?
    var rev : String?
    var white_magic : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.normalize, forKey: .normalize)
        try container.encodeIfPresent(self.geometry, forKey: .geometry)
        try container.encodeIfPresent(self.sizes, forKey: .sizes)
        try container.encodeIfPresent(self.imgid, forKey: .imgid)
        try container.encodeIfPresent(self.rev, forKey: .rev)
        try container.encodeIfPresent(self.white_magic, forKey: .white_magic)
    }
    enum CodingKeys: CodingKey {
        case normalize
        case geometry
        case sizes
        case imgid
        case rev
        case white_magic
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.normalize = try container.decodeIfPresent(String.self, forKey: .normalize)
        self.geometry = try container.decodeIfPresent(String.self, forKey: .geometry)
        self.sizes = try container.decodeIfPresent(Sizes8.self, forKey: .sizes)
        self.imgid = try container.decodeIfPresent(String.self, forKey: .imgid)
        self.rev = try container.decodeIfPresent(String.self, forKey: .rev)
        self.white_magic = try container.decodeIfPresent(String.self, forKey: .white_magic)
    }
}
struct Sizes8 : Codable {
    var i400 : Second400?
    var i100 : Second100?
    var i200 : Second200?
    var full : Full8?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.i400, forKey: .i400)
        try container.encodeIfPresent(self.i100, forKey: .i100)
        try container.encodeIfPresent(self.i200, forKey: .i200)
        try container.encodeIfPresent(self.full, forKey: .full)
    }
    enum CodingKeys: CodingKey {
        case i400
        case i100
        case i200
        case full
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.i400 = try container.decodeIfPresent(Second400.self, forKey: .i400)
        self.i100 = try container.decodeIfPresent(Second100.self, forKey: .i100)
        self.i200 = try container.decodeIfPresent(Second200.self, forKey: .i200)
        self.full = try container.decodeIfPresent(Full8.self, forKey: .full)
    }
}
struct Second400 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Second100 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Second200 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
struct Full8 : Codable {
    var w : Int?
    var h : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.w, forKey: .w)
        try container.encodeIfPresent(self.h, forKey: .h)
    }
    enum CodingKeys: CodingKey {
        case w
        case h
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.w = try container.decodeIfPresent(Int.self, forKey: .w)
        self.h = try container.decodeIfPresent(Int.self, forKey: .h)
    }
}
// for nutriments class

struct Nutriments : Codable {
    var humidity_serving : String?
    var fat : Float?
    var humidity : String?
    var nova_group : String?
    var nova_group_100g : String?
    var humidity_label : String?
    var fibre_serving : Float?
    var fibre_value : String?
    var proteins_serving : String?
    var fat_value : String?
    var fat_serving : Float?
    var fat_100g : Float?
    var fibre_100g : Float?
    var humidity_100g : String?
    var fibre_unit : String?
    var proteins_unit : String?
    var ash_unit : String?
    var ash_value : String?
    var fat_unit : String?
    var ash_100g : String?
    var proteins_value : String?
    var humidity_value : String?
    var humidity_unit : String?
    var fibre : Float?
    var proteins_100g : String?
    var proteins : String?
    var ash : String?
    var fibre_label : String?
    var nova_group_serving : String?
    var ash_serving : String?
    var ash_label : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.humidity_serving, forKey: .humidity_serving)
        try container.encodeIfPresent(self.fat, forKey: .fat)
        try container.encodeIfPresent(self.humidity, forKey: .humidity)
        try container.encodeIfPresent(self.nova_group, forKey: .nova_group)
        try container.encodeIfPresent(self.nova_group_100g, forKey: .nova_group_100g)
        try container.encodeIfPresent(self.humidity_label, forKey: .humidity_label)
        try container.encodeIfPresent(self.fibre_serving, forKey: .fibre_serving)
        try container.encodeIfPresent(self.fibre_value, forKey: .fibre_value)
        try container.encodeIfPresent(self.proteins_serving, forKey: .proteins_serving)
        try container.encodeIfPresent(self.fat_value, forKey: .fat_value)
        try container.encodeIfPresent(self.fat_serving, forKey: .fat_serving)
        try container.encodeIfPresent(self.fat_100g, forKey: .fat_100g)
        try container.encodeIfPresent(self.fibre_100g, forKey: .fibre_100g)
        try container.encodeIfPresent(self.humidity_100g, forKey: .humidity_100g)
        try container.encodeIfPresent(self.fibre_unit, forKey: .fibre_unit)
        try container.encodeIfPresent(self.proteins_unit, forKey: .proteins_unit)
        try container.encodeIfPresent(self.ash_unit, forKey: .ash_unit)
        try container.encodeIfPresent(self.ash_value, forKey: .ash_value)
        try container.encodeIfPresent(self.fat_unit, forKey: .fat_unit)
        try container.encodeIfPresent(self.ash_100g, forKey: .ash_100g)
        try container.encodeIfPresent(self.proteins_value, forKey: .proteins_value)
        try container.encodeIfPresent(self.humidity_value, forKey: .humidity_value)
        try container.encodeIfPresent(self.humidity_unit, forKey: .humidity_unit)
        try container.encodeIfPresent(self.fibre, forKey: .fibre)
        try container.encodeIfPresent(self.proteins_100g, forKey: .proteins_100g)
        try container.encodeIfPresent(self.proteins, forKey: .proteins)
        try container.encodeIfPresent(self.ash, forKey: .ash)
        try container.encodeIfPresent(self.fibre_label, forKey: .fibre_label)
        try container.encodeIfPresent(self.nova_group_serving, forKey: .nova_group_serving)
        try container.encodeIfPresent(self.ash_serving, forKey: .ash_serving)
        try container.encodeIfPresent(self.ash_label, forKey: .ash_label)
    }
    enum CodingKeys: CodingKey {
        case humidity_serving
        case fat
        case humidity
        case nova_group
        case nova_group_100g
        case humidity_label
        case fibre_serving
        case fibre_value
        case proteins_serving
        case fat_value
        case fat_serving
        case fat_100g
        case fibre_100g
        case humidity_100g
        case fibre_unit
        case proteins_unit
        case ash_unit
        case ash_value
        case fat_unit
        case ash_100g
        case proteins_value
        case humidity_value
        case humidity_unit
        case fibre
        case proteins_100g
        case proteins
        case ash
        case fibre_label
        case nova_group_serving
        case ash_serving
        case ash_label
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.humidity_serving = try container.decodeIfPresent(String.self, forKey: .humidity_serving)
        self.fat = try container.decodeIfPresent(Float.self, forKey: .fat)
        self.humidity = try container.decodeIfPresent(String.self, forKey: .humidity)
        self.nova_group = try container.decodeIfPresent(String.self, forKey: .nova_group)
        self.nova_group_100g = try container.decodeIfPresent(String.self, forKey: .nova_group_100g)
        self.humidity_label = try container.decodeIfPresent(String.self, forKey: .humidity_label)
        self.fibre_serving = try container.decodeIfPresent(Float.self, forKey: .fibre_serving)
        self.fibre_value = try container.decodeIfPresent(String.self, forKey: .fibre_value)
        self.proteins_serving = try container.decodeIfPresent(String.self, forKey: .proteins_serving)
        self.fat_value = try container.decodeIfPresent(String.self, forKey: .fat_value)
        self.fat_serving = try container.decodeIfPresent(Float.self, forKey: .fat_serving)
        self.fat_100g = try container.decodeIfPresent(Float.self, forKey: .fat_100g)
        self.fibre_100g = try container.decodeIfPresent(Float.self, forKey: .fibre_100g)
        self.humidity_100g = try container.decodeIfPresent(String.self, forKey: .humidity_100g)
        self.fibre_unit = try container.decodeIfPresent(String.self, forKey: .fibre_unit)
        self.proteins_unit = try container.decodeIfPresent(String.self, forKey: .proteins_unit)
        self.ash_unit = try container.decodeIfPresent(String.self, forKey: .ash_unit)
        self.ash_value = try container.decodeIfPresent(String.self, forKey: .ash_value)
        self.fat_unit = try container.decodeIfPresent(String.self, forKey: .fat_unit)
        self.ash_100g = try container.decodeIfPresent(String.self, forKey: .ash_100g)
        self.proteins_value = try container.decodeIfPresent(String.self, forKey: .proteins_value)
        self.humidity_value = try container.decodeIfPresent(String.self, forKey: .humidity_value)
        self.humidity_unit = try container.decodeIfPresent(String.self, forKey: .humidity_unit)
        self.fibre = try container.decodeIfPresent(Float.self, forKey: .fibre)
        self.proteins_100g = try container.decodeIfPresent(String.self, forKey: .proteins_100g)
        self.proteins = try container.decodeIfPresent(String.self, forKey: .proteins)
        self.ash = try container.decodeIfPresent(String.self, forKey: .ash)
        self.fibre_label = try container.decodeIfPresent(String.self, forKey: .fibre_label)
        self.nova_group_serving = try container.decodeIfPresent(String.self, forKey: .nova_group_serving)
        self.ash_serving = try container.decodeIfPresent(String.self, forKey: .ash_serving)
        self.ash_label = try container.decodeIfPresent(String.self, forKey: .ash_label)
    }
}

// for language class
struct Language : Codable {
    var en_french : Int?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.en_french, forKey: .en_french)
    }
    enum CodingKeys: CodingKey {
        case en_french
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.en_french = try container.decodeIfPresent(Int.self, forKey: .en_french)
    }
}
// for 2 ingrident class

struct Ingridents2 : Codable {
    var text : String?
    var rank : Int?
    var id : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.text, forKey: .text)
        try container.encodeIfPresent(self.rank, forKey: .rank)
        try container.encodeIfPresent(self.id, forKey: .id)
    }
    enum CodingKeys: CodingKey {
        case text
        case rank
        case id
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.text = try container.decodeIfPresent(String.self, forKey: .text)
        self.rank = try container.decodeIfPresent(Int.self, forKey: .rank)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
    }
    
}
// language code class
struct LanguageCode : Codable {
    var fr : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.fr, forKey: .fr)
    }
    enum CodingKeys: CodingKey {
        case fr
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.fr = try container.decodeIfPresent(String.self, forKey: .fr)
    }

}
