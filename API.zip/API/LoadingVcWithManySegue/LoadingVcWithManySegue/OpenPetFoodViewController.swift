//
//  OpenPetFoodViewController.swift
//  LoadingVcWithManySegue
//
//  Created by Swapnil Sahare on 03/01/23.
//

import UIKit

class OpenPetFoodViewController: UIViewController {
    
    @IBOutlet weak var petFoodTextView : UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
