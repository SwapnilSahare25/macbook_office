//
//  DetailViewController.swift
//  EmployeDetails
//
//  Created by Swapnil Sahare on 22/01/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel : UILabel!
    @IBOutlet weak var idlabel : UILabel!
    @IBOutlet weak var salaryLabel : UILabel!
    @IBOutlet weak var ageLabel : UILabel!
    
    var employee : Data?
    let createDict : [String : Any] = ["name":"Swapnil Sahare","salary":"30000","age":"25"]
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(employee)
        nameLabel.text = employee?.employeeName
        idlabel.text = "\(employee?.id ?? 0)"
        salaryLabel.text = "\(employee?.employeeSalary ?? 0)"
        ageLabel.text = "\(employee?.employeeAge ?? 0)"

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
