//
//  EmployeModel.swift
//  EmployeDetails
//
//  Created by Swapnil Sahare on 22/01/23.
//

import Foundation

struct Employee : Codable {
    var status : String?
    var data : [Data]?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.status, forKey: .status)
        try container.encodeIfPresent(self.data, forKey: .data)
    }
    enum CodingKeys: CodingKey {
        case status
        case data
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.status = try container.decodeIfPresent(String.self, forKey: .status)
        self.data = try container.decodeIfPresent([Data].self, forKey: .data)
    }
}
struct Data : Codable {
    var id : Int?
    var employeeName : String?
    var employeeSalary : Int?
    var employeeAge : Int?
    var profileImage : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.employeeName, forKey: .employeeName)
        try container.encodeIfPresent(self.employeeSalary, forKey: .employeeSalary)
        try container.encodeIfPresent(self.employeeAge, forKey: .employeeAge)
        try container.encodeIfPresent(self.profileImage, forKey: .profileImage)
    }
    enum CodingKeys: String, CodingKey {
        case id
        case employeeName = "employee_name"
        case employeeSalary = "employee_salary"
        case employeeAge = "employee_age"
        case profileImage = "profile_image"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(Int.self, forKey: .id)
        self.employeeName = try container.decodeIfPresent(String.self, forKey: .employeeName)
        self.employeeSalary = try container.decodeIfPresent(Int.self, forKey: .employeeSalary)
        self.employeeAge = try container.decodeIfPresent(Int.self, forKey: .employeeAge)
        self.profileImage = try container.decodeIfPresent(String.self, forKey: .profileImage)
    }
}
struct EmployeeRequest : Encodable {
    var name : String?
    var salary : String?
    var age : String?
    
    enum CodingKeys: String, CodingKey {
        case name = "employee_name"
        case salary = "employee_salary"
        case age = "employee_age"
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.salary, forKey: .salary)
        try container.encodeIfPresent(self.age, forKey: .age)
    }
}
