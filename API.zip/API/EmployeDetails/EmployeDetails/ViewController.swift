//
//  ViewController.swift
//  EmployeDetails
//
//  Created by Swapnil Sahare on 22/01/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var employeetableView : UITableView!
    @IBOutlet weak var nameView : UIView!
    @IBOutlet weak var nameLabel : UILabel!
    
    var employee : Employee?
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        // Do any additional setup after loading the view.
    }
    func getData(){
        let url = "https://dummy.restapiexample.com/api/v1/employees"
        guard let url = URL(string: url) else {return}
                let request = URLRequest(url: url)
                let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
                    if error == nil {
                        guard let data = data else {return}
                        do{
                            self.employee = try JSONDecoder().decode(Employee.self, from: data)
                        }catch let er{
                            print(er)
                        }
                        DispatchQueue.main.async {
                            self.employeetableView.reloadData()
                        }
                    }
                }
            dataTask.resume()
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employee?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = employeetableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let employeeName  = employee?.data![indexPath.row].employeeName
        cell.textLabel?.text = employeeName
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let employeeId = employee?.data![indexPath.row]
        self.performSegue(withIdentifier: "Response", sender: employeeId)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            var targetVc = segue.destination as? DetailViewController
            let employee = sender as! Data?
            //print(employee)
            targetVc?.employee = employee
        }
    }
    
}
