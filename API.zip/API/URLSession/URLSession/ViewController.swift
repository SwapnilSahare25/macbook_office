//
//  ViewController.swift
//  URLSession
//
//  Created by Swapnil Sahare on 29/12/22.
//

import UIKit
// 1
struct Response: Codable {
    var universities: [University]
    enum CodingKeys: CodingKey {
        case universities
    }
}
//2
let url = "http://universities.hipolabs.com/search?country=China"

class ViewController: UIViewController {
    //3
  //  var response: Response?
    var universityArray: [University]?
    var responseData: Data = Data()
    
    @IBOutlet weak var myTableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //9
        performSession()
    }


}
//4
extension ViewController {
    //5
    func createRequest() -> URLRequest? {
        guard let uniUrl = URL(string: url) else {return nil}
        
        let request = URLRequest(url: uniUrl)
        return request
    }
    //6
    func performSession(){
        
        guard let request = self.createRequest() else {return}
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession.init(configuration: configuration)
        
        session.dataTask(with: request){data,response,error in
            guard error == nil else {
                return
            }
            if let response = response as? HTTPURLResponse,
                let data = data {
                if response.statusCode == 200 {
                    self.parseData(data)
                }
            }
        }.resume()
    }
    //7
    func parseData(_ data:Data){
        do{
            let decoder = JSONDecoder()
            universityArray = try decoder.decode([University].self, from: data)
            DispatchQueue.main.async {[weak self] in
                guard let self = self else {return}
                
                self.myTableView.reloadData()
            }
            
        }catch let error{
            print(error)
            
        }
    }
    
}
//8
extension ViewController : URLSessionTaskDelegate,URLSessionDataDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard error != nil else {
            return
        }
        self.parseData(responseData)
    }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        self.responseData.append(data)
    }
}

//10
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universityArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        guard let arrey = universityArray else {
            return cell
        }
        let university : University = arrey[indexPath.row]
        cell.textLabel?.text = university.name
        cell.detailTextLabel?.text = university.domains?[0] ?? "no domains"
        
        return cell
    }
    
    
}


