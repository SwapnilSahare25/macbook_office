//
//  AuthorDetailViewController.swift
//  AuthorAndPoemProjectPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import UIKit

class AuthorDetailViewController: UIViewController {

    @IBOutlet weak var titleView : UIView!
    @IBOutlet weak var poemLabel : UILabel!
    @IBOutlet weak var poemTableView : UITableView!

    
    var name : String?
    var titleArray : [Title]?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
       
        // Do any additional setup after loading the view.
    }
    func getData(){
        var baseUrl = "https://poetrydb.org/author/"
        let query = name?.addingPercentEncoding(withAllowedCharacters: .urlUserAllowed) ?? ""
        baseUrl.append(query)
        let url = URL(string: baseUrl)
        let request = URLRequest(url: url!)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do{
                self.titleArray = try JSONDecoder().decode([Title].self, from: data)
            }catch let error{
                print(error)
            }
            DispatchQueue.main.async {
                self.poemTableView.reloadData()
            }
            
        }
        dataTask.resume()
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AuthorDetailViewController : UITableViewDataSource ,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = poemTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AuthorTableViewCell
        let title : Title = titleArray![indexPath.row]
        cell.authorNameLabel.text = "Name : \(title.author!)"
        cell.authorPoemLabel.text = "Poem : \(title.title!)"
        return cell
    }
}

