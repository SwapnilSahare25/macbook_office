//
//  ViewController.swift
//  AuthorAndPoemProjectPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import UIKit

class ViewController: UIViewController ,ConnectionManagerDelegate {
    
    var author : Author?
    var filterData : [String]!
    
    @IBOutlet weak var authorTableView : UITableView!
    @IBOutlet weak var nameSearchBar : UISearchBar!
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        filterData = author?.authors ?? []
        connection.delegate = self
        connection.startSession()
        nameSearchBar.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func didFinishedTask(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else {return}
            do {
                self.author = try JSONDecoder().decode(Author.self, from: data)
            }catch let error{
                print(error)
            }
            DispatchQueue.main.async {
                self.authorTableView.reloadData()
            }
            
        }
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return author?.authors?.count ?? 0
        return filterData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authorTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        //let authorName = author?.authors![indexPath.row]
        let authorName = filterData[indexPath.row]
        cell.textLabel?.text = authorName
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let authorTitle = author?.authors![indexPath.row]
        self.performSegue(withIdentifier: "Response", sender: authorTitle)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            let targetVc = segue.destination as! AuthorDetailViewController
            targetVc.name = sender as? String ?? ""
        }
    }
}
extension ViewController : UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterData = []
        if searchText == "" {
            filterData = author?.authors ?? []
            //author?.authors = filterData
        }
        for item in author?.authors ?? [] {
            if item.uppercased().contains(searchText.uppercased()){
                filterData.append(item)
            }
        }
        self.authorTableView.reloadData()
    }
}
