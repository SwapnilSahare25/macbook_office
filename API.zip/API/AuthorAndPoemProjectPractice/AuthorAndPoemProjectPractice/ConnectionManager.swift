//
//  ConnectionManager.swift
//  AuthorAndPoemProjectPractice
//
//  Created by Swapnil Sahare on 12/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    func didFinishedTask(data: Data?,error : Error?)
}
    let url = "https://poetrydb.org/author"

class ConnectionManager {
    var delegate : ConnectionManagerDelegate?
    
        func startSession(){
            guard let delegate = self.delegate else {return}
            self.startTask(url)
        }
    
    func startTask(_ url :String){
        guard let url = URL(string: url) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {return}
            delegate.didFinishedTask(data: data, error: error)
        }
        dataTask.resume()
    }
}
