//
//  nagerDateViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import UIKit

class NagerDateViewController: UIViewController ,ConnectionManagerDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async {
            self.removeLoading()
        }
        if error == nil {
            guard let data = data else {return}
            do{
                self.nagerData = try JSONDecoder().decode([NagerData].self, from: data)
            }catch let e{
                print(e)
            }
           // let text = String(data: data, encoding: .utf8)
            DispatchQueue.main.async {
                self.nagerDateTableView.reloadData()
                //self.nagerDateTextView.text = text
            }
        }
    }
    
    


    @IBOutlet weak var nagerDateTableView : UITableView!
    
    var nagerData : [NagerData]?
    let connection = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        connection.delegate = self
       
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.showLoading()
        connection.startSession()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension NagerDateViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nagerData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = nagerDateTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let data : NagerData = nagerData![indexPath.row]
        cell.textLabel?.text = data.name
        cell.detailTextLabel?.text = data.date
        return cell
    }
    
    
}
