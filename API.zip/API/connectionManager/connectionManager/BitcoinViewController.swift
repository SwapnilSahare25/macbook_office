//
//  BitcoinViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 04/01/23.
//

import UIKit

class BitcoinViewController: UIViewController, ConnectionManagerDelegate {
    
    var api: API?
    var myData: BitCoin?
    let cellSpacing  : CGFloat = 10.0
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        
        if error == nil {
            guard let data = data else {return}
            do{
                self.bitCoin =  try JSONDecoder().decode([BitCoin].self, from: data)
            }catch let e{
                print(e)
            }
            DispatchQueue.main.async {
                self.bitcoinTableView.reloadData()
            }
            
        }
    }
    
    
    @IBOutlet weak var bitcoinTableView : UITableView!

    
    var bitCoin : [BitCoin]?
    let connection = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        connection.delegate = self
        //self.navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
        connection.startSession()
    }

}
extension BitcoinViewController : UITableViewDataSource , UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacing
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bitCoin?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = bitcoinTableView.dequeueReusableCell(withIdentifier: "BitcoinTableViewCell", for: indexPath) as! BitcoinTableViewCell
        let bitcoinData : BitCoin = bitCoin![indexPath.row]
        myData = bitcoinData
        cell.nameLabel.text = bitcoinData.name
        //cell.symbolLabel.text = bitcoinData.symbol
        //cell.totalSupplyLabel.text = "\(bitcoinData.totalSupply ?? 0)"   // string interpolation convert int to string
        cell.coinRankLabel.text = "#\(bitcoinData.rank ?? 0)"
        cell.idlabel.text = bitcoinData.id
        //cell.lastUpadateLabel.text = bitcoinData.lastUpdated
         //cell.configure(dateStr: bitcoinData.lastUpdated ?? "")

        cell.layer.borderWidth = 1
        cell.layer.borderColor = UIColor.blue.cgColor
        cell.layer.cornerRadius = 20
        
        
        
        return cell
    }
    //    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    //
    //        let headerView = UIView()
    //        headerView.backgroundColor = view.backgroundColor
    //        return headerView
    //    }
    //
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "BitCoinResponse", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "BitCoinResponse" {
            
            let targetVC = segue.destination as? BitCoinResponseViewController
            targetVC?.bitcoinData = myData
        }
        
    }
}


