//
//  BitcoinTableViewCell.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 04/01/23.
//

import UIKit

class BitcoinTableViewCell: UITableViewCell {

    @IBOutlet weak var cellView : UIView!
    
    @IBOutlet weak var nameLabel : UILabel!
    
    @IBOutlet weak var coinRankLabel : UILabel!
    @IBOutlet weak var idlabel : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        let gradientLayer = CAGradientLayer()
//        gradientLayer.frame = cellView.frame
//        let fromColor  = UIColor.yellow.cgColor
//        let midddleColor  = UIColor.red.cgColor
//        let lastColor  = UIColor.purple.cgColor
//        gradientLayer.colors = [fromColor, midddleColor, lastColor]
//        cellView.layer.addSublayer(gradientLayer)
//        cellView.addSubview(symbolLabel)
        // Initialization code
        
//        let gradient = CAGradientLayer()
//        gradient.colors = [UIColor.red.cgColor,UIColor.blue.cgColor,UIColor.green.cgColor]
//        gradient.frame = cellView.frame
//        cellView.layer.addSublayer(gradient)
//        cellView.addSubview(symbolLabel)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
//    func configure(dateStr : String){
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
//        formatter.timeZone = TimeZone.gmt
//        
//        guard  let date = formatter.date(from: dateStr) else {
//            lastUpadateLabel.text = "Do not Convert"
//            return
//        }
//        formatter.timeZone = TimeZone(identifier: "PST")
//        formatter.dateFormat = "D MMM YYYY, hh:mm:ss a"
//        let str = formatter.string(from: date)
//            lastUpadateLabel.text = str
//    }
//   
}
