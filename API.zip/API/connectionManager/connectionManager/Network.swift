//
//  Network.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 29/12/22.
//

import Foundation

protocol ConnectionManagerDelegate {
    var api: API? {get set}
    
    func didFinishedTaskWithResponse(data : Data? , error : Error?)
}

enum API : String {
    
    case nagerdate = "https://date.nager.at/api/v2/publicholidays/2020/US"
    case randomuser = "https://randomuser.me/api/"
    case coinpaprika = "https://api.coinpaprika.com/v1/coins/btc-bitcoin"
    case teleport = "https://api.teleport.org/api/urban_areas/teleport%3A9q8yy/scores/"
    case university = "http://universities.hipolabs.com/search?country=United+Kingdom"
    case bitcoin = "https://api.coinpaprika.com/v1/tickers"
}
class ConnectionManager {
    //instance create of protocol
    var delegate : ConnectionManagerDelegate?
   // var URLSession
    
   // let shared = ConnectionManager()
    private let session: URLSession = URLSession.shared
    
    init(){
    }
    
    func startSession() {
        guard let delegate = self.delegate,  // delegate is optional thats why guard let is used
              let api = delegate.api  else {return}
        let url = api.rawValue  // values under api stored in url
        self.startTask(url)  // hit value in method
    }
    
   private func startTask(_ url : String) {
        
        guard let myurl = URL(string: url) else {return}
        
        let request = URLRequest(url: myurl)
        // pass url as a parameter in session and hit
       let dataTask =  session.dataTask(with: request) { data, response, error in
           guard let delegate = self.delegate else {return}
           delegate.didFinishedTaskWithResponse(data: data, error: error)
           
       }
       dataTask.resume()
    }
}
//ConnectionManager.shared
//.shared is use throughout tha app
