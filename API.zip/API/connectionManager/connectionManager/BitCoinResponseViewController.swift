//
//  BitCoinResponseViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 05/01/23.
//

import UIKit


class BitCoinResponseViewController: UIViewController {
    
    @IBOutlet weak var symbolView : UIView!
    @IBOutlet weak var bitcoinSymbolView : UIView!
    @IBOutlet weak var symbolLabel : UILabel!
    @IBOutlet weak var percent15mLabel: UILabel!
    @IBOutlet weak var percentchange30mLabel: UILabel!
    @IBOutlet weak var percentchange1h: UILabel!
    @IBOutlet weak var percentchange6h: UILabel!
    @IBOutlet weak var percentchange12h: UILabel!
    @IBOutlet weak var percentchange24h: UILabel!
    @IBOutlet weak var percentchange7d: UILabel!
    @IBOutlet weak var percentchange30d: UILabel!
    @IBOutlet weak var percentchange1year: UILabel!
    @IBOutlet weak var totalSupplyLabel : UILabel!
    @IBOutlet weak var firstDataAtLabel : UILabel!
    @IBOutlet weak var lastUpdatedLabel : UILabel!
    
    var bitcoinData : BitCoin?
    var quotedata : Quote?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        symbolLabel.text = "\(bitcoinData!.symbol!)"
        totalSupplyLabel.text = "Total Supply : \(bitcoinData!.totalSupply!)"
        firstDataAtLabel.text = "First Data At : \(bitcoinData!.firstDataAt!)"
        //lastUpdatedLabel.text = "Last Updated : \(bitcoinData!.lastUpdated!)"
        let config: () = configure(dateStr: bitcoinData!.lastUpdated!)
        //print(config)
        
        percent15mLabel.text = "\(quotedata?.percentChange15m ?? 0)"
        percentchange30mLabel.text = "\(quotedata?.percentChange30m ?? 0)"
        percentchange1h.text = "\(quotedata?.percentChange1h ?? 0)"
        percentchange6h.text = "\(quotedata?.percentChange6h ?? 0)"
        percentchange12h.text = "\(quotedata?.percentChange12h ?? 0)"
        percentchange24h.text = "\(quotedata?.percentChange24h ?? 0)"
        percentchange7d.text = "\(quotedata?.percentChange7d ?? 0)"
        percentchange30d.text = "\(quotedata?.percentChange30d ?? 0)"
        percentchange1year.text = "\(quotedata?.percentChange1y ?? 0)"
        
//        bitCoinResponseTableView.delegate = self
//        bitCoinResponseTableView.dataSource = self
//        print(responseData)
       // Do any additional setup after loading the view.
       
        
    }
    override func viewDidAppear(_ animated: Bool) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bitcoinSymbolView.frame
        gradientLayer.colors = [UIColor.green.cgColor,UIColor.blue.cgColor,UIColor.red.cgColor]
        //gradientLayer.frame = bitSymbolView.bounds
        //gradientLayer.cornerRadius = gradientLayer.frame.size.width/2
        gradientLayer.cornerRadius = gradientLayer.frame.size.height/2
        bitcoinSymbolView.layer.addSublayer(gradientLayer)
        bitcoinSymbolView.addSubview(symbolLabel)
        
        
        
        
      
        
    }
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func configure(dateStr : String){
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            formatter.timeZone = TimeZone.gmt
    
            guard  let date = formatter.date(from: dateStr) else {
                lastUpdatedLabel.text = "Do not Convert"
                return
            }
            formatter.timeZone = TimeZone(identifier: "PST")
            formatter.dateFormat = "D MMM YYYY, hh:mm:ss a"
            let str = formatter.string(from: date)
                lastUpdatedLabel.text = str
                
        }
    
}
//extension BitCoinResponseViewController : UITableViewDataSource , UITableViewDelegate {
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return quoteData?[section].quotes?.values.count ?? 0
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = bitCoinResponseTableView.dequeueReusableCell(withIdentifier: "bitCoinCell", for: indexPath) as! BitCoinResponseTableViewCell

//this data
//        guard let currencyDetail = quoteData?[indexPath.row].quotes else {return cell}
//        //let value = quoteData?[indexPath.row].quotes
//        //let quotesKeys = value?.keys
//        let keys = [String] (currencyDetail.keys)
//        //print(keys)
//        let key = keys[indexPath.row]  //section
//        //print(key)
//        guard let value: Quote = currencyDetail[key] else {return cell}

//    sendinigdata = value
//var aba = cryptodata = cryptodata[i.r].quotes
//allsenddaata = aba
//        cell.infoLabel.text = "AuthDate : \(value.athDate!)"

//        return cell
//    }
    
    
    

