//
//  randomUserViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import UIKit

class RandomUserViewController: UIViewController,ConnectionManagerDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async {
            self.removeLoading()
        }
        if error == nil {
            guard let data = data else {return}
            do{
                self.randomUser = try JSONDecoder().decode(RandomUser.self, from: data)
            }catch let e{
                print(e)
            }
            DispatchQueue.main.async {
                self.randomUserTableView.reloadData()
            }
        }
    }
    
   
    
    @IBOutlet weak var randomUserTableView : UITableView!
    
    var randomUser : RandomUser?
    
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        randomUserTableView.delegate = self
        randomUserTableView.dataSource = self
        
        connection.delegate = self
        
//        userView.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
//        userView.isHidden = false
//        userActivityIndicator.startAnimating()
        connection.startSession()
        self.showLoading()
    }
}
extension RandomUserViewController : UITableViewDataSource ,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return randomUser?.results?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = randomUserTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let result : Result = randomUser!.results![indexPath.row]
        cell.textLabel?.text = result.name?.first
        cell.detailTextLabel?.text = result.name?.last
        return cell
        
    }
    
    
}
