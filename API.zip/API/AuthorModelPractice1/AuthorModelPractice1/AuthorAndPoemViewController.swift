//
//  AuthorAndPoemViewController.swift
//  AuthorModelPractice1
//
//  Created by Swapnil Sahare on 13/01/23.
//

import UIKit

class AuthorAndPoemViewController: UIViewController {
    
    @IBOutlet weak var authorAndPoemTableView : UITableView!
    var name : String?
    var titleName : [TitleAndName]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        poetAndPoem()
        authorAndPoemTableView.delegate = self
        authorAndPoemTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        self.showLoading()
    }
    
    func poetAndPoem(){
        var urlStr = "https://poetrydb.org/author/"
        let query = name?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        urlStr.append(query)
        guard let url = URL(string: urlStr) else {return}
        let request = URLRequest(url: url)
        
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.removeLoading()
            }
            if error == nil {
                guard let data = data else {return}
                do{
                    self.titleName = try JSONDecoder().decode([TitleAndName].self, from: data)
                }catch let error{
                    print(error)
                }
                DispatchQueue.main.async {
                    self.authorAndPoemTableView.reloadData()
                }
            }
        }
        dataTask.resume()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AuthorAndPoemViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleName?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authorAndPoemTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AuthorAndPoemTableViewCell
        let titlNameAndPoem : TitleAndName = titleName![indexPath.row]
        cell.nameLabel.text = titlNameAndPoem.author
        cell.poemlabel.text = titlNameAndPoem.title
        cell.lineCount.text = titlNameAndPoem.linecount
        // font change
        cell.nameLabel.font = UIFont.groteskMedium(with: 15)
        cell.poemlabel.font = UIFont.groteskMedium(with: 15)
        cell.lineCount.font = UIFont.groteskMedium(with: 15)
        return cell
        
    }
}
extension AuthorAndPoemViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let poemTitle : TitleAndName = titleName![indexPath.row]
        let poem : [String] = poemTitle.lines ?? [""]
        //print(poem)
        self.performSegue(withIdentifier: "Response", sender: poem)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            
            let targetVc = segue.destination as! PoemViewController
            //print(targetVc)
            let poemLines = sender as! [String]
            targetVc.poem = poemLines.joined(separator: ".")
//print(poemLines)
        }
    }
}
