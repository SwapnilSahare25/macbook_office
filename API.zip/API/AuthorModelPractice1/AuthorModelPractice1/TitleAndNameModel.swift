//
//  TitleAndNameModel.swift
//  AuthorModelPractice1
//
//  Created by Swapnil Sahare on 13/01/23.
//

import Foundation


struct TitleAndName : Codable {
    var title : String?
    var author : String?
    var lines : [String]?
    var linecount : String?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.title, forKey: .title)
        try container.encodeIfPresent(self.author, forKey: .author)
        try container.encodeIfPresent(self.lines, forKey: .lines)
        try container.encodeIfPresent(self.linecount, forKey: .linecount)
    }
    enum CodingKeys: CodingKey {
        case title
        case author
        case lines
        case linecount
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.author = try container.decodeIfPresent(String.self, forKey: .author)
        self.lines = try container.decodeIfPresent([String].self, forKey: .lines)
        self.linecount = try container.decodeIfPresent(String.self, forKey: .linecount)
    }
}
