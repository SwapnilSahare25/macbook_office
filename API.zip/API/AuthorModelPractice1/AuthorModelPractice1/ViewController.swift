//
//  ViewController.swift
//  AuthorModelPractice1
//
//  Created by Swapnil Sahare on 13/01/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var authorTableView : UITableView!
    @IBOutlet weak var nameView : UIView!
    @IBOutlet weak var nameLabel : UILabel!
    
    var author : Author?
    
    let url = "https://poetrydb.org/author"
    
//    let searchBar = UISearchController(searchResultsController: nil)
//    var filterData = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        hitUrl(url)
        authorTableView.delegate = self
        authorTableView.dataSource = self
//        searchBarUI()
//        getFilteredData()
        
        
        // Do any additional setup after loading the view.
    }
    
    
    func hitUrl (_ url : String){
        let url = URL(string: url)
        let request = URLRequest(url: url!)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            if error == nil {
                guard let data = data else {return}
                do{
                    self.author = try JSONDecoder().decode(Author.self, from: data)
                }catch let error{
                    print(error)
                }
                DispatchQueue.main.async {
                    self.authorTableView.reloadData()
                }
                
            }
        }
        dataTask.resume()
    }

}
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return author?.authors?.count ?? 0
        //return filterData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authorTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let authorName = author?.authors![indexPath.row]
        //let authorName = filterData[indexPath.row]
        cell.textLabel?.text = authorName
        cell.textLabel?.font = UIFont.groteskBold(with: 40)
        return cell
    }
    
}
extension ViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let authorRowTap = author?.authors![indexPath.row]
        self.performSegue(withIdentifier: "AuthorResponse", sender: authorRowTap)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AuthorResponse"{
            let targetVc = segue.destination as! AuthorAndPoemViewController
            targetVc.name = sender as? String
            
        }
    }
}
//extension ViewController : UISearchBarDelegate {
//    func searchBarUI(){
//        searchBar.searchBar.delegate = self
//        searchBar.obscuresBackgroundDuringPresentation = false
//        searchBar.searchBar.sizeToFit()
//        //navigationItem.searchController = searchBar
//    }
//
//    func getFilteredData(searchedText: String = String()){
//        let filteredListData: [String] = author?.authors!.filter({ (object) -> Bool in
//                   searchedText.isEmpty ? true : object.lowercased().contains(searchedText.lowercased())
//        }) ?? [""]
//        filterData = filteredListData
//        authorTableView.reloadData()
//    }
//
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        getFilteredData(searchedText: searchBar.text ?? String())
//    }
//}
