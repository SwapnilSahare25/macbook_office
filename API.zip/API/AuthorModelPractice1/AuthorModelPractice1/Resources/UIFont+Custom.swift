//
//  UIFont+Custom.swift
//  AuthorModelPractice1
//
//  Created by Swapnil Sahare on 17/01/23.
//

import Foundation
import UIKit


extension UIFont {
   static func groteskBold(with size : CGFloat)-> UIFont? {
        return UIFont(name: "HKGrotesk-Bold", size: size)
    }
    static func groteskMedium(with size : CGFloat) ->UIFont? {
        return UIFont(name: "HKGrotesk-Medium", size: size)
    }
//    static func HKGroteskSemiBoldItalic(with size : CGFloat) -> UIFont? {
//        return
//    }
}
