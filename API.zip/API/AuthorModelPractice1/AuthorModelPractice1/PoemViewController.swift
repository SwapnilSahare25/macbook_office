//
//  PoemViewController.swift
//  AuthorModelPractice1
//
//  Created by Swapnil Sahare on 13/01/23.
//

import UIKit

class PoemViewController: UIViewController, UITextViewDelegate {

    @IBOutlet weak var poemView : UIView!
    @IBOutlet weak var poemLabel : UILabel!
    @IBOutlet weak var poemTextView : UITextView!
    
    var poem : String?
   
    override func viewDidLoad() {
        super.viewDidLoad()
//        DispatchQueue.main.async {
//            self.showLoading()
//        }
        poemTextView.delegate = self
        poemTextView.text = poem
        //print(poem)

        // Do any additional setup after loading the view.
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        self.removeLoading()
//    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
