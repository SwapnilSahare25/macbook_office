//
//  ViewController.swift
//  DictionaryProject
//
//  Created by Swapnil Sahare on 14/12/22.
//

import UIKit

class ViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate {
   
    var myDictArrey :[[[String:String]]] = [[["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]],[["E":"Akash"],["F":"Amit"],["G":"Amol"],["H":"Sameer"]],[["I":"Nagpur"],["J":"Mumbai"],["K":"Pune"],["L":"Nashik"],["M":"Solapur"]],[["1":"A"],["2":"B"],["3":"C"]]]

    @IBOutlet weak var myTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return myDictArrey.count
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let keys = myDictArrey[section]
        //print(keys)
        return keys.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell")
        
        let rowArray = myDictArrey[indexPath.section]
        //print(rowArrey) [["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]]
        let row = rowArray[indexPath.row]
        //print(keys) ["A":"Swapnil"]
        
        let key1 = Array(row.keys)[0] // A
        //print(key1)
        
        
        let value1 = row[key1]! // Swapnil
        //print(value1)
        
    
        cell?.textLabel?.text = "\(key1)"
        
        cell?.detailTextLabel?.text = "\(value1)"
       
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Section :\(section)"
    }
    
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "End :\(section)"
    }

} 

