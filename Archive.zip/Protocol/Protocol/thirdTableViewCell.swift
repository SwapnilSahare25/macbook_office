//
//  thirdTableViewCell.swift
//  Protocol
//
//  Created by Swapnil Sahare on 21/12/22.
//

import UIKit

protocol TableViewButton {
    
    func clicked (indexPath : IndexPath)
}

class thirdTableViewCell: UITableViewCell {
    
    var cellAction : TableViewButton?

    var indexPath : IndexPath?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func pressHere(_ sender: Any) {
        
        cellAction?.clicked(indexPath: indexPath!)
    }
}


// objc method
// closure
// add target , action
// protocol
