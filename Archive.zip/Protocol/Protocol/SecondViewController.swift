//
//  SecondViewController.swift
//  Protocol
//
//  Created by Swapnil Sahare on 20/12/22.
//

import UIKit


class User : NSObject {
    var fName : String?
    var lName : String?
    
    init(fName: String?, lName: String?) {
        self.fName = fName
        self.lName = lName
    }
}

class SecondViewController: UIViewController , TableViewDataSourceDelegate {
    
   
    @IBOutlet weak var secondTableView : UITableView!
    
    @IBOutlet weak var clickedButton: UIButton!
    
    var tableViewDataSource : TableViewDataSource?
    var cellAction : TableViewButton?
    var index : IndexPath?

    override func viewDidLoad() {
        super.viewDidLoad()
        let user1 = User(fName: "Amit", lName: "Ninawe")
        let user2 = User(fName: "Swapnil", lName: "Sahare")
        let user3 = User(fName: "Bharat", lName: "Silawat")
        let user4 = User(fName: "Uday", lName: "Patil")
        let data = [[user1,user2,user3,user4]]
        self.tableViewDataSource = TableViewDataSource(data: data, delegate: self)
        self.secondTableView.dataSource = self.tableViewDataSource
        
        // Do any additional setup after loading the view.
    }
    
    func cellForRow(at indexPath: IndexPath) -> UITableViewCell {
        let cell = self.secondTableView.dequeueReusableCell(withIdentifier: "User", for: indexPath)
        return cell
    }
    
    func design(cell: UITableViewCell, for data: Any) {
        guard let user = data as? User else {
                    return
                }
                cell.textLabel?.text = user.fName
                cell.detailTextLabel?.text = user.lName
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
