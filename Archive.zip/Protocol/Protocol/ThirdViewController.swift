//
//  ThirdViewController.swift
//  Protocol
//
//  Created by Swapnil Sahare on 21/12/22.
//

import UIKit


class ThirdViewController: UIViewController ,TableViewDataSourceDelegate ,TableViewButton {
    
    @IBOutlet weak var thirdTableView : UITableView!
    
    var tableViewDataSource : TableViewDataSource?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let data = [["a","b","c","d"]]
        self.tableViewDataSource = TableViewDataSource(data: data, delegate: self)
        self.thirdTableView.dataSource = self.tableViewDataSource

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func cellForRow(at indexPath: IndexPath) -> UITableViewCell {
        let cell = self.thirdTableView.dequeueReusableCell(withIdentifier: "thirdTableViewCell", for: indexPath) as! thirdTableViewCell
        cell.cellAction = self // for particular cell
        cell.indexPath = indexPath // initilized
        return cell
    }
    
    func design(cell: UITableViewCell, for data: Any) {
        
        cell.textLabel?.text = (data as? String) ?? "" // shows data of arrey
        
    }
    
    func clicked(indexPath: IndexPath) { // method created in protocol
        
        print("\(indexPath.row) is tapped")
    }
    
}
