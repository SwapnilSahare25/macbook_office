//
//  ViewController.swift
//  SwiftPracticeProject
//
//  Created by Swapnil Sahare on 08/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var customflipkart: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //test swapnils
    
    @IBAction func actionButton(_ sender: Any) {
        
        let secondvc = self.storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        
        self.navigationController?.pushViewController(secondvc, animated: true)
        
        
    }
}
