//
//  componentsViewController.swift
//  SwiftPracticeProject
//
//  Created by Swapnil Sahare on 12/12/22.
//

import UIKit

class componentsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet weak var componentTableview: UITableView!
    
    var dataDict: [Int:Int] = [1: 5, 2: 10, 3: 30]
    //var myStr : [String:[String]] = ["Vowels":["A","E","I","O","U"],"Consonents":["B","C","D","F","G","H","J","K","L","M","N","P","Q","R","S","T","V","W","X","Z"],"Numbers":["0","1","2","3","4","5","6","7","8","9"]]

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 0
//    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataDict.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = componentTableview.dequeueReusableCell(withIdentifier: "ComponentTableViewCell", for: indexPath) as! ComponentTableViewCell
        
        return cell
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> Int? {
//        let keyArrey = Array(dataDict.keys)
//        let key = keyArrey[section]
//        return key
//    }
}
