//
//  ViewController.swift
//  TableViewWithDictionary
//
//  Created by Swapnil Sahare on 13/12/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    var strDict: [String: [String]] = ["Vowel": ["A", "E", "I", "O", "U"], "Consonants": ["B","C","D","F","G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X","Z"], "Numbers": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]]
    // keys are string and values are arrey of string
    
   
    @IBOutlet weak var myTableView : UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
   
   
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return strDict.keys.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let rowArrey = Array(strDict.keys)
        let row = rowArrey[section]
        //print(row)
        return row.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell")
        
        let rowArrey = Array(strDict.keys)
        //print(keyArrey)
        let row = rowArrey[indexPath.section]
        //print(row)
        cell?.textLabel?.text = strDict[row]?[indexPath.row]
        print(strDict[row]?[indexPath.row])
        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let Keys = Array(strDict.keys)
        return Keys[section]
    }
   
}

