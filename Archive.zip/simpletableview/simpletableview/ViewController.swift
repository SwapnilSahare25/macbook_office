//
//  ViewController.swift
//  simpletableview
//
//  Created by Swapnil Sahare on 13/12/22.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
   
    var dataDict :[Int:Int] = [1:5,2:10,3:30,4:40,5:15,6:12,7:2]

    @IBOutlet weak var mytableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataDict.keys.count+1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
//        switch section {
//        case 0:
//            return 10
//        case 1:
//            return 5
//        case 2:
//            return 7
//        default :
//            return 50
//        }
        let values = dataDict[section] ?? 0
        //print(values)
        return values
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = "Row: \(indexPath.row)"
        return cell!
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "Section \(section)"
    }

}

