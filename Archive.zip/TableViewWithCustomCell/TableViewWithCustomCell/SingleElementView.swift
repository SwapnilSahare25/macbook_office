//
//  SingleElementView.swift
//  TableViewWithCustomCell
//
//  Created by Swapnil Sahare on 20/12/22.
//

import UIKit

class SingleElementView: UIView {
    
    private var titileLbl : UILabel = {
        
        let view = UILabel()
        view.textAlignment = .right
        return view
    }()
    
    private lazy var detailLbl : UILabel = {
        let view = UILabel()
        view.textAlignment = .left
        return view
    }()

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override init(frame: CGRect) {
        super.init(frame: frame)
        //configureSubViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    private func configureSubViews(){
        
        self.addSubview(titileLbl)
        titileLbl.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
        titileLbl.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 9),
        titileLbl.centerYAnchor.constraint(equalTo: self.centerYAnchor),
        titileLbl.widthAnchor.constraint(lessThanOrEqualToConstant: self.frame.size.width/3),
        titileLbl.heightAnchor.constraint(equalToConstant: 30)
        
        ])
        
        self.addSubview(detailLbl)
        detailLbl.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            detailLbl.leadingAnchor.constraint(equalTo: titileLbl.trailingAnchor, constant: 9),
            detailLbl.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -9),
            detailLbl.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            detailLbl.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    func setupView(with title: String, detail: String) {
        self.titileLbl.text = title + ": "
        self.detailLbl.text = detail
    }
}
