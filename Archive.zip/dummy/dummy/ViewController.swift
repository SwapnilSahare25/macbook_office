//
//  ViewController.swift
//  dummy
//
//  Created by Swapnil Sahare on 13/12/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    struct FruitModel {
        var name: String
        var description: String
    }
    var fruitModel = [String: [FruitModel]]()
    var dataKeys : Array = [String]()
    
    

    @IBOutlet weak var tableview1: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview1.delegate = self
        tableview1.dataSource = self
        // Do any additional setup after loading the view.
        fruitModel = [
                "C" : [
                FruitModel(name: "Clementine", description: "Clementines are super tasty!"),
                FruitModel(name: "Cherry", description: "Cherry's are red."),
                FruitModel(name: "Coconut", description: "Nuts for coconuts!!!"),
                ],
                "P" : [
                FruitModel(name: "Pear", description: "Pears rock!"),
                FruitModel(name: "Peach", description: "Mmmm, Peach."),
                ],
                "S" : [
                FruitModel(name: "Strawberry", description: "A widely grown hybrid species of the genus Fragaria. It is cultivated worldwide for its fruit.")
                ]
            ]

            dataKeys = (fruitModel as NSDictionary).allKeys as! [String]
            print(dataKeys)
            tableview1.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataKeys.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sec = dataKeys[section]
        return fruitModel[sec]?.count ?? 0
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dataKeys[section]
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        let sec = dataKeys[indexPath.section]
        cell.textLabel?.text = fruitModel[sec]?[indexPath.row].name

        return cell;
    }
}

