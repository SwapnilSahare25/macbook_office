//
//  AuthorViewController.swift
//  2022
//
//  Created by Swapnil Sahare on 11/01/23.
//

import UIKit

class AuthorViewController: UIViewController ,ConnectionManagerDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
       
        if error == nil {
            guard let data = data else {return}
            do{
                self.author = try JSONDecoder().decode(Author.self, from: data)
                //print(author)
            }catch let error{
                print(error)
            }
            DispatchQueue.main.async {
                self.authoreTableView.reloadData()
            }
        }
    }
    
    var author : Author?
    @IBOutlet weak var authoreTableView : UITableView!
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        connection.delegate = self
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        
        connection.startSession()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AuthorViewController : UITableViewDataSource ,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return author?.authors?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authoreTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
       
        cell.textLabel?.text = author?.authors![indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let author  = author?.authors?[indexPath.row]
        self.performSegue(withIdentifier: "AuthorResponse", sender: author)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AuthorResponse" {
            let  targetVc = segue.destination as! AuthorDetailViewController
            targetVc.name = (sender as? String) ?? ""
        }
    }
}
