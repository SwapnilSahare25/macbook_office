//
//  AuthorDetailViewController.swift
//  2022
//
//  Created by Swapnil Sahare on 11/01/23.
//

import UIKit

class AuthorDetailViewController: UIViewController {

    @IBOutlet weak var authorDetailTableView : UITableView!
    var name : String?
    var titlearray : [Title]?
    override func viewDidLoad() {
        super.viewDidLoad()
        detailData()
        // Do any additional setup after loading the view.
    }
    
    
    func detailData(){
        
        var urlStr = "https://poetrydb.org/author/"
        let query = name?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        urlStr.append(query)
        let url = URL(string: urlStr)
        let request = URLRequest(url: url!)
        
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {return}
            do {
                self.titlearray = try JSONDecoder().decode([Title].self, from: data)
            }catch let error{
                print(error)
            }
            DispatchQueue.main.async {
                self.authorDetailTableView.reloadData()
                
            }
            
        }
        dataTask.resume()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AuthorDetailViewController : UITableViewDataSource ,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titlearray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authorDetailTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let detail : Title = titlearray![indexPath.row]
        cell.textLabel?.text = detail.title
        cell.detailTextLabel?.text = detail.author
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let titleCount : Title = titlearray![indexPath.row]
        let poem:[String] = titleCount.lines ?? [""]
        self.performSegue(withIdentifier: "PoemResponse", sender: poem)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "PoemResponse" {
            let targetVc = segue.destination as! PoemViewController
            let poemLines = sender as! [String]
            targetVc.poem = poemLines.joined(separator:",")
            
        }
    }
}
