//
//  ResponseViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 29/12/22.
//

import UIKit
 // we conform protocol in class
class ResponseViewController: UIViewController, ConnectionManagerDelegate {
    

    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        
        DispatchQueue.main.async {
            self.removeLoading()
        }
        if error == nil {   // condtion for error is nil
            guard let data = data else {return}  // data is optional thats why guard data
            let text = String(data: data, encoding: .utf8)   // convert data into string
            DispatchQueue.main.async {  // ui changes can be done only on main thread
                self.urlTextView.text = text
            }
            
        }
    }
    
    // protocol properties
    var api : API?
    
    @IBOutlet weak var urlTextView : UITextView!
    
    @IBOutlet weak var responseView : UIView!
    @IBOutlet weak var responseActivityIndicator : UIActivityIndicatorView!
    
    let connection = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        connection.delegate = self
        responseView.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
//        responseView.isHidden = false
//        responseActivityIndicator.startAnimating()
//        self.view.isUserInteractionEnabled = false
        self.showLoading()
        self.connection.startSession()
        
    }
}
