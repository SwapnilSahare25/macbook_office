//
//  CoinPaprikaModel.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import Foundation


struct CoinPaprika : Codable {
    
    var id : String?
    var name : String?
    var symbol : String?
    var rank : Int?
    var isNew : Bool?
    var isActive : Bool?
    var type : String?
    var logo : String?
    var tags : [Tag]?
    var team : [Team]?
    var description : String?
    var message : String?
    var openSource : Bool?
    var startedAt : String?
    var developmentStatus : String?
    var hardwareWallet : Bool?
    var proofType : String?
    var orgStructure : String?
    var hashAlgorithm : String?
    var links : Links?
    var linksExtended : [LinksExtended]?
    var whitePaper : WhitePaper?
    var firstDataAt : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.symbol, forKey: .symbol)
        try container.encodeIfPresent(self.rank, forKey: .rank)
        try container.encodeIfPresent(self.isNew, forKey: .isNew)
        try container.encodeIfPresent(self.isActive, forKey: .isActive)
        try container.encodeIfPresent(self.type, forKey: .type)
        try container.encodeIfPresent(self.logo, forKey: .logo)
        try container.encodeIfPresent(self.tags, forKey: .tags)
        try container.encodeIfPresent(self.team, forKey: .team)
        try container.encodeIfPresent(self.description, forKey: .description)
        try container.encodeIfPresent(self.message, forKey: .message)
        try container.encodeIfPresent(self.openSource, forKey: .openSource)
        try container.encodeIfPresent(self.startedAt, forKey: .startedAt)
        try container.encodeIfPresent(self.developmentStatus, forKey: .developmentStatus)
        try container.encodeIfPresent(self.hardwareWallet, forKey: .hardwareWallet)
        try container.encodeIfPresent(self.proofType, forKey: .proofType)
        try container.encodeIfPresent(self.orgStructure, forKey: .orgStructure)
        try container.encodeIfPresent(self.hashAlgorithm, forKey: .hashAlgorithm)
        try container.encodeIfPresent(self.links, forKey: .links)
        try container.encodeIfPresent(self.linksExtended, forKey: .linksExtended)
        try container.encodeIfPresent(self.whitePaper, forKey: .whitePaper)
        try container.encodeIfPresent(self.firstDataAt, forKey: .firstDataAt)
    }
    enum CodingKeys:String, CodingKey {
        case id
        case name
        case symbol
        case rank
        case isNew = "is_new"
        case isActive = "is_active"
        case type
        case logo
        case tags
        case team
        case description
        case message
        case openSource = "open_source"
        case startedAt = "started_at"
        case developmentStatus = "development_status"
        case hardwareWallet = "hardware_wallet"
        case proofType = "proof_type"
        case orgStructure = "org_structure"
        case hashAlgorithm = "hash_algorithm"
        case links
        case linksExtended = "links_extended"
        case whitePaper = "whitepaper"
        case firstDataAt = "first_data_at"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.symbol = try container.decodeIfPresent(String.self, forKey: .symbol)
        self.rank = try container.decodeIfPresent(Int.self, forKey: .rank)
        self.isNew = try container.decodeIfPresent(Bool.self, forKey: .isNew)
        self.isActive = try container.decodeIfPresent(Bool.self, forKey: .isActive)
        self.type = try container.decodeIfPresent(String.self, forKey: .type)
        self.logo = try container.decodeIfPresent(String.self, forKey: .logo)
        self.tags = try container.decodeIfPresent([Tag].self, forKey: .tags)
        self.team = try container.decodeIfPresent([Team].self, forKey: .team)
        self.description = try container.decodeIfPresent(String.self, forKey: .description)
        self.message = try container.decodeIfPresent(String.self, forKey: .message)
        self.openSource = try container.decodeIfPresent(Bool.self, forKey: .openSource)
        self.startedAt = try container.decodeIfPresent(String.self, forKey: .startedAt)
        self.developmentStatus = try container.decodeIfPresent(String.self, forKey: .developmentStatus)
        self.hardwareWallet = try container.decodeIfPresent(Bool.self, forKey: .hardwareWallet)
        self.proofType = try container.decodeIfPresent(String.self, forKey: .proofType)
        self.orgStructure = try container.decodeIfPresent(String.self, forKey: .orgStructure)
        self.hashAlgorithm = try container.decodeIfPresent(String.self, forKey: .hashAlgorithm)
        self.links = try container.decodeIfPresent(Links.self, forKey: .links)
        self.linksExtended = try container.decodeIfPresent([LinksExtended].self, forKey: .linksExtended)
        self.whitePaper = try container.decodeIfPresent(WhitePaper.self, forKey: .whitePaper)
        self.firstDataAt = try container.decodeIfPresent(String.self, forKey: .firstDataAt)
    }
}


struct Tag : Codable {
    
    var id : String?
    var name : String?
    var coinCounter : Int?
    var icoCounter : Int?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.coinCounter, forKey: .coinCounter)
        try container.encodeIfPresent(self.icoCounter, forKey: .icoCounter)
    }
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case coinCounter = "coin_counter"
        case icoCounter = "ico_counter"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.coinCounter = try container.decodeIfPresent(Int.self, forKey: .coinCounter)
        self.icoCounter = try container.decodeIfPresent(Int.self, forKey: .icoCounter)
    }
}


struct Team : Codable {
    var id: String?
    var name :String?
    var position : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.position, forKey: .position)
    }
    enum CodingKeys: CodingKey {
        case id
        case name
        case position
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(String.self, forKey: .id)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.position = try container.decodeIfPresent(String.self, forKey: .position)
    }
}


struct Links : Codable {
    var explorer : [String]?
    var facebook : [String]?
    var reddit : [String]?
    var sourceCode : [String]?
    var website : [String]?
    var youtube : [String]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.explorer, forKey: .explorer)
        try container.encodeIfPresent(self.facebook, forKey: .facebook)
        try container.encodeIfPresent(self.reddit, forKey: .reddit)
        try container.encodeIfPresent(self.sourceCode, forKey: .sourceCode)
        try container.encodeIfPresent(self.website, forKey: .website)
        try container.encodeIfPresent(self.youtube, forKey: .youtube)
    }
    enum CodingKeys:String, CodingKey {
        case explorer
        case facebook
        case reddit
        case sourceCode = "source_code"
        case website
        case youtube
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.explorer = try container.decodeIfPresent([String].self, forKey: .explorer)
        self.facebook = try container.decodeIfPresent([String].self, forKey: .facebook)
        self.reddit = try container.decodeIfPresent([String].self, forKey: .reddit)
        self.sourceCode = try container.decodeIfPresent([String].self, forKey: .sourceCode)
        self.website = try container.decodeIfPresent([String].self, forKey: .website)
        self.youtube = try container.decodeIfPresent([String].self, forKey: .youtube)
    }
    
}


struct LinksExtended : Codable {
    var url : String?
    var type : String?
    var stats : Stats?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.url, forKey: .url)
        try container.encodeIfPresent(self.type, forKey: .type)
        try container.encodeIfPresent(self.stats, forKey: .stats)
    }
    enum CodingKeys: CodingKey {
        case url
        case type
        case stats
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.url = try container.decodeIfPresent(String.self, forKey: .url)
        self.type = try container.decodeIfPresent(String.self, forKey: .type)
        self.stats = try container.decodeIfPresent(Stats.self, forKey: .stats)
    }
}


struct Stats : Codable {
    var subscriber : Int?
    var contributer : Int?
    var stars : Int?
    var followers : Int?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.subscriber, forKey: .subscriber)
        try container.encodeIfPresent(self.contributer, forKey: .contributer)
        try container.encodeIfPresent(self.stars, forKey: .stars)
        try container.encodeIfPresent(self.followers, forKey: .followers)
    }
    enum CodingKeys: CodingKey {
        case subscriber
        case contributer
        case stars
        case followers
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.subscriber = try container.decodeIfPresent(Int.self, forKey: .subscriber)
        self.contributer = try container.decodeIfPresent(Int.self, forKey: .contributer)
        self.stars = try container.decodeIfPresent(Int.self, forKey: .stars)
        self.followers = try container.decodeIfPresent(Int.self, forKey: .followers)
    }
}


struct WhitePaper : Codable {
    var link : String?
    var thumbnail : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.link, forKey: .link)
        try container.encodeIfPresent(self.thumbnail, forKey: .thumbnail)
    }
    enum CodingKeys: CodingKey {
        case link
        case thumbnail
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.link = try container.decodeIfPresent(String.self, forKey: .link)
        self.thumbnail = try container.decodeIfPresent(String.self, forKey: .thumbnail)
    }
}
