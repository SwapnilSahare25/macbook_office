//
//  TeleportModel.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import Foundation

struct Teleport : Codable {
    var links : Link?
    var categories : [Category]? // let a: = categories[0]
    var summary : String?
    var teleportCityScore : Float?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.links, forKey: .links)
        try container.encodeIfPresent(self.categories, forKey: .categories)
        try container.encodeIfPresent(self.summary, forKey: .summary)
        try container.encodeIfPresent(self.teleportCityScore, forKey: .teleportCityScore)
    }
    enum CodingKeys:String, CodingKey {
        case links = "_links"
        case categories
        case summary
        case teleportCityScore = "teleport_city_score"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.links = try container.decodeIfPresent(Link.self, forKey: .links)
        self.categories = try container.decodeIfPresent([Category].self, forKey: .categories)
        self.summary = try container.decodeIfPresent(String.self, forKey: .summary)
        self.teleportCityScore = try container.decodeIfPresent(Float.self, forKey: .teleportCityScore)
    }
    
}


struct Link : Codable {
    var curies : [Curies]?
    var myself : MySelf?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.curies, forKey: .curies)
        try container.encodeIfPresent(self.myself, forKey: .myself)
    }
    enum CodingKeys: String, CodingKey {
        case curies
        case myself = "self"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.curies = try container.decodeIfPresent([Curies].self, forKey: .curies)
        self.myself = try container.decodeIfPresent(MySelf.self, forKey: .myself)
    }
}


struct Curies : Codable {
    var href : String?
    var name : String?
    var templeted : Bool?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.href, forKey: .href)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.templeted, forKey: .templeted)
    }
    
    enum CodingKeys: CodingKey {
        case href
        case name
        case templeted
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.href = try container.decodeIfPresent(String.self, forKey: .href)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.templeted = try container.decodeIfPresent(Bool.self, forKey: .templeted)
    }
}


struct MySelf : Codable {
    var hrf : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.hrf, forKey: .hrf)
    }
    enum CodingKeys: String, CodingKey {
        case hrf = "href"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.hrf = try container.decodeIfPresent(String.self, forKey: .hrf)
    }
}

struct Category : Codable {
    var color : String?
    var name : String?
    var scoreOutOfTen : Float?
    
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.color, forKey: .color)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.scoreOutOfTen, forKey: .scoreOutOfTen)
    }
    enum CodingKeys:String, CodingKey {
        case color
        case name
        case scoreOutOfTen = "score_out_of_10"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.color = try container.decodeIfPresent(String.self, forKey: .color)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.scoreOutOfTen = try container.decodeIfPresent(Float.self, forKey: .scoreOutOfTen)
    }
}
