//
//  TeleportViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import UIKit

class TeleportViewController: UIViewController,ConnectionManagerDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async {
            self.removeLoading()
        }
        if error == nil {
            guard let data = data else {return}
            do {
                self.telport = try JSONDecoder().decode(Teleport.self, from: data)
            } catch let e {
                print(e)
            }
          
            DispatchQueue.main.async {
                self.teleportTableView.reloadData()
            }
        }
    }
    @IBOutlet weak var teleportTableView : UITableView!

   
    // instance of teleport class
    var telport : Teleport?
    
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        connection.delegate = self
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
        connection.startSession()
        self.showLoading()
        
    }
}


extension TeleportViewController : UITableViewDataSource {
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return telport?.categories?.count ?? 0
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = teleportTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let category : Category = telport!.categories![indexPath.row]
        cell.textLabel?.text = category.color
        cell.detailTextLabel?.text = category.name
        return cell
    }
}
extension UIColor {
    
    convenience init( hex : String) {
        let r , b , g , a : CGFloat
    }
}
