//
//  ViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 29/12/22.
//

import UIKit

class ViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate {
  
    var apiArrey : [API] = [.nagerdate,.randomuser,.coinpaprika,.teleport,.university,.bitcoin]
    
    let dict: [API: String] = [.nagerdate : "nagerDateResponse", .randomuser: "randomUserResponse",.coinpaprika : "coinPaprikaResponse",.teleport : "teleportResponse",.university : "UniversityResponse"]
    
    
    @IBOutlet weak var urlTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
//make type of enum = arrey:[enum]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apiArrey.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = urlTableView.dequeueReusableCell(withIdentifier: "urlCell", for: indexPath)
        let apiType:API = apiArrey[indexPath.row]
        cell.textLabel?.text = apiType.rawValue
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urlApi : API = apiArrey[indexPath.row] //=>0 index .nagerDate
        // for dictionary
        let id : String = dict[urlApi] ?? ""
        
        if id.count > 0 {
            self.performSegue(withIdentifier: id, sender: urlApi)
        }
        
//        switch(urlApi){
//            case .nagerdate :
//                self.performSegue(withIdentifier: "nagerDateResponse", sender: urlApi)
//            case.randomuser :
//                self.performSegue(withIdentifier: "randomUserResponse", sender: urlApi)
//            case.coinpaprika :
//                self.performSegue(withIdentifier: "coinPaprikaResponse", sender: urlApi)
//            case.teleport :
//                self.performSegue(withIdentifier: "teleportResponse", sender: urlApi)
//
//        }  // finished
        
        
        //self.performSegue(withIdentifier: "response", sender: urlApi)
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier?.hasSuffix("Response") == true {
            // for identify segue (with identifier)
            guard let api : API = sender as? API else {return}
            
            var targetvc = segue.destination as? ConnectionManagerDelegate
            targetvc?.api = api
            
        }
    }
}

