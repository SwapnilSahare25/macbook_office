//
//  CoinPaprikaViewController.swift
//  connectionManager
//
//  Created by Swapnil Sahare on 30/12/22.
//

import UIKit

class CoinPaprikaViewController: UIViewController,ConnectionManagerDelegate {
    var api: API?
    
    func didFinishedTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async {
            self.removeLoading()
        }
        if error == nil {
            guard let data = data else {return}
            //let text = String(data: data, encoding: .utf8)
            do{
                self.coin = try JSONDecoder().decode(CoinPaprika.self, from: data)
            }catch let e{
                print(e)
            }
            
            DispatchQueue.main.async {
                //self.coinPaprikaTextView.text = text
                self.coinPeprikaTableView.reloadData()
            }
        }
    }
    
    
    
    //@IBOutlet weak var coinPaprikaTextView : UITextView!
    @IBOutlet weak var coinPeprikaTableView : UITableView!
    var coin : CoinPaprika?
    
    let connection = ConnectionManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        connection.delegate = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func viewDidAppear(_ animated: Bool) {
        connection.startSession()
        self.showLoading()
    }

}
extension CoinPaprikaViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coin?.tags?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = coinPeprikaTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let coinData : Tag = coin!.tags![indexPath.row]
        cell.textLabel?.text = coinData.name
        cell.detailTextLabel?.text = coinData.id
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
    }
    
}
