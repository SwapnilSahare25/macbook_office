//
//  Network.swift
//  MultipleApiProject
//
//  Created by Bharat Silavat on 04/01/23.
//

import Foundation

//MARK: - Making protocol -

protocol ConnectionManagerDelegate {
    func didCompleteTask(with data:Data?, error:Error?, for api:API)
}

class ConnectionManager{
    
    var delegate : ConnectionManagerDelegate?
    var currentAPI: API = .todosPosts
    private let session = URLSession.shared
    var url: String?
    
    init(delegate: ConnectionManagerDelegate? = nil, url: String? = nil) {
        self.delegate = delegate
        self.url = url
    }
    
    //MARK: - making function to Start a Session -
    
    func startSession(){
        
        
        let api: API = .todosPosts
        let url = api.rawValue
        self.hitUrl(url)
        
    }
    
    func getPosts() {
        let api: API = .todosPosts
        currentAPI = api
        let url = api.rawValue
        self.hitUrl(url)
    }
    
    func getComments() {
        let api: API = .todosComments
        currentAPI = api
        let url = api.rawValue
        self.hitUrl(url)
    }
    
    func getUsers() {
        let api: API = .todosUsers
        currentAPI = api
        let url = api.rawValue
        self.hitUrl(url)
    }
    
    func getComments(for postId: Int) {
        let api: API = .todosPostComments
        let url = String(format: api.rawValue, "\(postId)")
        self.hitUrl(url)
    }
    
    // MARK: - Private Function To hitUrl AfterStarting UrlSession -
    
    private func hitUrl(_ provideStringUrlHere : String, queryParam: [String: String]? = nil) {
        
        guard let url = URL(string: provideStringUrlHere) else { return }
        let request = URLRequest(url: url)
        
        let task = URLSession.shared.dataTask(with: request) { (data, responce, error ) in
            
            guard let delegate = self.delegate else {return}
            delegate.didCompleteTask(with: data, error: error, for: self.currentAPI)
            
        }.resume()
        
    }
    
}

// MARK: - Create and Enum to pass all API's Url's -

enum API: String{
    
    case todosList =  "https://jsonplaceholder.typicode.com/todos"
    case todosUsers = "https://jsonplaceholder.typicode.com/users"
    case todosPosts = "https://jsonplaceholder.typicode.com/posts"
    case todosPhotos = "https://jsonplaceholder.typicode.com/photos"
    case todosAlbums = "https://jsonplaceholder.typicode.com/albums"
    case todosComments = "https://jsonplaceholder.typicode.com/comments"
    case todosPostComments = "https://jsonplaceholder.typicode.com/posts/%@/comments"
}
