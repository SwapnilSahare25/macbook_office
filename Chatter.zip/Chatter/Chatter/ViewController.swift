//
//  ViewController.swift
//  Chatter
//
//  Created by Bharat Silavat on 09/01/23.
//

import UIKit

class ViewController: UIViewController, ConnectionManagerDelegate {
    var api: API?
    
    func didCompleteTask(with data: Data?, error: Error?) {
        
    }
    
    func queryParameter() -> [URLQueryItem] {
        let query = [URLQueryItem(name: "client_id", value: "0ee021ae6e34be67c2ebcdb242e5b606e135be9e"), URLQueryItem(name: "response_type", value: "code"), URLQueryItem(name: "redirect_uri", value: "chatter://")]
        return query
    }
    
    var code: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.api = .authorize
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var urlComponent = URLComponents(string: "https://gitter.im/login/oauth/authorize")
        urlComponent?.queryItems = self.queryParameter()
        UIApplication.shared.openURL(urlComponent!.url!)
    }
}

